
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from '@/context/LanguageContext';
import SiteMapPage from '@/pages/SiteMapPage';
import ProductFeedPage from '@/pages/ProductFeedPage';
import CatalogFeedPage from '@/pages/CatalogFeedPage';
import TowerCraneFeedPage from '@/pages/TowerCraneFeedPage';

const RobotsTxtPage = () => {
    const sitemapUrl = `https://www.bku-website.online/sitemap.xml`;
    return (
        <pre>
            {`User-agent: *
Allow: /

Sitemap: ${sitemapUrl}`}
        </pre>
    );
};

const Root = () => {
  return (
    <BrowserRouter>
      <LanguageProvider>
        <Routes>
            <Route path="/sitemap.xml" element={<SiteMapPage />} />
            <Route path="/product-feed.xml" element={<ProductFeedPage />} />
            <Route path="/catalog-feed.xml" element={<CatalogFeedPage />} />
            <Route path="/tower-crane-feed.xml" element={<TowerCraneFeedPage />} />
            <Route path="/robots.txt" element={<RobotsTxtPage />} />
            <Route path="/*" element={<App />} />
        </Routes>
      </LanguageProvider>
    </BrowserRouter>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(
  <Root />
);
