
import React, { useContext, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { Route, Routes, useLocation, Navigate } from 'react-router-dom';
import HomePage from '@/pages/HomePage';
import EquipmentPage from '@/pages/EquipmentPage';
import ContactPage from '@/pages/ContactPage';
import TowerCranesPage from '@/pages/TowerCranesPage';
import TowerCraneDetailPage from '@/pages/TowerCraneDetailPage';
import AboutPage from '@/pages/AboutPage';
import ServicesPage from '@/pages/ServicesPage';
import MaintenancePage from '@/pages/MaintenancePage';
import TrainingPage from '@/pages/TrainingPage';
import ProjectsPage from '@/pages/ProjectsPage';
import CatalogSalesPage from '@/pages/CatalogSalesPage';
import MusicPlayer from '@/components/MusicPlayer';
import CatalogDetailPage from '@/pages/CatalogDetailPage';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import LogisticsPage from '@/pages/LogisticsPage';
import ConsultationPage from '@/pages/ConsultationPage';
import ConstructionHoistsPage from '@/pages/ConstructionHoistsPage';
import StoreLocatorPage from '@/pages/StoreLocatorPage';
import BlogPage from '@/pages/BlogPage';
import BlogPostPage from '@/pages/BlogPostPage';
import MediaPage from '@/pages/MediaPage';
import OrderConfirmationPage from '@/pages/OrderConfirmationPage';
import SEOServicesPage from '@/pages/SEOServicesPage';
import { LanguageContext } from '@/context/LanguageContext';
import { translations } from '@/lib/translations';

const AppContent = () => {
  const { language, setLanguage } = useContext(LanguageContext);
  const location = useLocation();
  const isRtl = language === 'ar';
  
  const getDynamicHost = () => {
    const hostname = window.location.hostname;
    return `https://${hostname}`;
  };

  const canonicalHost = getDynamicHost();

  useEffect(() => {
    const pathSegments = location.pathname.split('/').filter(Boolean);
    const langSegment = pathSegments[0];
    const langMap = { 'en': 'en', 'tr': 'tr', 'cn': 'zh' };
    
    if (langSegment && langMap[langSegment]) {
      setLanguage(langMap[langSegment]);
    } else {
      setLanguage('ar');
    }
  }, [location.pathname, setLanguage]);

  const t = translations[language] || translations.en;
  
  const isHomePage = location.pathname === '/' || ['/en', '/tr', '/cn'].includes(location.pathname);

  const getCanonicalUrl = (currentPath, targetLang) => {
    const pathSegments = currentPath.split('/').filter(Boolean);
    const langSegment = pathSegments[0];
    
    let pathWithoutLang = currentPath;
    if (['en', 'tr', 'cn'].includes(langSegment)) {
      pathWithoutLang = '/' + pathSegments.slice(1).join('/');
    }
    if (pathWithoutLang === '') pathWithoutLang = '/';

    let langPrefix = '';
    if (targetLang === 'zh') {
        langPrefix = '/cn';
    } else if (targetLang === 'en' || targetLang === 'tr') {
        langPrefix = `/${targetLang}`;
    }

    const finalPath = `${langPrefix}${pathWithoutLang === '/' ? '' : pathWithoutLang}`;
    return `${canonicalHost}${finalPath || '/'}`;
  };

  const getHrefLang = (langCode) => {
    switch(langCode) {
      case 'ar': return 'ar-KW';
      case 'en': return 'en-US';
      case 'tr': return 'tr-TR';
      case 'zh': return 'zh-CN';
      default: return langCode;
    }
  };

  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    "name": "BKU Crane - Tower Crane Kuwait",
    "image": `${canonicalHost}/logo.png`,
    "@id": `${canonicalHost}/`,
    "url": `${canonicalHost}/`,
    "telephone": "+965-69306030",
    "priceRange": "$$$",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Al-Nahar Complex, Floor 1, Office 5, Tunisia St",
      "addressLocality": "Hawally",
      "addressCountry": "KW"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 29.340991,
      "longitude": 48.019832
    },
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"],
      "opens": "08:00",
      "closes": "17:00"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+965-69306030",
      "contactType": "customer service",
      "areaServed": ["KW", "QA", "SA", "AE"],
      "availableLanguage": ["en", "ar", "zh", "tr"]
    },
    "sameAs": [
      "https://www.facebook.com/share/1QK2CJFNbr/?mibextid=wwXIfr",
      "https://www.instagram.com/bku_cranes/",
      "https://www.linkedin.com/company/bkucrane/?originalSubdomain=kw",
      "https://www.youtube.com/@bkucrane",
      "https://www.tiktok.com/@bku_cranes"
    ],
    "description": "The number one expert for Tower Crane Kuwait. We are certified suppliers for Liebherr and Potain tower cranes in Kuwait and the Gulf. We offer rental and sales of tower cranes, construction hoists, luffing crane, and self erecting tower crane. For the best tower crane kuwait services, contact us."
  };

  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": `${canonicalHost}/`,
    "potentialAction": {
      "@type": "SearchAction",
      "target": {
        "type": "EntryPoint",
        "urlTemplate": `${canonicalHost}/en/equipment?q={search_term_string}`
       },
      "query-input": "required name=search_term_string"
    }
  };

  const PageRoutes = () => (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/equipment" element={<EquipmentPage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/equipment/tower-cranes" element={<TowerCranesPage />} />
      <Route path="/equipment/tower-cranes/:craneId" element={<TowerCraneDetailPage />} />
      <Route path="/equipment/construction-hoists" element={<ConstructionHoistsPage />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/services" element={<ServicesPage />} />
      <Route path="/services/maintenance" element={<MaintenancePage />} />
      <Route path="/services/training" element={<TrainingPage />} />
      <Route path="/services/logistics" element={<LogisticsPage />} />
      <Route path="/services/consultation" element={<ConsultationPage />} />
      <Route path="/projects" element={<ProjectsPage />} />
      <Route path="/catalog-sales" element={<CatalogSalesPage />} />
      <Route path="/catalog-sales/:catalogId" element={<CatalogDetailPage />} />
      <Route path="/store-locator" element={<StoreLocatorPage />} />
      <Route path="/blog" element={<BlogPage />} />
      <Route path="/blog/:postId" element={<BlogPostPage />} />
      <Route path="/media" element={<MediaPage />} />
      <Route path="/order-confirmation" element={<OrderConfirmationPage />} />
      <Route path="/seo-services" element={<SEOServicesPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );

  return (
    <>
      <Helmet>
        <html lang={language} dir={isRtl ? 'rtl' : 'ltr'} />
        <link rel="canonical" href={getCanonicalUrl(location.pathname, language)} />
        {['en', 'ar', 'tr', 'zh'].map(langCode => (
          <link 
            key={langCode}
            rel="alternate" 
            hrefLang={getHrefLang(langCode)}
            href={getCanonicalUrl(location.pathname, langCode)}
          />
        ))}
        <link rel="alternate" hrefLang="x-default" href={getCanonicalUrl(location.pathname, 'ar')} />
        <meta property="og:locale" content={language === 'ar' ? "ar_KW" : language === 'zh' ? "zh_CN" : "en_US"} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={getCanonicalUrl(location.pathname, language)} />
        <meta property="og:image" content={`${canonicalHost}/og-image.jpg`} />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
        <meta property="og:image:alt" content="A fleet of BKU's Liebherr and Potain tower cranes at a construction site. tower crane kuwait" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content={`${canonicalHost}/og-image.jpg`} />
        <meta name="keywords" content={language === 'ar' ? "تاور كرين الكويت, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, BKU Crane, معدات ثقيلة الكويت, رافعات برجية الكويت, صيانة رافعات الكويت, تدريب رافعات الكويت, لوجستيات رافعات الكويت, استشارات رافعات الكويت" : "tower crane Kuwait, rental tower crane, tower crane for sale, BKU Crane, heavy equipment Kuwait, tower cranes Kuwait, crane maintenance Kuwait, crane training Kuwait, crane logistics Kuwait, crane consultation Kuwait"} />
        <script type="application/ld+json">{JSON.stringify(localBusinessSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(websiteSchema)}</script>
      </Helmet>
      <div className="flex flex-col min-h-screen">
          <Header isHomePage={isHomePage} />
          <main className={`flex-grow ${!isHomePage ? 'pt-28 sm:pt-32' : ''}`}>
            <h1 className="sr-only">
              {language === 'ar' 
                ? "تاور كرين الكويت، تاجير رافعه برجية، بيع رافعة برجية، للايجار رافعة برجية" 
                : t.h1}
            </h1>
             <div style={{ display: 'none' }}>
              {'tower crane kuwait, rental tower crane, tower crane for sale'.repeat(10)}
            </div>
            <Routes>
              <Route path="/en/*" element={<PageRoutes />} />
              <Route path="/tr/*" element={<PageRoutes />} />
              <Route path="/cn/*" element={<PageRoutes />} />
              <Route path="/*" element={<PageRoutes />} />
            </Routes>
          </main>
          <Footer />
      </div>
      <Toaster />
      <MusicPlayer />
    </>
  );
};

const RedirectManager = ({ children }) => {
  const location = useLocation();

  const redirects = {
    '/ar': '/',
    '/catalogs': '/catalog-sales',
    '/blog/1': '/blog',
    '/blog/xcmg-safety-features-for-rental-fleet': '/blog/xcmg-crane-safety-features',
    '/blog/choosing-the-right-sym-crane': '/blog/how-to-choose-sym-tower-crane',
    '/blog/how-to-use-sym-tower-cranes': '/blog/how-to-operate-sym-tower-crane',
    '/blog/yongmao-in-kuwait-projects': '/blog/yongmao-tower-cranes-in-kuwait',
    '/blog/operator-training-for-xcmg-rentals': '/blog/xcmg-crane-operator-training',
  };

  const path = location.pathname;

  if (redirects[path]) {
    return <Navigate to={redirects[path]} replace />;
  }
  
  if (path.startsWith('/ar/')) {
    const newPath = path.substring(3);
    return <Navigate to={`/${newPath}`} replace />;
  }

  return children;
};

function App() {
  return (
    <RedirectManager>
      <AppContent />
    </RedirectManager>
  );
}

export default App;
