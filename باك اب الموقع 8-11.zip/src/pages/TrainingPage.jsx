import React, { useState, useRef, useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Award, Mail, Loader2, HardHat, BookOpen, ShieldCheck } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import KeywordsCloud from '@/components/KeywordsCloud';
import { LanguageContext } from '@/context/LanguageContext';
import emailjs from '@emailjs/browser';

const TrainingPage = () => {
  const { toast } = useToast();
  const formRef = useRef(null);
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const content = {
    en: {
      title: "Tower Crane Kuwait Operator Training | BKU Certified",
      subtitle: "Certified training programs for tower crane operators in Kuwait. We ensure your team operates with the highest standards of safety and efficiency for your tower crane kuwait projects.",
      keywords: `crane operator training, crane certification, crane safety courses, BKU training school, tower crane in Kuwait, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, tower crane kuwait, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      form: {
        title: "Enroll in a Training Course",
        companyName: "Company Name",
        name: "Your Name",
        email: "Email",
        phone: "Phone Number",
        courseDetails: "Which course are you interested in?",
        submit: "Register Now"
      },
      courses: {
        title: "Our Training Courses",
        items: [
          { icon: HardHat, title: "Basic Tower Crane Operation", description: "Fundamentals of operation, safety checks, and basic maneuvers for new operators." },
          { icon: BookOpen, title: "Advanced Rigging & Signaling", description: "Complex lifting techniques, communication protocols, and advanced safety for experienced operators." },
          { icon: ShieldCheck, title: "Crane Safety & Inspection", description: "Comprehensive course on daily inspections, recognizing hazards, and emergency procedures." },
        ]
      },
      toastSuccess: "Registration request sent successfully!",
      toastSuccessDesc: "We will contact you shortly with course details.",
      toastError: "Error!",
      toastErrorDesc: "Failed to send request. Please try again later."
    },
    ar: {
      title: "تدريب مشغلي تاور كرين الكويت | شهادة BKU",
      subtitle: "برامج تدريب معتمدة لمشغلي الرافعات البرجية في الكويت. نضمن أن فريقك يعمل بأعلى معايير السلامة والكفاءة لمشاريع tower crane kuwait الخاصة بك.",
      keywords: `تدريب مشغلي الرافعات, شهادة مشغل رافعة, دورات سلامة الرافعات, مدرسة تدريب BKU, تاور كرين في الكويت, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, تاور كرين الكويت, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      form: {
        title: "التسجيل في دورة تدريبية",
        companyName: "اسم الشركة",
        name: "الاسم",
        email: "البريد الإلكتروني",
        phone: "رقم الهاتف",
        courseDetails: "ما هي الدورة التي تهتم بها؟",
        submit: "سجل الآن"
      },
      courses: {
        title: "دوراتنا التدريبية",
        items: [
          { icon: HardHat, title: "تشغيل الرافعات البرجية الأساسي", description: "أساسيات التشغيل والفحوصات الآمنة والمناورات الأساسية للمشغلين الجدد." },
          { icon: BookOpen, title: "التجهيز والإشارة المتقدم", description: "تقنيات الرفع المعقدة وبروتوكولات الاتصال والسلامة المتقدمة للمشغلين ذوي الخبرة." },
          { icon: ShieldCheck, title: "سلامة وفحص الرافعات", description: "دورة شاملة حول الفحوصات اليومية والتعرف على المخاطر وإجراءات الطوارئ." },
        ]
      },
      toastSuccess: "تم إرسال طلب التسجيل بنجاح!",
      toastSuccessDesc: "سوف نتصل بك قريبا مع تفاصيل الدورة.",
      toastError: "خطأ!",
      toastErrorDesc: "فشل إرسال الطلب. يرجى المحاولة مرة أخرى لاحقًا."
    },
     zh: {
        title: "科威特塔式起重机操作员培训 | BKU认证",
        subtitle: "为科威特的塔式起重机操作员提供认证培训计划。我们确保您的团队在您的科威特塔式起重机项目中以最高的安全和效率标准运作。",
        keywords: `起重机操作员培训, 起重机认证, 起重机安全课程, BKU培训学校, 科威特塔式起重机, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, tower crane kuwait, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机`,
        form: { title: "报名培训课程", companyName: "公司名称", name: "您的姓名", email: "电子邮件", phone: "电话号码", courseDetails: "您对哪门课程感兴趣？", submit: "立即注册" },
        courses: { title: "我们的培训课程", items: [{ icon: HardHat, title: "基础塔式起重机操作", description: "为新操作员提供的操作基础、安全检查和基本操作。" }, { icon: BookOpen, title: "高级索具和信号", description: "为有经验的操作员提供复杂的起重技术、通信协议和高级安全。" }, { icon: ShieldCheck, title: "起重机安全与检查", description: "关于日常检查、识别危险和应急程序的综合课程。" },] },
        toastSuccess: "注册请求已成功发送！", toastSuccessDesc: "我们将很快与您联系并提供课程详情。", toastError: "错误！", toastErrorDesc: "发送请求失败。请稍后再试。"
    },
    tr: {
        title: "Kuveyt Kule Vinç Operatör Eğitimi | BKU Sertifikalı",
        subtitle: "Kuveyt'teki kule vinç operatörleri için sertifikalı eğitim programları. Ekibinizin kule vinç kuveyt projelerinizde en yüksek güvenlik ve verimlilik standartlarıyla çalışmasını sağlıyoruz.",
        keywords: `vinç operatörü eğitimi, vinç sertifikası, vinç güvenlik kursları, BKU eğitim okulu, Kuveyt'te kule vinç, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, kule vinç Kuveyt, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur`,
        form: { title: "Eğitim Kursuna Kaydolun", companyName: "Şirket Adı", name: "Adınız", email: "E-posta", phone: "Telefon Numarası", courseDetails: "Hangi kursla ilgileniyorsunuz?", submit: "Şimdi Kaydolun" },
        courses: { title: "Eğitim Kurslarımız", items: [{ icon: HardHat, title: "Temel Kule Vinç Operasyonu", description: "Yeni operatörler için operasyon temelleri, güvenlik kontrolleri ve temel manevralar." }, { icon: BookOpen, title: "İleri Düzey Sapan ve İşaretleme", description: "Deneyimli operatörler için karmaşık kaldırma teknikleri, iletişim protokolleri ve ileri düzey güvenlik." }, { icon: ShieldCheck, title: "Vinç Güvenliği ve Denetimi", description: "Günlük denetimler, tehlikeleri tanıma ve acil durum prosedürleri hakkında kapsamlı bir kurs." },] },
        toastSuccess: "Kayıt talebi başarıyla gönderildi!", toastSuccessDesc: "Kurs detayları ile yakında sizinle iletişime geçeceğiz.", toastError: "Hata!", toastErrorDesc: "İstek gönderilemedi. Lütfen daha sonra tekrar deneyin."
    }
  };

  const t = content[language] || content.en;
  
  const getLangPrefix = () => {
    if (language === 'ar') return '';
    if (language === 'zh') return '/cn';
    return `/${language}`;
  };
  const langPrefix = getLangPrefix();

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    emailjs.sendForm('service_gkl5ueg', 'template_vxo3769', formRef.current, 'aIV30VFPKcE2h5A_w')
      .then((result) => {
          toast({ title: t.toastSuccess, description: t.toastSuccessDesc });
          formRef.current.reset();
      }, (error) => {
          toast({ title: t.toastError, description: error.text || t.toastErrorDesc, variant: 'destructive' });
      })
      .finally(() => {
        setIsSubmitting(false);
      });
  };

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "Crane Operator Training",
    "provider": { "@type": "Organization", "name": "BKU Crane" },
    "areaServed": "Kuwait",
    "description": t.subtitle,
    "name": t.title
  };

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.subtitle} />
        <meta name="keywords" content={t.keywords} />
        <link rel="canonical" href={`https://bku-website.online${langPrefix}/services/training`} />
        <meta property="og:title" content={t.title} />
        <meta property="og:description" content={t.subtitle} />
        <meta property="og:url" content={`https://bku-website.online${langPrefix}/services/training`} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/17498c56c2d1b8c199859f5b66d8e203.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify(serviceSchema)}</script>
      </Helmet>
      <div className="bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
        <section className="container mx-auto px-4 py-16 sm:py-24">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
                className="text-center mb-12"
            >
                <div className="inline-block bg-green-100 text-green-800 p-4 rounded-full mb-4">
                    <Award className="h-10 w-10" />
                </div>
                <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800">{t.title}</h1>
                <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">{t.subtitle}</p>
            </motion.div>
            
            <div className="grid lg:grid-cols-5 gap-12 items-start">
                <motion.div 
                    initial={{ opacity: 0, x: isRtl ? 50 : -50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                    className="lg:col-span-3 space-y-8"
                >
                    <h2 className="text-3xl font-bold text-gray-800">{t.courses.title}</h2>
                    <div className="space-y-6">
                        {t.courses.items.map((course, index) => {
                            const Icon = course.icon;
                            return (
                            <div key={index} className="flex items-start bg-white p-6 rounded-lg shadow-md">
                                <div className="flex-shrink-0 h-12 w-12 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
                                    <Icon className="h-6 w-6"/>
                                </div>
                                <div className={isRtl ? 'mr-4' : 'ml-4'}>
                                    <h4 className="text-lg font-semibold text-gray-900">{course.title}</h4>
                                    <p className="text-gray-600">{course.description}</p>
                                </div>
                            </div>
                            );
                        })}
                    </div>
                    <div className="mt-8">
                      <img alt="A certified crane operator safely maneuvering a tower crane in Kuwait with a clear view of the city skyline." className="rounded-lg shadow-xl w-full h-auto object-cover" src="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/17498c56c2d1b8c199859f5b66d8e203.jpg" />
                    </div>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                    className="lg:col-span-2 bg-white p-8 rounded-lg shadow-2xl sticky top-28"
                >
                    <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">{t.form.title}</h3>
                    <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="from_name" className="block text-sm font-medium text-gray-700 mb-1">{t.form.name}</label>
                            <Input id="from_name" name="from_name" type="text" placeholder={t.form.name} required />
                        </div>
                        <div>
                            <label htmlFor="company_name" className="block text-sm font-medium text-gray-700 mb-1">{t.form.companyName}</label>
                            <Input id="company_name" name="company_name" type="text" placeholder={t.form.companyName} />
                        </div>
                        <div>
                            <label htmlFor="from_email" className="block text-sm font-medium text-gray-700 mb-1">{t.form.email}</label>
                            <Input id="from_email" name="from_email" type="email" placeholder={t.form.email} required />
                        </div>
                        <div>
                            <label htmlFor="from_phone" className="block text-sm font-medium text-gray-700 mb-1">{t.form.phone}</label>
                            <Input id="from_phone" name="from_phone" type="tel" placeholder={t.form.phone} />
                        </div>
                        <div>
                            <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">{t.form.courseDetails}</label>
                            <Textarea id="message" name="message" placeholder={t.form.courseDetails} rows={4} required />
                        </div>
                        <div>
                            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-lg py-3" disabled={isSubmitting}>
                                {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Mail className="mr-2 h-5 w-5" />}
                                {isSubmitting ? (language === 'ar' ? 'جاري التسجيل...' : 'Registering...') : t.form.submit}
                            </Button>
                        </div>
                    </form>
                </motion.div>
            </div>
        </section>
      </div>
      <KeywordsCloud />
    </>
  );
};

export default TrainingPage;