import React, { useEffect, useContext } from 'react';
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '@/context/LanguageContext';

const OrderConfirmationPage = () => {
    const location = useLocation();
    const { language } = useContext(LanguageContext);

    const content = {
        en: {
            title: "Order Confirmed!",
            message: "Thank you for your purchase. Your order is being processed.",
            reviewInvite: "You may be invited to rate your experience."
        },
        ar: {
            title: "تم تأكيد الطلب!",
            message: "شكراً لشرائك. طلبك قيد المعالجة.",
            reviewInvite: "قد تتم دعوتك لتقييم تجربتك."
        },
        tr: {
            title: "Sipariş Onaylandı!",
            message: "Satın aldığınız için teşekkür ederiz. Siparişiniz işleniyor.",
            reviewInvite: "Deneyiminizi değerlendirmek için davet edilebilirsiniz."
        },
        zh: {
            title: "订单已确认！",
            message: "感谢您的购买。您的订单正在处理中。",
            reviewInvite: "您可能会被邀请评价您的体验。"
        }
    };
    const t = content[language];

    useEffect(() => {
        const queryParams = new URLSearchParams(location.search);
        const orderId = queryParams.get('order_id') || `MOCK-ORDER-${Date.now()}`;
        const email = queryParams.get('email') || 'customer@example.com';
        
        const deliveryDate = new Date();
        deliveryDate.setDate(deliveryDate.getDate() + 7);
        const estimatedDeliveryDate = deliveryDate.toISOString().split('T')[0];

        const products = [{ "gtin": "GTIN1" }, { "gtin": "GTIN2" }];

        window.renderOptIn = function() {
          if (window.gapi && window.gapi.surveyoptin) {
            try {
              window.gapi.surveyoptin.render({
                  "merchant_id": 5678671698,
                  "order_id": orderId,
                  "email": email,
                  "delivery_country": "KW",
                  "estimated_delivery_date": estimatedDeliveryDate,
                  "products": products
              });
            } catch (e) {
              console.error("Google Survey Opt-in render error:", e);
            }
          }
        };
        
        // If gapi is already loaded, render it. Otherwise, the onload callback will handle it.
        if (window.gapi) {
          window.renderOptIn();
        }

        return () => {
            // Cleanup the global function to avoid side-effects
            if (window.renderOptIn) {
                delete window.renderOptIn;
            }
        };
    }, [location]);

    return (
        <>
            <Helmet>
                <title>{t.title}</title>
            </Helmet>
            <div className="container mx-auto px-4 py-20 text-center">
                <div className="bg-white p-10 rounded-lg shadow-xl max-w-md mx-auto">
                    <h1 className="text-3xl font-bold text-green-600 mb-4">{t.title}</h1>
                    <p className="text-gray-700 mb-2">{t.message}</p>
                    <p className="text-sm text-gray-500">{t.reviewInvite}</p>
                </div>
            </div>
        </>
    );
};

export default OrderConfirmationPage;