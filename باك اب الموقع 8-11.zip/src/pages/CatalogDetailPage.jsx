import React, { useContext } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { catalogData } from '@/lib/catalogData';
import { Button } from '@/components/ui/button';
import { ChevronLeft, Star, Tag, Clock } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';
import { useToast } from '@/components/ui/use-toast';
import { initializeCheckout } from '@/api/EcommerceApi';

const CatalogDetailPage = () => {
    const { postId, catalogId } = useParams();
    const id = postId || catalogId;
    const { language } = useContext(LanguageContext);
    const { toast } = useToast();
    const t = catalogData[language] || catalogData.ar;
    const item = t.find(p => p.id === id);

    const getLink = (path) => {
        if (language === 'ar') return path;
        const langCode = language === 'zh' ? 'cn' : language;
        return `/${langCode}${path}`;
    };
    
    const handlePurchase = async () => {
        try {
            const successUrl = `${window.location.origin}${getLink('/order-confirmation')}?order_id=BKU-ORD-${Date.now()}&email=customer@example.com`;
            const cancelUrl = window.location.href;

            // This is a mocked item for purchase. In a real scenario, you'd use a variant ID.
            const checkoutData = await initializeCheckout({
                items: [{ variant_id: 'variant_mock_123', quantity: 1 }], 
                successUrl,
                cancelUrl,
                locale: language,
            });

            window.location.href = checkoutData.url;
        } catch (error) {
            console.error("Checkout initialization failed:", error);
            toast({
                title: "An Error Occurred",
                description: "Failed to start the checkout process. Please try again later.",
                variant: "destructive",
            });
        }
    };
    
    if (!item) {
        return <div className="text-center py-20">Product not found.</div>;
    }

    const AvailabilityBadge = ({ availability }) => {
        const styles = {
          InStock: 'bg-green-100 text-green-800',
          OutOfStock: 'bg-red-100 text-red-800',
          PreOrder: 'bg-yellow-100 text-yellow-800',
        };
        const text = {
            en: { InStock: 'In Stock', OutOfStock: 'Out of Stock', PreOrder: 'Pre-Order' },
            ar: { InStock: 'متوفر', OutOfStock: 'غير متوفر', PreOrder: 'طلب مسبق' },
            tr: { InStock: 'Stokta', OutOfStock: 'Stokta Yok', PreOrder: 'Ön Sipariş' },
            zh: { InStock: '有现货', OutOfStock: '缺货', PreOrder: '预购' },
        }
        return (
          <span className={`px-3 py-1 text-sm font-semibold rounded-full ${styles[availability] || 'bg-gray-100 text-gray-800'}`}>
            {text[language][availability] || availability}
          </span>
        );
    };

    const StarRating = ({ rating, count }) => (
        <div className="flex items-center">
            <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`h-5 w-5 ${i < Math.floor(rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                ))}
            </div>
            <span className="text-sm text-gray-600 ml-2">{`(${count} ${language === 'ar' ? 'مراجعات' : 'reviews'})`}</span>
        </div>
    );
    
    const productSchema = {
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": item.title,
        "image": item.image,
        "description": item.description,
        "sku": item.id,
        "mpn": item.id,
        "brand": {
          "@type": "Brand",
          "name": "BKU Crane"
        },
        ...(item.review && {
          "review": {
            "@type": "Review",
            "reviewRating": {
              "@type": "Rating",
              "ratingValue": item.review.rating,
              "bestRating": "5"
            },
            "author": {
              "@type": "Organization",
              "name": "BKU Crane"
            }
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": item.review.rating,
            "reviewCount": item.review.count
          }
        }),
        "offers": {
          "@type": "Offer",
          "url": `https://bku-website.online${getLink(`/catalog-sales/${item.id}`)}`,
          "priceCurrency": "KWD",
          "price": item.price.split(' ')[0],
          "priceValidUntil": item.priceValidUntil,
          "itemCondition": "https://schema.org/UsedCondition",
          "availability": `https://schema.org/${item.availability}`,
          "seller": {
            "@type": "Organization",
            "name": "BKU Crane"
          }
        }
    };


    return (
        <>
            <Helmet>
                <title>{item.title}</title>
                <meta name="description" content={item.description} />
                <script type="application/ld+json">{JSON.stringify(productSchema)}</script>
            </Helmet>
            <div className="container mx-auto px-4 py-12">
                <div className="mb-8">
                    <Link to={getLink("/catalog-sales")} className="text-gray-600 hover:text-red-600 transition-colors flex items-center">
                        <ChevronLeft className="h-5 w-5" />
                        <span className="ml-1">{language === 'ar' ? 'العودة إلى الكتالوج' : 'Back to Catalog'}</span>
                    </Link>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
                        <img src={item.image} alt={item.title} className="w-full h-auto rounded-lg shadow-lg" />
                    </motion.div>
                    <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{item.title}</h1>
                        <div className="flex items-center space-x-4 mb-4">
                           <AvailabilityBadge availability={item.availability} />
                           {item.review && <StarRating rating={item.review.rating} count={item.review.count} />}
                        </div>
                        <p className="text-gray-700 mb-6 leading-relaxed">{item.description}</p>
                        
                        <div className="bg-gray-100 p-6 rounded-lg mb-6">
                            <div className="flex items-center text-3xl font-bold text-red-600 mb-2">
                                <Tag className="h-8 w-8 mr-3"/>
                                {item.price}
                            </div>
                             <div className="flex items-center text-sm text-gray-500">
                                <Clock className="h-4 w-4 mr-1" />
                                <span>{language === 'ar' ? `السعر صالح حتى ${item.priceValidUntil}` : `Price valid until ${item.priceValidUntil}`}</span>
                            </div>
                        </div>

                        <Button onClick={handlePurchase} size="lg" className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 text-lg transition-transform transform hover:scale-105">
                            {language === 'ar' ? 'شراء الآن' : language === 'tr' ? 'Şimdi Satın Al' : language === 'zh' ? '立即购买' : 'Buy Now'}
                        </Button>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default CatalogDetailPage;