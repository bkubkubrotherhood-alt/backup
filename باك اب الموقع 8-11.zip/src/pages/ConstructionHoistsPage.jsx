import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LanguageContext } from '@/context/LanguageContext';
import ServiceRequestForm from '@/components/ServiceRequestForm';
import { Check } from 'lucide-react';
import WatermarkedImage from '@/components/WatermarkedImage';
import KeywordsCloud from '@/components/KeywordsCloud';

const ConstructionHoistsPage = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const getLink = (path) => {
    if (language === 'ar') return path;
    const langCode = language === 'zh' ? 'cn' : language;
    return `/${langCode}${path}`;
  };

  const content = {
    en: {
      meta: {
        title: "Construction Hoist SC200/200 for Sale & Rent in Kuwait",
        description: "High-performance SC200/200 passenger and material construction elevators for sale and rent. A reliable and safe choice for high-rise projects and any tower crane kuwait site.",
        keywords: `construction hoist Kuwait, passenger hoist Kuwait, construction elevator Kuwait, SC200/200 for sale, SC200/200 for rent, tower crane kuwait, material hoist, personnel hoist, vertical transport, high-rise construction, BKU Crane, heavy equipment Kuwait, BKU CRANE, tower crane kuwait, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      },
      header: {
        title: "SC200/200 Construction Hoist",
        subtitle: "Reliable & Efficient Vertical Transport for Your High-Rise Projects in Kuwait. The perfect companion for any tower crane kuwait.",
      },
      product: {
        imageAlt: "SC200/200 Construction Hoist with dual cages, installed on a building in Kuwait.",
        description: "The SC200/200 Construction Hoist is a state-of-the-art vertical transport solution, designed for both passengers and materials. With a robust 2-ton capacity per cage and advanced safety features, it ensures efficient and secure operation on any construction site. Ideal for high-rise buildings, this construction lifter is available for both sale and rental, making it a versatile choice for any tower crane kuwait project.",
      },
      features: {
        title: "Key Features",
        list: [
          "Dual cage design for increased efficiency",
          "Variable Frequency Drive (VFD) for smooth operation",
          "Advanced safety devices including overload protection",
          "Durable materials for long service life in harsh conditions",
          "Spacious cages for personnel and material transport"
        ],
      },
      specs: {
        title: "Technical Specifications",
        table: [
          { label: "Model", value: "SC200/200" },
          { label: "Cage", value: "Double" },
          { label: "Cage Inner Size (L*W*H)", value: "3.0*1.5*2.5 m" },
          { label: "Rated Load Capacity", value: "2000 kg per cage" },
          { label: "Lifting Speed", value: "0-36 m/min (with VFD)" },
          { label: "Mast Section Size", value: "650*650*1508 mm" },
          { label: "Motor Power", value: "2 * 3 * 11 kW" },
          { label: "Safety Device", value: "SAJ40-1.2 Overload Protector", },
        ],
      },
    },
    ar: {
      meta: {
        title: "مصعد إنشائي SC200/200 للبيع والإيجار في الكويت",
        description: "مصاعد إنشائية عالية الأداء طراز SC200/200 لنقل الأفراد والمواد، للبيع والإيجار. خيار موثوق وآمن للمشاريع الشاهقة وأي موقع تور كرين في الكويت.",
        keywords: `مصعد انشائي الكويت, مصعد ركاب الكويت, مصعد بناء, بيع SC200/200, ايجار SC200/200, تاور كرين الكويت, مصعد مواد, مصعد أفراد, نقل عمودي, بناء شاهق, BKU Crane, معدات ثقيلة الكويت, BKU CRANE, تاور كرين الكويت, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      },
      header: {
        title: "مصعد إنشائي SC200/200",
        subtitle: "حلول نقل رأسية موثوقة وفعالة لمشاريعك الشاهقة في الكويت. الرفيق المثالي لأي tower crane kuwait.",
      },
      product: {
        imageAlt: "مصعد إنشائي SC200/200 بقفصين، مثبت على مبنى في الكويت.",
        description: "يُعد المصعد الإنشائي SC200/200 حلاً متطورًا للنقل الرأسي، مصممًا لنقل الركاب والمواد على حد سواء. بفضل سعته القوية البالغة 2 طن لكل قفص وميزات السلامة المتقدمة، فإنه يضمن التشغيل الفعال والآمن في أي موقع بناء. مثالي للمباني الشاهقة، هذا المصعد الإنشائي متاح للبيع والإيجار، مما يجعله خيارًا متعدد الاستخدامات لأي مشروع tower crane kuwait.",
      },
       features: {
        title: "الميزات الرئيسية",
        list: [
          "تصميم قفص مزدوج لزيادة الكفاءة",
          "محرك متغير التردد (VFD) لتشغيل سلس",
          "أجهزة أمان متقدمة بما في ذلك الحماية من الحمل الزائد",
          "مواد متينة لعمر خدمة طويل في الظروف القاسية",
          "أقفاص واسعة لنقل الأفراد والمواد"
        ],
      },
      specs: {
        title: "المواصفات الفنية",
        table: [
          { label: "الموديل", value: "SC200/200" },
          { label: "القفص", value: "مزدوج" },
          { label: "الحجم الداخلي للقفص (ط*ع*ا)", value: "3.0*1.5*2.5 متر" },
          { label: "الحمولة المقدرة", value: "2000 كجم لكل قفص" },
          { label: "سرعة الرفع", value: "0-36 م/دقيقة (مع VFD)" },
          { label: "حجم قسم الصاري", value: "650*650*1508 مم" },
          { label: "قوة المحرك", value: "2 * 3 * 11 كيلوواط" },
          { label: "جهاز الأمان", value: "SAJ40-1.2 مع حماية من الحمل الزائد" },
        ],
      },
    },
    zh: {
      meta: {
        title: "科威特SC200/200施工升降机销售与租赁",
        description: "高性能SC200/200乘客和材料施工升降机出售和租赁。是高层项目和任何科威特塔式起重机工地的可靠安全选择。",
        keywords: `科威特施工升降机, 乘客升降机, 施工电梯, SC200/200出售, SC200/200租赁, 科威特塔式起重机, 材料升降机, 人员升降机, 垂直运输, 高层建筑, BKU Crane, 科威特重型设备, BKU CRANE, tower crane kuwait, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机`,
      },
      header: {
        title: "SC200/200 施工升降机",
        subtitle: "为您的科威特高层项目提供可靠高效的垂直运输。任何科威特塔式起重机的完美伴侣。",
      },
      product: {
        imageAlt: "安装在科威特一栋建筑上的带有双笼的SC200/200施工升降机。",
        description: "SC200/200施工升降机是一种最先进的垂直运输解决方案，专为乘客和材料设计。每个吊笼具有强大的2吨容量和先进的安全功能，确保在任何建筑工地上都能高效安全地运行。这款施工升降机非常适合高层建筑，在科威特可供销售和租赁，是任何科威特塔式起重机项目的多功能选择。",
      },
       features: {
        title: "主要特点",
        list: [
          "双笼设计，提高效率",
          "变频驱动 (VFD)，运行平稳",
          "先进的安全装置，包括过载保护",
          "耐用材料，可在恶劣条件下长期使用",
          "宽敞的吊笼，便于人员和物料运输"
        ],
      },
      specs: {
        title: "技术规格",
        table: [
          { label: "型号", value: "SC200/200" },
          { label: "吊笼", value: "双笼" },
          { label: "吊笼内部尺寸（长*宽*高）", value: "3.0*1.5*2.5 米" },
          { label: "额定载重量", value: "每个吊笼2000公斤" },
          { label: "提升速度", value: "0-36 米/分钟 (带变频器)" },
          { label: "标准节尺寸", value: "650*650*1508 毫米" },
          { label: "电机功率", value: "2 * 3 * 11 千瓦" },
          { label: "安全装置", value: "SAJ40-1.2 过载保护器" },
        ],
      },
    },
    tr: {
      meta: {
        title: "Kuveyt'te Satılık ve Kiralık İnşaat Asansörü SC200/200",
        description: "Yüksek performanslı SC200/200 yolcu ve malzeme inşaat asansörleri satılık ve kiralıktır. Yüksek katlı projeler ve her türlü kule vinç Kuveyt şantiyesi için güvenilir ve emniyetli bir seçimdir.",
        keywords: `inşaat asansörü Kuveyt, yolcu asansörü Kuveyt, inşaat asansörü, satılık SC200/200, kiralık SC200/200, kule vinç kuveyt, malzeme asansörü, personel asansörü, dikey taşıma, yüksek katlı inşaat, BKU Crane, ağır ekipman Kuveyt, BKU CRANE, kule vinç Kuveyt, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur`,
      },
      header: {
        title: "SC200/200 İnşaat Asansörü",
        subtitle: "Kuveyt'teki Yüksek Katlı Projeleriniz İçin Güvenilir ve Verimli Dikey Taşıma. Her türlü kule vinç kuveyt için mükemmel bir arkadaştır.",
      },
      product: {
        imageAlt: "Kuveyt'te bir binaya monte edilmiş çift kafesli SC200/200 İnşaat Asansörü.",
        description: "SC200/200 İnşaat Asansörü, hem yolcular hem de malzemeler için tasarlanmış son teknoloji bir dikey taşıma çözümüdür. Her kafes için 2 tonluk sağlam kapasitesi ve gelişmiş güvenlik özellikleriyle, her inşaat sahasında verimli ve güvenli çalışma sağlar. Yüksek katlı binalar için ideal olan bu inşaat asansörü hem satılık hem de kiralıktır, bu da onu her türlü kule vinç Kuveyt projesi için çok yönlü bir seçenek haline getirir.",
      },
      features: {
        title: "Ana Özellikler",
        list: [
          "Artan verimlilik için çift kafes tasarımı",
          "Düzgün çalışma için Değişken Frekanslı Sürücü (VFD)",
          "Aşırı yük koruması dahil gelişmiş güvenlik cihazları",
          "Zorlu koşullarda uzun hizmet ömrü için dayanıklı malzemeler",
          "Personel ve malzeme taşımacılığı için geniş kafesler"
        ],
      },
      specs: {
        title: "Teknik Özellikler",
        table: [
          { label: "Model", value: "SC200/200" },
          { label: "Kafes", value: "Çift" },
          { label: "Kafes İç Ölçüsü (U*G*Y)", value: "3.0*1.5*2.5 m" },
          { label: "Nominal Yük Kapasitesi", value: "Her kafes için 2000 kg" },
          { label: "Kaldırma Hızı", value: "0-36 m/dak (VFD ile)" },
          { label: "Mast Bölüm Boyutu", value: "650*650*1508 mm" },
          { label: "Motor Gücü", value: "2 * 3 * 11 kW" },
          { label: "Güvenlik Cihazı", value: "SAJ40-1.2 Aşırı Yük Koruyucu", },
        ],
      },
    },
  };

  const t = content[language] || content.en;

  const productSchema = {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": "SC200/200 Construction Hoist",
    "image": "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/e7477820e533bee2d13a13d34b1dd302.jpg",
    "description": t.meta.description,
    "brand": {
      "@type": "Brand",
      "name": "BKU"
    },
    "sku": "SC200-200",
    "mpn": "SC200-200",
    "item_group_id": "construction-hoists",
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "54"
    },
    "offers": {
      "@type": "AggregateOffer",
      "priceCurrency": "KWD",
      "lowPrice": "1000",
      "highPrice": "5000",
      "offerCount": "2",
      "offers": [
        {
          "@type": "Offer",
          "name": "Construction Hoist Rental in Kuwait",
          "url": `https://bku-website.online${getLink('/equipment/construction-hoists')}`,
          "availability": "https://schema.org/InStock",
          "seller": {
            "@type": "Organization",
            "name": "BKU Crane"
          }
        },
        {
          "@type": "Offer",
          "name": "Construction Hoist for Sale in Kuwait",
          "url": `https://bku-website.online${getLink('/equipment/construction-hoists')}`,
          "availability": "https://schema.org/InStock",
          "seller": {
            "@type": "Organization",
            "name": "BKU Crane"
          }
        }
      ]
    },
    "additionalProperty": t.specs.table.map(spec => ({
      "@type": "PropertyValue",
      "name": spec.label,
      "value": spec.value
    }))
  };

  return (
    <>
      <Helmet>
        <title>{t.meta.title}</title>
        <meta name="description" content={t.meta.description} />
        <meta name="keywords" content={t.meta.keywords} />
        <link rel="canonical" href={`https://bku-website.online${getLink('/equipment/construction-hoists')}`} />
        <meta property="og:title" content={t.meta.title} />
        <meta property="og:description" content={t.meta.description} />
        <meta property="og:url" content={`https://bku-website.online${getLink('/equipment/construction-hoists')}`} />
        <meta property="og:type" content="product" />
        <meta property="og:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/e7477820e533bee2d13a13d34b1dd302.jpg" />
        <meta property="og:image:alt" content={t.product.imageAlt} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={t.meta.title} />
        <meta name="twitter:description" content={t.meta.description} />
        <meta name="twitter:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/e7477820e533bee2d13a13d34b1dd302.jpg" />
        <script type="application/ld+json">{JSON.stringify(productSchema)}</script>
      </Helmet>
      <div dir={isRtl ? 'rtl' : 'ltr'}>
        <section className="relative py-20 sm:py-32 bg-gray-800 text-white overflow-hidden">
           <div className="absolute inset-0">
             <img src="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/e7477820e533bee2d13a13d34b1dd302.jpg" alt={t.product.imageAlt} className="w-full h-full object-cover opacity-20"/>
             <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
           </div>
           <div className="relative container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <h1 className="text-4xl md:text-5xl font-extrabold">{t.header.title}</h1>
              <h2 className="mt-4 text-lg text-gray-300 max-w-3xl mx-auto">{t.header.subtitle}</h2>
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <motion.div
                initial={{ opacity: 0, x: isRtl ? 50 : -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="space-y-8"
              >
                <div className="rounded-lg overflow-hidden shadow-xl aspect-square">
                    <WatermarkedImage 
                        src="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/e7477820e533bee2d13a13d34b1dd302.jpg" 
                        alt={t.product.imageAlt}
                    />
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-gray-800">{t.features.title}</h2>
                  <p className="text-gray-600 mt-4">{t.product.description}</p>
                 </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: isRtl ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="space-y-8"
              >
                 <ul className="space-y-3 p-6 bg-gray-50 rounded-lg shadow-inner">
                    {t.features.list.map((feature, index) => (
                        <li key={index} className="flex items-center text-gray-700 font-medium">
                            <Check className="h-5 w-5 text-green-500 mr-3 rtl:ml-3 flex-shrink-0"/>
                            <span>{feature}</span>
                        </li>
                      ))}
                 </ul>
                <div>
                    <h2 className="text-3xl font-bold text-gray-800 mb-4">{t.specs.title}</h2>
                    <div className="overflow-x-auto shadow-md rounded-lg">
                      <table className="w-full text-sm text-left text-gray-500">
                        <tbody className="divide-y divide-gray-200">
                          {t.specs.table.map((spec, index) => (
                            <tr key={index} className="bg-white hover:bg-gray-50">
                              <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                {spec.label}
                              </th>
                              <td className="px-6 py-4">{spec.value}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
        
        <ServiceRequestForm serviceTitle={t.header.title} />
        <KeywordsCloud />
      </div>
    </>
  );
};

export default ConstructionHoistsPage;