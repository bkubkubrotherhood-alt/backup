import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '@/context/LanguageContext';

const StoreLocatorPage = () => {
  const { language } = useContext(LanguageContext);

  const content = {
    en: {
      title: "Our Locations | BKU Crane Map",
      description: "View BKU Crane's main location on the map. Get directions and find us easily.",
      pageTitle: "Our Location",
      pageSubtitle: "Find us on the map.",
      keywords: "bku crane location, tower crane kuwait office, find bku, tower crane Kuwait, tower crane Kuwait, tower crane Kuwait"
    },
    ar: {
      title: "مواقعنا | خريطة شركة الاخوة الكويتية المتحدة",
      description: "شاهد مواقع شركة الاخوة الكويتية المتحدة على الخريطة. احصل على الاتجاهات وتجدنا بسهولة.",
      pageTitle: "موقعنا",
      pageSubtitle: "تجدنا على الخريطة.",
      keywords: "موقع شركة الاخوة الكويتية المتحدة, مكتب تاور كرين الكويت, عنوان bku, tower crane Kuwait, tower crane Kuwait, tower crane Kuwait"
    },
    zh: {
      title: "我们的位置 | BKU起重机地图",
      description: "在地图上查看BKU起重机的主要位置。获取路线并轻松找到我们。",
      pageTitle: "我们的位置",
      pageSubtitle: "在地图上找到我们。",
      keywords: "bku起重机位置, 科威特塔式起重机办公室, 查找bku, 科威特塔式起重机, 科威特塔式起重机, 科威特塔式起重机"
    },
    tr: {
      title: "Konumlarımız | BKU Vinç Haritası",
      description: "BKU Vinç'in ana konumunu haritada görüntüleyin. Yol tarifi alın ve bizi kolayca bulun.",
      pageTitle: "Konumumuz",
      pageSubtitle: "Bizi haritada bulun.",
      keywords: "bku vinç konumu, kuveyt kule vinç ofisi, bku bul, kule vinç Kuveyt"
    }
  };

  const t = content[language] || content.en;

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.description} />
        <meta name="keywords" content={t.keywords} />
        <link rel="canonical" href="https://www.bkucrane.com/store-locator" />
        <meta property="og:title" content={t.title} />
        <meta property="og:description" content={t.description} />
        <meta property="og:url" content="https://www.bkucrane.com/store-locator" />
      </Helmet>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">
            {t.pageTitle}
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl">
            {t.pageSubtitle}
          </p>
        </div>
        <div className="w-full h-[70vh] min-h-[500px] rounded-lg shadow-xl overflow-hidden">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3478.036949451018!2d48.0168628151001!3d29.34106258214418!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjnCsDIwJzI3LjgiTiA0OMKwMDEnMDkuOSJF!5e0!3m2!1sen!2skw!4v1672527000000"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Google Map of Hawally"
          ></iframe>
        </div>
      </div>
    </>
  );
};

export default StoreLocatorPage;