import React, { useState, useContext, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { LanguageContext } from '@/context/LanguageContext';
import { towerCranesData } from '@/lib/towerCranesData.js';
import { Weight, GitCommitHorizontal, Milestone, Search, Star, Tag } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

const TowerCranesPage = () => {
    const { language } = useContext(LanguageContext);
    const isRtl = language === 'ar';

    const [searchTerm, setSearchTerm] = useState('');
    const [selectedBrands, setSelectedBrands] = useState(['All']);
    const [selectedCapacities, setSelectedCapacities] = useState([]);
    const [selectedHeights, setSelectedHeights] = useState([]);

    const t = useMemo(() => ({
        en: {
            title: 'Tower Cranes in Kuwait | For Sale & Rent | BKU',
            description: 'Explore our full range of Liebherr, Potain, and Zoomlion tower cranes. Find the perfect construction crane for sale or rent in Kuwait for your project. Get the best tower crane price from the best tower crane kuwait company.',
            keywords: "tower cranes Kuwait, tower crane for sale, rental tower crane, liebherr tower crane, potain tower crane, zoomlion tower crane, construction crane, tower crane price, tower crane kuwait",
            subtitle: 'Explore our high-performance tower cranes. We are your number one choice for tower crane kuwait.',
            searchPlaceholder: 'Type equipment name...',
            brandsFilter: 'Brands Filter',
            capacityFilter: 'Max Lifting Capacity',
            heightFilter: 'Free Standing Height',
            all: 'All',
            details: 'View Details',
            inStock: 'In Stock',
            outOfStock: 'Out of Stock',
            preOrder: 'Pre-Order',
            currency: 'KWD',
        },
        ar: {
            title: 'تاور كرين للبيع والإيجار في الكويت | BKU',
            description: 'استكشف مجموعتنا الكاملة من الرافعات البرجية Liebherr و Potain و Zoomlion. اعثر على رافعة البناء المثالية للبيع أو للايجار في الكويت لمشروعك. احصل على أفضل سعر تور كرين.',
            keywords: "تاور كرين الكويت, تور كرين للبيع, للايجار رافعة برجية, رافعات Liebherr, رافعات Potain, رافعات Zoomlion, سعر الرافعة البرجية, أنواع الرافعات البرجية, tower crane kuwait",
            subtitle: 'استكشف مجموعتنا من الرافعات البرجية عالية الأداء. نحن خيارك الأول لـ tower crane kuwait.',
            searchPlaceholder: 'اكتب اسم المعدة...',
            brandsFilter: 'فلتر الماركات',
            capacityFilter: 'قدرة الرفع القصوى',
            heightFilter: 'ارتفاع قائم بذاته',
            all: 'الكل',
            details: 'عرض التفاصيل',
            inStock: 'متوفر',
            outOfStock: 'غير متوفر',
            preOrder: 'طلب مسبق',
            currency: 'د.ك',
        },
        tr: {
            title: 'Kuveyt Kule Vinç | Satılık & Kiralık | BKU',
            description: 'Liebherr, Potain ve Zoomlion\'dan oluşan tüm kule vinç yelpazemizi keşfedin. Projeniz için Kuveyt\'te satılık veya kiralık mükemmel inşaat vincini bulun. En iyi kule vinç fiyatını alın.',
            keywords: "kuveyt kule vinç, satılık kule vinç, kiralık kule vinç, liebherr kule vinç, potain kule vinç, zoomlion kule vinç, inşaat vinci, kule vinç fiyatı, tower crane kuwait",
            subtitle: 'Yüksek performanslı kule vinçlerimizi keşfedin. Kuveyt kule vinç için bir numaralı tercihiniz biziz.',
            searchPlaceholder: 'Ekipman adı yazın...',
            brandsFilter: 'Marka Filtresi',
            capacityFilter: 'Maks. Kaldırma Kapasitesi',
            heightFilter: 'Serbest Durma Yüksekliği',
            all: 'Tümü',
            details: 'Detayları Görüntüle',
            inStock: 'Stokta',
            outOfStock: 'Stokta Yok',
            preOrder: 'Ön Sipariş',
            currency: 'KWD',
        },
        zh: {
            title: '科威特塔式起重机 | 销售与租赁 | BKU',
            description: '探索我们全系列的利勃海尔、波坦和中联重科塔式起重机。为您的项目在科威特找到完美的建筑起重机销售或租赁。获取最佳塔式起重机价格。',
            keywords: "科威特塔式起重机, 待售塔式起重机, 租赁塔式起重机, 利勃海尔塔式起重机, 波坦塔式起重机, 中联重科塔式起重机, 建筑起重机, 塔式起重机价格, tower crane kuwait",
            subtitle: '探索我们的高性能塔式起重机。我们是您在科威特塔式起重机领域的首选。',
            searchPlaceholder: '输入设备名称...',
            brandsFilter: '品牌筛选',
            capacityFilter: '最大起重能力',
            heightFilter: '自由站立高度',
            all: '全部',
            details: '查看详情',
            inStock: '有现货',
            outOfStock: '缺货',
            preOrder: '预购',
            currency: 'KWD',
        },
    }[language] || 'en'), [language]);
    
    const cranes = towerCranesData[language] || towerCranesData.en;
    const brands = useMemo(() => ['Liebherr', 'Potain', 'Zoomlion'], []);
    const capacities = useMemo(() => ['< 10 T', '10-16 T', '> 16 T'], []);
    const heights = useMemo(() => ['< 45 m', '45-55 m', '> 55 m'], []);

    const getLink = (path) => {
        if (language === 'ar') return path;
        const langCode = language === 'zh' ? 'cn' : language;
        return `/${langCode}${path}`;
    };

    const handleBrandClick = (brand) => {
        setSelectedBrands([brand]);
    };

    const handleCapacityChange = (capacity) => {
        setSelectedCapacities(prev => 
            prev.includes(capacity) 
            ? prev.filter(c => c !== capacity) 
            : [...prev, capacity]
        );
    };

    const handleHeightChange = (height) => {
        setSelectedHeights(prev => 
            prev.includes(height) 
            ? prev.filter(h => h !== height) 
            : [...prev, height]
        );
    };

    const parseCapacity = (crane) => {
        const capacityString = crane.capacity || '';
        const match = capacityString.match(/(\d+)/);
        return match ? parseInt(match[1], 10) : 0;
    };

    const parseHeight = (crane) => {
        const heightString = crane.height || '';
        const match = heightString.match(/(\d+)/);
        return match ? parseInt(match[1], 10) : 0;
    };

    const filteredCranes = useMemo(() => {
        if (!cranes) return [];
        return cranes.filter(crane => {
            const model = crane.model || '';
            const matchesSearch = model.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesBrand = selectedBrands.includes('All') || selectedBrands.some(b => (crane.brand || '').toLowerCase().includes(b.toLowerCase()));
            
            const capacity = parseCapacity(crane);
            const matchesCapacity = selectedCapacities.length === 0 || selectedCapacities.some(c => {
                if (c === '< 10 T') return capacity < 10;
                if (c === '10-16 T') return capacity >= 10 && capacity <= 16;
                if (c === '> 16 T') return capacity > 16;
                return false;
            });

            const height = parseHeight(crane);
            const matchesHeight = selectedHeights.length === 0 || selectedHeights.some(h => {
                if (h === '< 45 m') return height < 45;
                if (h === '45-55 m') return height >= 45 && height <= 55;
                if (h === '> 55 m') return height > 55;
                return false;
            });

            return matchesSearch && matchesBrand && matchesCapacity && matchesHeight;
        });
    }, [cranes, searchTerm, selectedBrands, selectedCapacities, selectedHeights]);

    const generateProductSchema = (crane) => {
        const craneUrl = `https://bku-website.online${getLink(`/equipment/tower-cranes/${crane.id}`)}`;
        return {
            "@context": "https://schema.org/",
            "@type": "Product",
            "name": `${crane.brand} ${crane.model}`,
            "image": crane.image,
            "description": crane.description,
            "sku": crane.id,
            "mpn": crane.mpn,
            "brand": {
              "@type": "Brand",
              "name": crane.brand
            },
            ...(crane.review && {
              "review": {
                "@type": "Review",
                "reviewRating": {
                  "@type": "Rating",
                  "ratingValue": crane.review.rating,
                  "bestRating": "5"
                },
                "author": {
                  "@type": "Organization",
                  "name": "BKU Crane"
                }
              },
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": crane.review.rating,
                "reviewCount": crane.review.count
              }
            }),
            "offers": {
              "@type": "Offer",
              "url": craneUrl,
              "priceCurrency": crane.currency || "KWD",
              "price": crane.price,
              "priceValidUntil": crane.priceValidUntil,
              "itemCondition": "https://schema.org/UsedCondition",
              "availability": `https://schema.org/${crane.availability}`,
              "seller": {
                "@type": "Organization",
                "name": "BKU Crane"
              }
            }
        };
    };
    
    const AvailabilityBadge = ({ availability }) => {
        const styles = {
          InStock: 'bg-green-100 text-green-800',
          OutOfStock: 'bg-red-100 text-red-800',
          PreOrder: 'bg-yellow-100 text-yellow-800',
        };
        const text = {
            InStock: t.inStock,
            OutOfStock: t.outOfStock,
            PreOrder: t.preOrder,
        }
        return (
          <span className={`absolute top-2 right-2 px-2 py-1 text-xs font-semibold rounded-full ${styles[availability] || 'bg-gray-100 text-gray-800'}`}>
            {text[availability] || availability}
          </span>
        );
    };

    const StarRating = ({ rating, count }) => (
        <div className="flex items-center">
            <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`h-4 w-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                ))}
            </div>
            <span className="text-xs text-gray-500 mx-2">{`(${count})`}</span>
        </div>
    );

    return (
        <>
            <Helmet>
                <title>{t.title}</title>
                <meta name="description" content={t.description} />
                <meta name="keywords" content={t.keywords} />
                {cranes.map(crane => (
                    <script key={`schema-${crane.id}`} type="application/ld+json">
                        {JSON.stringify(generateProductSchema(crane))}
                    </script>
                ))}
            </Helmet>
            <div className="bg-gray-50 min-h-screen" dir={isRtl ? 'rtl' : 'ltr'}>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <div className="flex flex-col lg:flex-row gap-8">
                        {/* Filters Sidebar */}
                        <aside className="w-full lg:w-1/4 xl:w-1/5">
                            <Card className="p-6 shadow-sm sticky top-24">
                                <h3 className="text-lg font-bold mb-4">{t.brandsFilter}</h3>
                                <div className="flex flex-wrap gap-2 mb-6">
                                    <Button onClick={() => handleBrandClick('All')} variant={selectedBrands.includes('All') ? 'default' : 'outline'} size="sm" className={`rounded-full ${selectedBrands.includes('All') ? 'bg-red-600 text-white' : ''}`}>{t.all}</Button>
                                    {brands.map(brand => (
                                        <Button key={brand} onClick={() => handleBrandClick(brand)} variant={selectedBrands.includes(brand) ? 'default' : 'outline'} size="sm" className={`rounded-full ${selectedBrands.includes(brand) ? 'bg-red-600 text-white' : ''}`}>{brand}</Button>
                                    ))}
                                </div>

                                <h3 className="text-lg font-bold mb-4">{t.capacityFilter}</h3>
                                <div className="space-y-3 mb-6">
                                    {capacities.map(capacity => (
                                        <div key={capacity} className="flex items-center space-x-2 rtl:space-x-reverse">
                                            <Checkbox id={capacity} onCheckedChange={() => handleCapacityChange(capacity)} checked={selectedCapacities.includes(capacity)} className="rtl:ml-2"/>
                                            <label htmlFor={capacity} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{capacity}</label>
                                        </div>
                                    ))}
                                </div>

                                <h3 className="text-lg font-bold mb-4">{t.heightFilter}</h3>
                                <div className="space-y-3">
                                    {heights.map(height => (
                                        <div key={height} className="flex items-center space-x-2 rtl:space-x-reverse">
                                            <Checkbox id={height} onCheckedChange={() => handleHeightChange(height)} checked={selectedHeights.includes(height)} className="rtl:ml-2"/>
                                            <label htmlFor={height} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{height}</label>
                                        </div>
                                    ))}
                                </div>
                            </Card>
                        </aside>

                        {/* Main Content */}
                        <main className="w-full lg:w-3/4 xl:w-4/5">
                            <div className="relative mb-8">
                                <Search className="absolute top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" style={{ [isRtl ? 'right' : 'left']: '0.75rem' }} />
                                <Input
                                    type="text"
                                    placeholder={t.searchPlaceholder}
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className={`w-full rounded-full bg-white shadow-sm transition-all duration-300 focus:shadow-md focus:ring-2 focus:ring-red-300 ${isRtl ? 'pr-10' : 'pl-10'}`}
                                />
                            </div>

                            <motion.div
                                initial="hidden"
                                animate="visible"
                                variants={{
                                    visible: { transition: { staggerChildren: 0.05 } }
                                }}
                                className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                                {filteredCranes.map(crane => (
                                    <motion.div key={crane.id} variants={{hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 }}}>
                                        <Link to={getLink(`/equipment/tower-cranes/${crane.id}`)} className="block h-full">
                                            <Card className="h-full flex flex-col overflow-hidden group hover:shadow-xl transition-shadow duration-300">
                                                <div className="relative h-56 w-full overflow-hidden">
                                                    <img src={crane.image} alt={`Image of ${crane.model}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"/>
                                                    {crane.availability && <AvailabilityBadge availability={crane.availability} />}
                                                </div>
                                                <CardContent className="p-4 flex-grow flex flex-col">
                                                    <h3 className="text-lg font-bold text-gray-800 truncate">{crane.brand} {crane.model}</h3>
                                                    <div className="flex justify-between items-center my-2">
                                                        <div className="flex items-center text-lg font-bold text-red-600">
                                                          <Tag className={`w-4 h-4 text-red-500 ${isRtl ? 'ml-2' : 'mr-2'}`} />
                                                          {new Intl.NumberFormat(isRtl ? 'ar-KW' : 'en-US').format(crane.price)} {t.currency}
                                                        </div>
                                                        {crane.review && <StarRating rating={crane.review.rating} count={crane.review.count} />}
                                                    </div>
                                                    <p className="text-xs text-gray-500 mb-3">{crane.category}</p>
                                                    
                                                    <div className="space-y-2 my-2 text-left text-sm text-gray-600 flex-grow">
                                                      <div className="flex items-center"><Weight className={`w-4 h-4 text-gray-500 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {isRtl ? `الحمولة: ${crane.capacity}` : `Capacity: ${crane.capacity}`}</div>
                                                      <div className="flex items-center"><GitCommitHorizontal className={`w-4 h-4 text-gray-500 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {isRtl ? `طول الذراع: ${crane.jibLength}` : `Jib: ${crane.jibLength}`}</div>
                                                      <div className="flex items-center"><Milestone className={`w-4 h-4 text-gray-500 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {isRtl ? `الارتفاع: ${crane.height}` : `Height: ${crane.height}`}</div>
                                                    </div>

                                                    <div className="mt-auto pt-4 border-t">
                                                      <Button className="w-full bg-red-600 hover:bg-red-700 text-white font-bold">
                                                          {t.details}
                                                      </Button>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        </Link>
                                    </motion.div>
                                ))}
                            </motion.div>
                            {filteredCranes.length === 0 && (
                                <div className="text-center py-16 text-gray-500">
                                    <p className="text-lg">{isRtl ? 'لا توجد رافعات تطابق معاييرك.' : 'No cranes match your criteria.'}</p>
                                    <p>{isRtl ? 'جرّب تعديل بحثك أو الفلاتر.' : 'Try adjusting your search or filters.'}</p>
                                </div>
                            )}
                        </main>
                    </div>
                </div>
            </div>
        </>
    );
};

export default TowerCranesPage;