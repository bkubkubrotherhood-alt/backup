
import React, { useState, useMemo, useContext } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { blogData } from '@/lib/blogData.js';
import { Input } from '@/components/ui/input';
import { Search, ArrowRight, ArrowLeft } from 'lucide-react';
import KeywordsCloud from '@/components/KeywordsCloud';
import { LanguageContext } from '@/context/LanguageContext';

const BlogPage = () => {
  const { language } = useContext(LanguageContext);
  const [searchTerm, setSearchTerm] = useState('');
  
  const tContent = {
      en: {
        title: "BKU Crane Blog - Insights & News on Tower Cranes in Kuwait",
        metaDescription: "Stay updated with the latest news, expert insights, and project showcases on tower cranes, construction hoists, and lifting solutions in Kuwait from BKU Crane. Best tower crane kuwait.",
        heroTitle: "Insights, Innovations & Industry Updates",
        heroSubtitle: "Your #1 source for the latest in lifting technology and construction trends. We are the best in tower crane kuwait.",
        readMore: "Read More",
        searchPlaceholder: "Search for articles on tower crane kuwait...",
        keywords: `tower crane kuwait blog, kuwait construction news, Liebherr news, Potain news, bku crane news, tower crane kuwait, construction hoists Kuwait, lifting solutions Kuwait, heavy equipment blog, construction industry insights, project showcases, crane technology, safety in construction, Liebherr, Potain, Zoomlion, Yongmao, crane rental Kuwait, crane sales Kuwait`,
      },
      ar: {
        title: "مدونة BKU Crane - رؤى وأخبار حول الرافعات البرجية في الكويت",
        metaDescription: "ابق على اطلاع بآخر الأخبار والرؤى المتخصصة وعروض المشاريع حول الرافعات البرجية ومصاعد البناء وحلول الرفع في الكويت من BKU Crane. أفضل تاور كرين الكويت.",
        heroTitle: "رؤى، ابتكارات وتحديثات الصناعة",
        heroSubtitle: "مصدرك الأول لأحدث التقنيات في الرفع واتجاهات البناء. نحن الأفضل في مجال تاور كرين الكويت.",
        readMore: "اقرأ المزيد",
        searchPlaceholder: "ابحث عن مقالات حول تاور كرين الكويت...",
        noResults: "لم يتم العثور على مقالات تطابق بحثك.",
        keywords: `مدونة تاور كرين الكويت, أخبار البناء في الكويت, أخبار Liebherr, أخبار Potain, أخبار bku crane, تاور كرين الكويت, مصاعد بناء الكويت, حلول الرفع الكويت, مدونة معدات ثقيلة, رؤى صناعة البناء, عروض المشاريع, تكنولوجيا الرافعات, السلامة في البناء, Liebherr, Potain, Zoomlion, Yongmao, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت`,
      },
      tr: {
        title: "BKU Vinç Blogu - Kuveyt'teki Kule Vinçler Hakkında Bilgiler ve Haberler",
        metaDescription: "BKU Crane'den Kuveyt'teki kule vinçler, inşaat asansörleri ve kaldırma çözümleri hakkındaki en son haberler, uzman görüşleri ve proje vitrinleri ile güncel kalın. En iyi kule vinç Kuveyt.",
        heroTitle: "Görüşler, Yenilikler ve Sektör Güncellemeleri",
        heroSubtitle: "Kaldırma teknolojisi ve inşaat trendlerindeki en son gelişmeler için 1 numaralı kaynağınız. Kule vinç Kuveyt konusunda en iyisiyiz.",
        readMore: "Daha Fazla Oku",
        searchPlaceholder: "Kuveyt kule vinç hakkında makale ara...",
        noResults: "Aramanızla eşleşen makale bulunamadı.",
        keywords: `kule vinç kuveyt blogu, kuveyt inşaat haberleri, Liebherr haberleri, Potain haberleri, bku vinç haberleri, kule vinç kuveyt, inşaat asansörleri Kuveyt, kaldırma çözümleri Kuveyt, ağır ekipman blogu, inşaat sektörü analizleri, proje vitrinleri, vinç teknolojisi, inşaatta güvenlik, Liebherr, Potain, Zoomlion, Yongmao, kule vinç kiralama Kuveyt, kule vinç satışı Kuveyt`,
      },
      zh: {
        title: "BKU Crane博客 - 关于科威特塔式起重机的见解与新闻",
        metaDescription: "从BKU Crane获取科威特塔式起重机、施工升降机和起重解决方案的最新新闻、专家见解和项目展示。最佳科威特塔式起重机。",
        heroTitle: "见解、创新与行业更新",
        heroSubtitle: "您获取最新起重技术和建筑趋势的第一来源。我们是科威特塔式起重机领域的佼佼者。",
        readMore: "阅读更多",
        searchPlaceholder: "搜索关于科威特塔式起重机的文章...",
        noResults: "未找到与您搜索匹配的文章。",
        keywords: `科威特塔式起重机博客, 科威特建筑新闻, 利勃海尔新闻, 波坦新闻, bku crane新闻, 科威特塔式起重机, 施工升降机科威特, 起重解决方案科威特, 重型设备博客, 建筑行业见解, 项目展示, 起重机技术, 施工安全, 利勃海尔, 波坦, 中联重科, 永茂, 起重机租赁科威特, 起重机销售科威特`,
      }
  };

  const t = tContent[language] || tContent.en;
  const posts = useMemo(() => blogData[language] || blogData.en, [language]);
  const isRtl = language === 'ar';
  
  const getLink = (path) => {
    if (language === 'ar') return path;
    const langCode = language === 'zh' ? 'cn' : language;
    return `/${langCode}${path}`;
  };

  const filteredPosts = useMemo(() => {
    if (!posts) return [];
    return posts.filter(post =>
      (post.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (post.content || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (post.category || '').toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [posts, searchTerm]);
  
  const Arrow = isRtl ? ArrowLeft : ArrowRight;

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.metaDescription} />
        <meta name="keywords" content={t.keywords} />
      </Helmet>
      <div className="bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="container mx-auto px-4 py-16 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl sm:text-5xl font-extrabold text-gray-900 tracking-tight"
          >
            {t.heroTitle}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-4 max-w-2xl mx-auto text-lg text-gray-600"
          >
            {t.heroSubtitle}
          </motion.p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12" dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="mb-12 max-w-lg mx-auto">
          <div className="relative">
            <Input
              type="text"
              placeholder={t.searchPlaceholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`h-12 text-base ${isRtl ? 'pr-10' : 'pl-10'}`}
            />
            <Search className={`absolute top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400 ${isRtl ? 'right-3' : 'left-3'}`} />
          </div>
        </div>

        {filteredPosts.length > 0 ? (
          <div className="grid gap-8 lg:grid-cols-3 md:grid-cols-2">
            {filteredPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300"
              >
                <Link to={getLink(`/blog/${post.id}`)} className="block">
                  <div className="flex-shrink-0">
                    <img className="h-56 w-full object-cover" alt={post.imageAlt} src={post.image} />
                  </div>
                  <div className="flex flex-1 flex-col justify-between bg-white p-6">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-[#000080]">
                        {post.category}
                      </p>
                      <div className="mt-2 block">
                        <p className="text-xl font-semibold text-gray-900">{post.title}</p>
                        <p className="mt-3 text-base text-gray-500 line-clamp-3">{(post.content || '').replace(/###\s?\d\.\s/g, '').replace(/###/g, '').replace(/\*/g, '')}</p>
                      </div>
                    </div>
                    <div className="mt-6 flex items-center justify-between">
                      <div className="text-sm text-gray-500">
                        <time dateTime={post.datetime}>{post.date}</time>
                      </div>
                      <div className="text-sm font-semibold text-[#000080] hover:text-blue-700 flex items-center">
                        {t.readMore}
                        <Arrow className={`${isRtl ? 'mr-1' : 'ml-1'} h-4 w-4`} />
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-xl text-gray-500">{t.noResults}</p>
          </div>
        )}
      </div>
      <KeywordsCloud />
    </>
  );
};

export default BlogPage;
