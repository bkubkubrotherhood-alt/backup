import React, { useState, useRef, useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Truck, Mail, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import KeywordsCloud from '@/components/KeywordsCloud';
import { LanguageContext } from '@/context/LanguageContext';
import emailjs from '@emailjs/browser';

const LogisticsPage = () => {
  const { toast } = useToast();
  const formRef = useRef(null);
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const content = {
    en: {
      title: "Tower Crane Kuwait Logistics & Transport | BKU",
      subtitle: "We provide comprehensive logistics solutions for tower cranes throughout Kuwait, including transport, assembly, and disassembly. Request a quote for your tower crane kuwait project.",
      keywords: `crane logistics, crane transport, crane assembly, BKU logistics, tower crane in Kuwait, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, tower crane kuwait, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      form: {
        title: "Request Logistics Quote",
        companyName: "Company Name",
        name: "Your Name",
        email: "Email",
        phone: "Phone Number",
        serviceDetails: "Describe your logistics needs (e.g., crane model, location, timeline)",
        submit: "Send Request"
      },
      toastSuccess: "Logistics request sent successfully!",
      toastSuccessDesc: "We will contact you shortly with a quote.",
      toastError: "Error!",
      toastErrorDesc: "Failed to send request. Please try again later."
    },
    ar: {
      title: "خدمات لوجستيات ونقل تاور كرين الكويت | BKU",
      subtitle: "نقدم حلولًا لوجستية شاملة للرافعات البرجية في جميع أنحاء الكويت، بما في ذلك النقل والتجميع والتفكيك. اطلب عرض سعر لمشروعك الخاص بـ tower crane kuwait.",
      keywords: `لوجستيات الرافعات, نقل الرافعات, تجميع الرافعات, لوجستيات BKU, تاور كرين في الكويت, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, تاور كرين الكويت, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      form: {
        title: "اطلب عرض سعر للخدمات اللوجستية",
        companyName: "اسم الشركة",
        name: "الاسم",
        email: "البريد الإلكتروني",
        phone: "رقم الهاتف",
        serviceDetails: "صف احتياجاتك اللوجستية (مثال: موديل الرافعة، الموقع، الجدول الزمني)",
        submit: "إرسال الطلب"
      },
      toastSuccess: "تم إرسال طلب الخدمات اللوجستية بنجاح!",
      toastSuccessDesc: "سوف نتصل بك قريبا مع عرض أسعار.",
      toastError: "خطأ!",
      toastErrorDesc: "فشل إرسال الطلب. يرجى المحاولة مرة أخرى لاحقًا."
    },
    zh: {
        title: "科威特塔式起重机物流与运输 | BKU",
        subtitle: "我们为科威特各地的塔式起重机提供全面的物流解决方案，包括运输、组装和拆卸。为您的科威特塔式起重机项目索取报价。",
        keywords: `起重机物流, 起重机运输, 起重机组装, BKU物流, 科威特塔式起重机, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, tower crane kuwait, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机`,
        form: { title: "索取物流报价", companyName: "公司名称", name: "您的姓名", email: "电子邮件", phone: "电话号码", serviceDetails: "描述您的物流需求（例如，起重机型号、地点、时间表）", submit: "发送请求" },
        toastSuccess: "物流请求已成功发送！", toastSuccessDesc: "我们将很快与您联系并提供报价。", toastError: "错误！", toastErrorDesc: "发送请求失败。请稍后再试。"
    },
    tr: {
        title: "Kuveyt Kule Vinç Lojistik ve Nakliye | BKU",
        subtitle: "Kuveyt genelinde kule vinçler için nakliye, montaj ve demontaj dahil olmak üzere kapsamlı lojistik çözümleri sunuyoruz. Kuveyt kule vinç projeniz için bir teklif isteyin.",
        keywords: `vinç lojistiği, vinç nakliyesi, vinç montajı, BKU lojistik, Kuveyt'te kule vinç, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, BKU CRANE, kule vinç Kuveyt, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur`,
        form: { title: "Lojistik Teklifi İsteyin", companyName: "Şirket Adı", name: "Adınız", email: "E-posta", phone: "Telefon Numarası", serviceDetails: "Lojistik ihtiyaçlarınızı açıklayın (ör. vinç modeli, konum, zaman çizelgesi)", submit: "İstek Gönder" },
        toastSuccess: "Lojistik talebi başarıyla gönderildi!", toastSuccessDesc: "Size bir teklifle kısa süre içinde ulaşacağız.", toastError: "Hata!", toastErrorDesc: "İstek gönderilemedi. Lütfen daha sonra tekrar deneyin."
    }
  };

  const t = content[language] || content.en;
  
  const getLangPrefix = () => {
    if (language === 'ar') return '';
    if (language === 'zh') return '/cn';
    return `/${language}`;
  };
  const langPrefix = getLangPrefix();

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    emailjs.sendForm('service_gkl5ueg', 'template_vxo3769', formRef.current, 'aIV30VFPKcE2h5A_w')
      .then((result) => {
          toast({ title: t.toastSuccess, description: t.toastSuccessDesc });
          formRef.current.reset();
      }, (error) => {
          toast({ title: t.toastError, description: error.text || t.toastErrorDesc, variant: 'destructive' });
      })
      .finally(() => {
        setIsSubmitting(false);
      });
  };

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "Tower Crane Logistics",
    "provider": { "@type": "Organization", "name": "BKU Crane" },
    "areaServed": "Kuwait",
    "description": t.subtitle,
    "name": t.title
  };

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.subtitle} />
        <meta name="keywords" content={t.keywords} />
        <link rel="canonical" href={`https://bku-website.online${langPrefix}/services/logistics`} />
        <meta property="og:title" content={t.title} />
        <meta property="og:description" content={t.subtitle} />
        <meta property="og:url" content={`https://bku-website.online${langPrefix}/services/logistics`} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/9e6340c0458397ac6075f5c653642a14.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify(serviceSchema)}</script>
      </Helmet>
      <div className="bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
      <section className="container mx-auto px-4 py-16 sm:py-24">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <div className="inline-block bg-blue-100 text-blue-800 p-4 rounded-full mb-4">
              <Truck className="h-10 w-10" />
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800">{t.title}</h1>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">{t.subtitle}</p>
        </motion.div>
        <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
            >
                 <img alt="Crane cabin and boom parts loaded on a flatbed truck, ready for transport." className="rounded-lg shadow-xl w-full h-auto object-cover" src="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/9e6340c0458397ac6075f5c653642a14.jpg" />
            </motion.div>
            <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="bg-white p-8 rounded-lg shadow-2xl"
            >
            <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">{t.form.title}</h3>
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="from_name" className="block text-sm font-medium text-gray-700 mb-1">{t.form.name}</label>
                  <Input id="from_name" name="from_name" type="text" placeholder={t.form.name} required />
                </div>
                <div>
                  <label htmlFor="company_name" className="block text-sm font-medium text-gray-700 mb-1">{t.form.companyName}</label>
                  <Input id="company_name" name="company_name" type="text" placeholder={t.form.companyName} />
                </div>
                <div>
                  <label htmlFor="from_email" className="block text-sm font-medium text-gray-700 mb-1">{t.form.email}</label>
                  <Input id="from_email" name="from_email" type="email" placeholder={t.form.email} required />
                </div>
                <div>
                  <label htmlFor="from_phone" className="block text-sm font-medium text-gray-700 mb-1">{t.form.phone}</label>
                  <Input id="from_phone" name="from_phone" type="tel" placeholder={t.form.phone} />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">{t.form.serviceDetails}</label>
                  <Textarea id="message" name="message" placeholder={t.form.serviceDetails} rows={5} required />
                </div>
                <div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Mail className="mr-2 h-5 w-5" />}
                    {isSubmitting ? (language === 'ar' ? 'جاري الإرسال...' : 'Submitting...') : t.form.submit}
                </Button>
                </div>
            </form>
            </motion.div>
        </div>
      </section>
      </div>
      <KeywordsCloud />
    </>
  );
};

export default LogisticsPage;