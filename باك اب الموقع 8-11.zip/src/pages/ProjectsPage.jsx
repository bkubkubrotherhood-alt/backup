import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LanguageContext } from '@/context/LanguageContext';
import KeywordsCloud from '@/components/KeywordsCloud';

const ProjectsPage = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const projectsContent = {
    en: {
      title: "Our Projects | BKU Tower Crane Kuwait Portfolio",
      subtitle: "Discover the key projects where BKU's tower cranes have played a crucial role in shaping Kuwait's skyline. Every project is a tower crane kuwait success story.",
      keywords: `BKU projects, tower crane Kuwait projects, construction portfolio, Kuwait airport T2, Al Zour refinery, Hessah AlMubarak, BKU CRANE, tower crane kuwait, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      projects: [
        { id: 1, name: "Kuwait International Airport - T2", description: "Provided a fleet of Liebherr and Potain tower cranes for the construction of the new terminal, a landmark tower crane kuwait project.", image: "https://images.unsplash.com/photo-1569154941061-e231b4725ef1?q=80&w=2070&auto=format&fit=crop" },
        { id: 2, name: "Al Zour Refinery", description: "Supplied specialized heavy-lifting solutions, including high-capacity tower cranes, for one of the largest refineries in the region, a major tower crane kuwait undertaking.", image: "https://images.unsplash.com/photo-1555848132-eb2c6eeb261c?q=80&w=2070&auto=format&fit=crop" },
        { id: 3, name: "Hessah AlMubarak District", description: "Our tower cranes are instrumental in building this modern, mixed-use urban development. A top tower crane kuwait showcase.", image: "https://images.unsplash.com/photo-1519817914152-22d216bb9170?q=80&w=2070&auto=format&fit=crop" },
        { id: 4, name: "Kuwait University - Sabah Al-Salem University City", description: "Deployed a large number of tower cranes to support the construction of various faculties and facilities, proving our capacity for large-scale tower crane kuwait operations.", image: "https://images.unsplash.com/photo-1630856169381-257a78a8ea98?q=80&w=2070&auto=format&fit=crop" },
      ],
    },
    ar: {
      title: "مشاريعنا | معرض أعمال تاور كرين الكويت من BKU",
      subtitle: "اكتشف المشاريع الرئيسية التي لعبت فيها رافعات BKU البرجية دورًا حاسمًا في تشكيل أفق الكويت. كل مشروع تاور كرين الكويت هو قصة نجاح.",
      keywords: `مشاريع BKU, مشاريع تاور كرين الكويت, معرض أعمال البناء, مطار الكويت T2, مصفاة الزور, ضاحية حصة المبارك, BKU CRANE, تاور كرين الكويت, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
      projects: [
        { id: 1, name: "مطار الكويت الدولي - T2", description: "توفير أسطول من رافعات Liebherr و Potain البرجية لبناء المبنى الجديد، وهو مشروع رائد في مجال tower crane kuwait.", image: "https://images.unsplash.com/photo-1569154941061-e231b4725ef1?q=80&w=2070&auto=format&fit=crop" },
        { id: 2, name: "مصفاة الزور", description: "توفير حلول رفع ثقيلة متخصصة، بما في ذلك رافعات برجية عالية السعة، لواحدة من أكبر المصافي في المنطقة، وهو مشروع كبير لـ tower crane kuwait.", image: "https://images.unsplash.com/photo-1555848132-eb2c6eeb261c?q=80&w=2070&auto=format&fit=crop" },
        { id: 3, name: "ضاحية حصة المبارك", description: "تلعب رافعاتنا البرجية دورًا أساسيًا في بناء هذا المشروع الحضري الحديث متعدد الاستخدامات. عرض رائع لـ tower crane kuwait.", image: "https://images.unsplash.com/photo-1519817914152-22d216bb9170?q=80&w=2070&auto=format&fit=crop" },
        { id: 4, name: "جامعة الكويت - مدينة صباح السالم الجامعية", description: "نشر عدد كبير من الرافعات البرجية لدعم بناء مختلف الكليات والمرافق، مما يثبت قدرتنا على عمليات tower crane kuwait واسعة النطاق.", image: "https://images.unsplash.com/photo-1630856169381-257a78a8ea98?q=80&w=2070&auto=format&fit=crop" },
      ],
    },
    zh: {
      title: "我们的项目 | BKU科威特塔式起重机项目集",
      subtitle: "探索BKU塔式起重机在塑造科威特天际线中发挥关键作用的重点项目。每个项目都是科威特塔式起重机的成功案例。",
      keywords: `BKU项目, 科威特塔式起重机项目, 建筑作品集, 科威特机场T2, Al Zour炼油厂, Hessah AlMubarak, BKU CRANE, tower crane kuwait, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机`,
      projects: [
        { id: 1, name: "科威特国际机场 - T2", description: "为新航站楼的建设提供了一批利勃海尔和波坦塔式起重机，这是一个具有里程碑意义的科威特塔式起重机项目。", image: "https://images.unsplash.com/photo-1569154941061-e231b4725ef1?q=80&w=2070&auto=format&fit=crop" },
        { id: 2, name: "Al Zour炼油厂", description: "为该地区最大的炼油厂之一提供了专业的重型起重解决方案，包括高容量塔式起重机，这是一项重大的科威特塔式起重机工程。", image: "https://images.unsplash.com/photo-1555848132-eb2c6eeb261c?q=80&w=2070&auto=format&fit=crop" },
        { id: 3, name: "Hessah AlMubarak区", description: "我们的塔式起重机在这个现代化的多功能城市开发项目中发挥着重要作用。一个顶级的科威特塔式起重机展示。", image: "https://images.unsplash.com/photo-1519817914152-22d216bb9170?q=80&w=2070&auto=format&fit=crop" },
        { id: 4, name: "科威特大学 - Sabah Al-Salem大学城", description: "部署了大量塔式起重机，以支持各院系和设施的建设，证明了我们进行大规模科威特塔式起重机作业的能力。", image: "https://images.unsplash.com/photo-1630856169381-257a78a8ea98?q=80&w=2070&auto=format&fit=crop" },
      ],
    },
    tr: {
      title: "Projelerimiz | BKU Kuveyt Kule Vinç Portföyü",
      subtitle: "BKU'nun kule vinçlerinin Kuveyt'in siluetini şekillendirmede önemli bir rol oynadığı kilit projeleri keşfedin. Her proje bir kule vinç Kuveyt başarı öyküsüdür.",
      keywords: `BKU projeleri, kule vinç Kuveyt projeleri, inşaat portföyü, Kuveyt havalimanı T2, Al Zour rafinerisi, Hessah AlMubarak, BKU CRANE, kule vinç Kuveyt, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur`,
      projects: [
        { id: 1, name: "Kuveyt Uluslararası Havalimanı - T2", description: "Yeni terminalin inşası için bir Liebherr ve Potain kule vinç filosu sağlandı, bu bir dönüm noktası olan kule vinç kuveyt projesidir.", image: "https://images.unsplash.com/photo-1569154941061-e231b4725ef1?q=80&w=2070&auto=format&fit=crop" },
        { id: 2, name: "Al Zour Rafinerisi", description: "Bölgenin en büyük rafinerilerinden biri için yüksek kapasiteli kule vinçler de dahil olmak üzere özel ağır kaldırma çözümleri tedarik edildi, bu büyük bir kule vinç kuveyt girişimidir.", image: "https://images.unsplash.com/photo-1555848132-eb2c6eeb261c?q=80&w=2070&auto=format&fit=crop" },
        { id: 3, name: "Hessah AlMubarak Bölgesi", description: "Kule vinçlerimiz bu modern, karma kullanımlı kentsel gelişimin inşasında etkili olmaktadır. Bir üst düzey kule vinç kuveyt vitrini.", image: "https://images.unsplash.com/photo-1519817914152-22d216bb9170?q=80&w=2070&auto=format&fit=crop" },
        { id: 4, name: "Kuveyt Üniversitesi - Sabah Al-Salem Üniversite Şehri", description: "Çeşitli fakülte ve tesislerin inşasını desteklemek için çok sayıda kule vinç konuşlandırıldı, bu da büyük ölçekli kule vinç kuveyt operasyonları için kapasitemizi kanıtlıyor.", image: "https://images.unsplash.com/photo-1630856169381-257a78a8ea98?q=80&w=2070&auto=format&fit=crop" },
      ],
    },
  };

  const t = projectsContent[language] || projectsContent.en;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      },
    },
  };

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.subtitle} />
        <meta name="keywords" content={t.keywords} />
        <link rel="canonical" href="https://bku-website.online/projects" />
        <meta property="og:title" content={t.title} />
        <meta property="og:description" content={t.subtitle} />
        <meta property="og:url" content="https://bku-website.online/projects" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1519817914152-22d216bb9170?q=80&w=2070&auto=format&fit=crop" />
        <meta property="og:image:alt" content="A stunning cityscape with multiple construction cranes, representing BKU's project portfolio in Kuwait." />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={t.title} />
        <meta name="twitter:description" content={t.subtitle} />
        <meta name="twitter:image" content="https://images.unsplash.com/photo-1519817914152-22d216bb9170?q=80&w=2070&auto=format&fit=crop" />
      </Helmet>
      <div className="container mx-auto px-4 py-16 sm:py-24" dir={isRtl ? 'rtl' : 'ltr'}>
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800">{t.title}</h1>
          <h2 className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">{t.subtitle}</h2>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {t.projects.map((project, index) => (
            <motion.div
              key={project.id}
              variants={itemVariants}
              className="bg-white rounded-lg shadow-lg overflow-hidden group"
            >
              <div className="relative h-64">
                <img src={project.image} alt={`Project: ${project.name}, a tower crane kuwait highlight.`} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-end p-6">
                  <h3 className="text-white text-2xl font-bold">{project.name}</h3>
                </div>
              </div>
              <div className="p-6">
                <p className="text-gray-600">{project.description}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
      <KeywordsCloud />
    </>
  );
};

export default ProjectsPage;