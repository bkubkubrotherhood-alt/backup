import React, { useContext, useMemo } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LanguageContext } from '@/context/LanguageContext';
import { blogData } from '@/lib/blogData.js';
import { ArrowLeft, Calendar, Tag, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import KeywordsCloud from '@/components/KeywordsCloud';

const RenderContentWithLinks = ({ content }) => {
  const { language } = useContext(LanguageContext);
  const getLangPrefix = () => {
    if (language === 'ar') return '';
    if (language === 'zh') return '/cn';
    return `/${language}`;
  };
  const langPrefix = getLangPrefix();

  const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;

  const paragraphs = content.split('\n').map((paragraph, pIndex) => {
    let lastIndex = 0;
    const parts = [];
    let match;

    while ((match = linkRegex.exec(paragraph)) !== null) {
      if (match.index > lastIndex) {
        parts.push(paragraph.substring(lastIndex, match.index));
      }
      
      const [fullMatch, linkText, linkPath] = match;
      const finalPath = `${langPrefix}${linkPath === '/' ? '' : linkPath}`;
      parts.push(
        <Link to={finalPath || '/'} key={`${pIndex}-${match.index}`} className="text-blue-600 hover:underline font-semibold">
          {linkText}
        </Link>
      );
      
      lastIndex = match.index + fullMatch.length;
    }

    if (lastIndex < paragraph.length) {
      parts.push(paragraph.substring(lastIndex));
    }

    return <p key={pIndex} className="mb-6">{parts}</p>;
  });

  return <>{paragraphs}</>;
};

const BlogPostPage = () => {
  const { postId } = useParams();
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const getLangPrefix = () => {
    if (language === 'ar') return '';
    if (language === 'zh') return '/cn';
    return `/${language}`;
  };
  const langPrefix = getLangPrefix();

  const post = useMemo(() => {
    const posts = blogData[language] || blogData.en || [];
    return posts.find(p => p.id === postId);
  }, [postId, language]);

  const content = {
    en: { back: 'Back to Blog' },
    ar: { back: 'العودة إلى المدونة' },
    zh: { back: '返回博客' },
    tr: { back: 'Bloga Geri Dön' },
  };
  const t = content[language] || content.en;
  const BackArrow = isRtl ? ArrowRight : ArrowLeft;

  if (!post) {
    return <Navigate to={`${langPrefix}/blog`} replace />;
  }
  
  const pageUrl = `https://bku-website.online${langPrefix}/blog/${post.id}`;

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": pageUrl
    },
    "headline": post.title,
    "image": post.image,
    "author": {
      "@type": "Organization",
      "name": "BKU Crane"
    },
    "publisher": {
      "@type": "Organization",
      "name": "BKU Crane",
      "logo": {
        "@type": "ImageObject",
        "url": "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/fa691c59856bf50bf64553a454cfa2dc.png"
      }
    },
    "datePublished": post.datetime,
    "dateModified": post.datetime,
    "description": post.content.substring(0, 250).replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1').replace(/"/g, "'") + "...",
    "articleBody": post.content.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1').replace(/"/g, "'")
  };

  return (
    <>
      <Helmet>
        <title>{post.title}</title>
        <meta name="description" content={post.content.substring(0, 160).replace(/###\s?\d\.\s/g, '').replace(/###/g, '').replace(/\*/g, '').replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1')} />
        <meta name="keywords" content={language === 'ar' ? `تاور كرين الكويت, ${post.category}, BKU Crane, ${post.title.split(' ').slice(0, 3).join(' ')}, أخبار الرافعات البرجية, مقالات البناء, Liebherr, Potain, Zoomlion, Yongmao, تأجير رافعات الكويت, بيع رافعات الكويت` : `tower crane kuwait, ${post.category}, BKU Crane, ${post.title.split(' ').slice(0, 3).join(' ')}, tower crane news, construction articles, Liebherr, Potain, Zoomlion, Yongmao, crane rental Kuwait, crane sales Kuwait`} />
        <link rel="canonical" href={pageUrl} />
        <meta property="og:title" content={post.title} />
        <meta property="og:description" content={post.content.substring(0, 160).replace(/###\s?\d\.\s/g, '').replace(/###/g, '').replace(/\*/g, '').replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1')} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={pageUrl} />
        <meta property="og:image" content={post.image} />
        <meta property="og:image:alt" content={post.imageAlt} />
        <meta property="article:published_time" content={post.datetime} />
        <meta property="article:modified_time" content={post.datetime} />
        <meta property="article:author" content="BKU Crane" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>
      <div className="container mx-auto px-4 py-12 sm:py-16">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Button asChild variant="ghost" className="mb-8">
            <Link to={`${langPrefix}/blog`} className="flex items-center text-gray-600 hover:text-gray-900">
              <BackArrow className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />
              {t.back}
            </Link>
          </Button>

          <article>
            <header className="mb-8">
              <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4 rtl:space-x-reverse">
                <div className="flex items-center">
                  <Tag className="ml-1.5 h-4 w-4 rtl:mr-1.5 rtl:ml-0" />
                  <span className="font-medium text-[#000080]">{post.category}</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="ml-1.5 h-4 w-4 rtl:mr-1.5 rtl:ml-0" />
                  <time dateTime={post.datetime}>{post.date}</time>
                </div>
              </div>
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-gray-900 tracking-tight leading-tight">
                {post.title}
              </h1>
            </header>

            <div className="mb-8 rounded-lg overflow-hidden shadow-lg">
              <img className="w-full h-auto max-h-[500px] object-cover" alt={post.imageAlt} src={post.image} />
            </div>

            <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed">
              <RenderContentWithLinks content={post.content} />
            </div>
          </article>
        </motion.div>
      </div>
      <KeywordsCloud />
    </>
  );
};

export default BlogPostPage;