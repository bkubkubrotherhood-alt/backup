import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LanguageContext } from '@/context/LanguageContext';

const mediaItems = [
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/ec6f8c8392c0678973249318df028fe8.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/48efec9a2b301bf06f1dd37b2b054344.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/22833d626a225e68671165c68b6d5b30.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/18109cbbf44ff974c21da834419b6014.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/34fec56bc3127fc4182610a21341d8d7.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/fa705b0d2845daaedd16e83dd732a0e9.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/b65975e922552dc182d630969e6fcc23.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/eb136995b7cf63354873f21d5dd52262.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/56f3378f83aac20d49b7f48f2d93d8d0.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/f3150941a1a58d5c06db0683fcd695ce.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/861d661c2c006bc22c15e2f035856d10.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/6ab4acef13eba11c93392e43eba43836.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/68a05c8ced585bcc1aee8254b4199b35.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/35dc60b0db5fe2843bbb5304e5decd7a.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/1690a2c79c5f025876891f094ee8ea84.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/40868754f18980c5f73f9b6847d696fe.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/c889fe77b9c711715918dfaa7aecbd6b.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/92adfb47fa73da26620d04142d9f7f83.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/308dd95fff5076521309d06a06cd6cb5.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/5816a01335e70561edaabe458d26dd82.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/2edda17882370a0bdf60f7f7f786d68e.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/f2e7cc1218af777600df193e01642b4d.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/ef0218030fde605bc23bda3569d749eb.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/5ee7cdcce0d945a1a071851f91b236b6.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/74f0239efa59ed5a85a3427848ea7f16.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/0b56624eff111209c2b8a2bcd66be307.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/4f9844f308b9dfb145b1a138ed88d756.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/230af376c95c672633982245e0d604c8.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/9c0ae4248165919113f8873fe416fae3.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/d04ae063467b81f00c88f03be88f44cd.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/e13459e43fda0b57b37de99e22f06904.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/6f9ccba00799a8892110abf620a1661a.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/47c7989583e6ec52dcbf00bb2804e0ce.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/5b6ed0f5bcf8d3382ea9d43e390e1301.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/8fef44a78550f71b60beca4e41e6432d.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/feaa00ef7d97fe721f183c6ca731a40f.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/fd0b69fb0b29a15b45badf6d63d3be6d.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/168460d4c8a93df3dc29f3003b304966.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/bd3d80b055f8f69f7fbcb3cb42490e5b.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/b340043b9d85aa865ad29271d3b7f7a1.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/4c4f64f8d43ffc1f159a623d00ad26aa.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/95c92f8e0c370db69ad8c61c06cbfe76.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/cc8aed71b83ddf90ebc64b08fa0a684b.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/9425a38a77b2f14afb686897f47fdb4a.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/3d7119caff47a345b9d1809bd2aed9f9.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/f8c2e57a5062fa545c0b3b09f24f45ca.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/6f9eabab9d604627a0c84d675f0b0880.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/4cbb04481ceb4e7e43fa1b8d63363de0.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/cb61fa14f16a05dde7307f2df0ebe5eb.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-43e8-7ea4bac69708/013ae74d1ff21deaea149d61d84de4ba.webp",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/2029a07dea1f2feab0686f5e23447299.webp",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/5bfc42fcc2406b1576d3f3e585b2f16c.webp",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/c59c47ae8a401c5800d026d8038828ef.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/923d4d3132b0f0c3751554325a48d93b.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/9a016124e5e9680cd18e87bdb2386f9f.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/cdb63607532dda599636477ae3781a17.jpg",
  "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/cdb63607532dda599636477ae3781a17.jpg",
];

const MediaPage = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const content = {
    en: {
      title: "BKU Crane Media Gallery",
      metaDescription: "Explore BKU Crane's media gallery featuring projects, photos, and videos of tower cranes from Kuwait. See Liebherr and Potain cranes in action.",
      subtitle: "Discover our projects, equipment, and team in action."
    },
    ar: {
      title: "معرض وسائط BKU Crane",
      metaDescription: "استكشف معرض وسائط BKU Crane الذي يضم مشاريع وصور وفيديوهات الرافعات البرجية من الكويت. شاهد رافعات Liebherr و Potain أثناء العمل.",
      subtitle: "اكتشف مشاريعنا ومعداتنا وفريقنا أثناء العمل."
    },
    tr: {
      title: "BKU Vinç Medya Galerisi",
      metaDescription: "BKU Crane'in Kuveyt'teki kule vinç projelerini, fotoğraflarını ve videolarını içeren medya galerisini keşfedin. Liebherr ve Potain vinçlerini çalışırken görün.",
      subtitle: "Projelerimizi, ekipmanlarımızı ve ekibimizi çalışırken keşfedin."
    },
    zh: {
      title: "BKU Crane媒体库",
      metaDescription: "探索BKU Crane的媒体库，其中包含科威特塔式起重机的项目、照片和视频。观看利勃海尔和波坦起重机的实际操作。",
      subtitle: "探索我们的项目、设备和团队的实际工作情况。"
    }
  };

  const t = content[language] || content.en;

  const fadeIn = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.8 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.8, y: 20 },
    visible: { 
      opacity: 1, 
      scale: 1, 
      y: 0,
      transition: {
        type: "spring",
        stiffness: 260,
        damping: 20,
      }
    }
  };

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.metaDescription} />
      </Helmet>
       <div style={{ display: 'none' }}>
        {'tower crane kuwait '.repeat(20)}
      </div>
      <motion.div
        initial="hidden"
        animate="visible"
        variants={fadeIn}
        className="bg-gray-50 min-h-screen"
        dir={isRtl ? 'rtl' : 'ltr'}
      >
        <div className="container mx-auto px-4 py-16">
          <motion.div
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 tracking-tight">
              {t.title}
            </h1>
            <p className="mt-4 text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              {t.subtitle}
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {mediaItems.map((item, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.3 }}
                className="group overflow-hidden rounded-lg shadow-lg relative aspect-w-1 aspect-h-1"
              >
                <img 
                  src={item} 
                  alt={`BKU Crane Media ${index + 1}`}
                  loading="lazy"
                  className="w-full h-full object-cover transform transition-transform duration-500 ease-in-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-40 transition-all duration-300"></div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default MediaPage;