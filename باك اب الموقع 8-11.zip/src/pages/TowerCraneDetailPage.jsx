import React, { useContext } from 'react';
    import { Helmet } from 'react-helmet';
    import { useParams, Link, Navigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { LanguageContext } from '@/context/LanguageContext';
    import { CheckCircle, Info, Phone, ArrowLeft, ArrowRight, Download } from 'lucide-react';
    import { towerCranesData } from '@/lib/towerCranesData.js';

    const TowerCraneDetailPage = () => {
      const { language } = useContext(LanguageContext);
      const { craneId } = useParams();
      const isRtl = language === 'ar';
      
      const getLangPrefix = () => {
        if (language === 'ar') return '';
        if (language === 'zh') return '/cn';
        return `/${language}`;
      };
      const langPrefix = getLangPrefix();

      const pageContent = {
        en: {
          backLink: "Back to Tower Cranes",
          specsTitle: "Specifications",
          featuresTitle: "Key Features",
          quoteButton: "Request a Quote for this Crane in Kuwait",
          downloadBrochure: "Download Brochure",
        },
        ar: {
          backLink: "العودة إلى الرافعات البرجية",
          specsTitle: "المواصفات",
          featuresTitle: "الميزات الرئيسية",
          quoteButton: "طلب عرض سعر لهذه الرافعة في الكويت",
          downloadBrochure: "تحميل الكتيب",
        },
        zh: {
          backLink: "返回塔式起重机列表",
          specsTitle: "规格",
          featuresTitle: "主要特点",
          quoteButton: "请求此起重机在科威特的报价",
          downloadBrochure: "下载手册",
        },
        tr: {
          backLink: "Kule Vinçlere Geri Dön",
          specsTitle: "Teknik Özellikler",
          featuresTitle: "Ana Özellikler",
          quoteButton: "Kuveyt'teki Bu Vinç İçin Teklif İsteyin",
          downloadBrochure: "Broşürü İndir",
        }
      };

      const t = pageContent[language] || pageContent.en;
      const cranes = towerCranesData[language] || towerCranesData.en;
      const crane = cranes.find(c => c.id === craneId);

      if (!crane) {
        return <Navigate to={`${langPrefix}/equipment/tower-cranes` || '/'} />;
      }
      
      const BackArrow = isRtl ? ArrowRight : ArrowLeft;

      const pageUrl = `https://bku-website.online${langPrefix}/equipment/tower-cranes/${crane.id}`;
      const pageTitle = language === 'ar' ? `مواصفات ${crane.brand} ${crane.model} | تاجير وبيع في الكويت` : `${crane.brand} ${crane.model} Specs | For Sale & Rent in Kuwait`;
      const pageDescription = language === 'ar' ? `تفاصيل ومواصفات الرافعة البرجية ${crane.brand} ${crane.model}. متوفرة لخدمات تاجير رافعه برجية و بيع رافعة برجية في الكويت. ${crane.description}` : `Technical specifications for the ${crane.brand} ${crane.model} tower crane. Available for sale and rent in Kuwait. ${crane.description}. Your ideal tower crane kuwait.`;
      const pageKeywords = language === 'ar' ? `مواصفات ${crane.brand} ${crane.model}, سعر ${crane.brand} ${crane.model}, تاجير ${crane.brand} ${crane.model} الكويت, بيع ${crane.brand} ${crane.model} الكويت, تاور كرين الكويت, ${crane.brand}` : `${crane.brand} ${crane.model} specs, ${crane.brand} ${crane.model} price, rent ${crane.brand} ${crane.model} Kuwait, buy ${crane.brand} ${crane.model} Kuwait, tower crane Kuwait, ${crane.brand}`;

      const getCraneImage = (craneId) => {
        const imageMap = {
          'liebherr-280-ec-h': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/a95a458d4f6eb707274208b2cb9722e8.jpg",
          'liebherr-110-ec-b-6': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/87ae6ad6fc5d6d112dc2fd0043d15e7f.jpg",
          'liebherr-112-ec-h-8': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/06631656c5b35e1882e57b6c6d68ee22.jpg",
          'liebherr-132-ec-h-8': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/531553cb37b7b8a914510b9a4f157e6c.jpg",
          'liebherr-154-ec-h-6': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/fbf8f9bb4b3fe6a8b1ee56c5b3ad3302.jpg",
          'liebherr-154-ec-h-10': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/b791cb8b0f1c01e782cce282d9a2059b.jpg",
          'liebherr-200-ec-h-10': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/0db564ace1a00008f0fe386c45c53881.jpg",
          'liebherr-202-ec-b-10': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/bf74085f7708d251f60f207da495b4db.jpg",
          'liebherr-245-ec-h-12': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/d62a4f2d73266db1baf033f959dc8908.jpg",
          'liebherr-280-ec-h-12-litronic': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/26a21e5a8b051034b86d051af20fccdb.jpg",
          'liebherr-316-ec-h-12': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/b28e9a3aedf966b10bb28bb5f041584d.jpg",
          'liebherr-380-ec-b-16': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/786bca68e4dc4bd7f5d760c2e778d8a2.jpg",
          'liebherr-550-ec-h-20': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/a4605c3381e12f8498e3f4314cb0ebd2.jpg",
          'potain-md-238-a-j12': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/7756f601e9ba14f6a332966bb870e2a5.jpg",
          'potain-md-265-b-j12': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/d0b7687ec75c3214c5a7e2d8c5d3fe33.jpg",
          'potain-md-310-c-k12': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/fb7ed3290fe93328529c1d8d8989dc46.jpg",
          'potain-md-365-b-l16': "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/56cedbbec04d80fd379e44cf036ec1a3.jpg",
          'zoomlion-tc5013-5': "https://images.unsplash.com/photo-1529939664823-5e3a58384367?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80",
          'zoomlion-tc6012-8': "https://images.unsplash.com/photo-1542882269-d369a01435b2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%.D%3D&auto=format&fit=crop&w=1920&q=80",
          'zoomlion-tc7030-16': "https://images.unsplash.com/photo-1618241318999-9a923154c165?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80",
        };
        const baseId = craneId.split('-').slice(0, -1).join('-');
        return imageMap[crane.id] || crane.image || "https://images.unsplash.com/photo-1623447996775-b9d8096c8ffe";
      };

      const craneImage = getCraneImage(crane.id);

      const productSchema = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": `${crane.brand} ${crane.model}`,
        "image": craneImage,
        "description": pageDescription,
        "url": pageUrl,
        "sku": crane.id,
        "mpn": crane.model,
        "item_group_id": crane.id,
        "brand": {
          "@type": "Brand",
          "name": crane.brand
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.9",
          "reviewCount": "88"
        },
        "offers": {
          "@type": "AggregateOffer",
          "priceCurrency": "KWD",
          "lowPrice": "1000",
          "highPrice": "10000",
          "offerCount": "2",
          "offers": [
            {
              "@type": "Offer",
              "name": `Rental tower crane Kuwait - ${crane.brand} ${crane.model}`,
              "url": pageUrl,
              "availability": "https://schema.org/InStock",
              "priceCurrency": "KWD",
              "price": "1000",
              "seller": {
                "@type": "Organization",
                "name": "BKU Crane"
              }
            },
            {
              "@type": "Offer",
              "name": `Tower crane for sale in Kuwait - ${crane.brand} ${crane.model}`,
              "url": pageUrl,
              "availability": "https://schema.org/InStock",
               "priceCurrency": "KWD",
               "price": "50000",
               "seller": {
                "@type": "Organization",
                "name": "BKU Crane"
              }
            }
          ]
        },
         "additionalProperty": (crane.specifications && Object.entries(crane.specifications).map(([key, value]) => ({
            "@type": "PropertyValue",
            "name": key,
            "value": value
        }))) || []
      };

      return (
        <>
          <Helmet>
            <title>{pageTitle}</title>
            <meta name="description" content={pageDescription} />
            <meta name="keywords" content={pageKeywords} />
            <link rel="canonical" href={pageUrl} />
            <meta property="og:title" content={pageTitle} />
            <meta property="og:description" content={pageDescription} />
            <meta property="og:url" content={pageUrl} />
            <meta property="og:image" content={craneImage} />
            <meta property="og:image:width" content="1200" />
            <meta property="og:image:height" content="630" />
            <meta property="og:image:alt" content={`Image of the ${crane.brand} ${crane.model} tower crane in Kuwait.`} />
            <meta property="og:type" content="product" />
            <meta name="twitter:card" content="summary_large_image" />
            <meta name="twitter:title" content={pageTitle} />
            <meta name="twitter:description" content={pageDescription} />
            <meta name="twitter:image" content={craneImage} />
            <script type="application/ld+json">{JSON.stringify(productSchema)}</script>
          </Helmet>
          <div className="py-12 sm:py-20 bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
            <div className="container mx-auto px-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Button asChild variant="ghost" className="mb-8">
                  <Link to={`${langPrefix}/equipment/tower-cranes` || '/'}>
                    <BackArrow className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />
                    {t.backLink}
                  </Link>
                </Button>

                <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-start bg-white p-8 rounded-xl shadow-lg">
                  <div className="rounded-lg overflow-hidden shadow-xl">
                    <img className="w-full h-96 object-cover" alt={`Detailed view of the ${crane.brand} ${crane.model} construction crane available in Kuwait`} src={crane.image} />
                  </div>
                  <div className="space-y-6">
                    <h1 className="text-4xl font-extrabold text-gray-800">{`${crane.brand} ${crane.model}`}</h1>
                    <h2 className="text-gray-600 text-lg">{crane.description}</h2>
                    
                    <div className="flex flex-wrap gap-4 pt-4">
                        <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 flex-1 min-w-[200px]">
                            <Link to={`${langPrefix}/contact`}>{t.quoteButton}</Link>
                        </Button>
                        <Button asChild variant="outline" size="lg" className="border-blue-600 text-blue-600 hover:bg-blue-50 hover:text-blue-700 flex-1 min-w-[200px]">
                           <a href={`/brochures/${crane.id}.pdf`} download>
                             <Download className="mr-2 h-5 w-5 rtl:ml-2 rtl:mr-0" />
                            {t.downloadBrochure}
                           </a>
                        </Button>
                    </div>

                    <div className="pt-2">
                         <div className="flex items-center text-gray-800 font-semibold bg-blue-50 p-4 rounded-lg">
                          <Phone className="h-6 w-6 text-blue-600 shrink-0 mr-4 rtl:ml-4" />
                          <span>+965 6930 6030 / +965 6512 1663</span>
                        </div>
                      </div>
                  </div>
                </div>

                <div className="mt-12 grid md:grid-cols-2 gap-8 md:gap-12 bg-white p-8 rounded-xl shadow-lg">
                    {crane.specifications && (
                        <section>
                            <h3 className="text-2xl font-bold text-gray-800 mb-4">{t.specsTitle}</h3>
                            <ul className="space-y-3">
                                {Object.entries(crane.specifications).map(([key, value]) => (
                                <li key={key} className="flex items-center p-2 rounded-md transition-colors hover:bg-gray-100">
                                    <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mr-3 rtl:ml-3" />
                                    <span className="text-gray-700 font-semibold capitalize">{key.replace(/([A-Z])/g, ' $1')}: </span>
                                    <span className="text-gray-700 ml-2">{value}</span>
                                </li>
                                ))}
                            </ul>
                        </section>
                    )}
                    
                    {crane.features && crane.features.length > 0 && (
                        <section>
                            <h3 className="text-2xl font-bold text-gray-800 mb-4">{t.featuresTitle}</h3>
                             <ul className="space-y-3">
                                {crane.features.map((feature, featureIndex) => (
                                <li key={featureIndex} className="flex items-center p-2 rounded-md transition-colors hover:bg-gray-100">
                                    <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mr-3 rtl:ml-3" />
                                    <span className="text-gray-700">{feature}</span>
                                </li>
                                ))}
                            </ul>
                        </section>
                    )}
                </div>

                 <div className="mt-8">
                    <div className="flex items-start text-sm text-gray-600 bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                    <Info className="h-5 w-5 shrink-0 mr-3 rtl:ml-3 mt-0.5 text-yellow-500" />
                    <span>Note: Some images may be for representational purposes. Please contact us to confirm availability as the equipment may be rented or sold. Equipment may be located in our branches in Qatar, KSA, or UAE, requiring 1-2 weeks for transfer.</span>
                    </div>
                </div>

              </motion.div>
            </div>
          </div>
        </>
      );
    };

    export default TowerCraneDetailPage;