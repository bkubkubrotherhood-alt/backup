import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import Hero from '@/components/sections/Hero';
import ProductHighlights from '@/components/sections/ProductHighlights';
import PartnersSection from '@/components/sections/PartnersSection';
import NewsSection from '@/components/sections/NewsSection';
import { LanguageContext } from '@/context/LanguageContext';

const HomePage = () => {
  const { language } = useContext(LanguageContext);

  const homeContent = {
    en: {
      title: "Tower Crane Kuwait | BKU | Rental & Sale | #1 Experts",
      description: "BKU Crane is your top choice for tower crane kuwait. We offer rental tower crane Kuwait services and have tower cranes for sale in Kuwait (Liebherr, Potain, Zoomlion, Yongmao). As certified suppliers, we provide comprehensive solutions including luffing crane, self erecting tower crane, and construction crane for any project. For the best tower crane price, contact us.",
      keywords: "tower crane kuwat, rental tower crane, sell tower crane, tower crane for rent, tower crane rental kuwait, tower crane for sale kuwait, liebherr, potain, zoomlion, yongmao, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, tower crane types, tower cranes, construction crane, crane tower, how to install tower cranes, tower crane, ton jib crane, tower crane for sale, tower crane price, self erecting tower crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, construction crane for sale, telescopic boom crane, small tower crane, lr 11000, BKU CRANE, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, تاور كرين الكويت, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية",
      ogTitle: "BKU: The #1 for Tower Crane Kuwait Rental & Sale",
      ogDescription: "Leading provider of tower crane for sale in Kuwait and rental tower crane services. Your expert for everything related to tower crane kuwait. We specialize in Liebherr, Potain, Zoomlion, and Yongmao cranes.",
    },
    ar: {
      title: "تاور كرين الكويت | شركة الاخوة المتحدة | ايجار وبيع | رقم #1",
      description: "خبراء تأجير، بيع، وصيانة رافعات Liebherr و Potain و Zoomlion و Yongmao. شركة الإخوة الكويتية المتحدة رائدة في تأجير وبيع الرافعات البرجية في الكويت (تور كرين). نقدم حلولاً متكاملة تشمل luffing crane و self erecting tower crane، مع التزام كامل بالسلامة. شريك رسمي نحو رؤية كويت جديدة 2035.",
      keywords: "تاور كرين الكويت, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, BKU CRANE, شركة الاخوة الكويتية المتحدة, معدات ثقيلة, liebherr, potain, zoomlion, yongmao, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, سعر الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية",
      ogTitle: "تاور كرين الكويت | شركة الاخوة الكويتية المتحدة: ايجار وبيع",
      ogDescription: "الشركة الرائدة في بيع تور كرين في الكويت وخدمات تاجير تاور كرين الكويت. نحن خبراء في رافعات Liebherr و Potain و Zoomlion و Yongmao، وجهتك الأولى لكل ما يتعلق بـ tower crane kuwait.",
    },
    zh: {
        title: "科威特塔式起重机 | BKU | 租赁与销售 | #1 专家",
        description: "BKU Crane是您在科威特塔式起重机领域的首选。我们提供科威特塔式起重机租赁服务，并销售科威特塔式起重机（利勃海尔、波坦、中联重科、永茂）。作为认证供应商，我们为任何项目提供全面的解决方案，包括动臂起重机、自升式塔式起重机和建筑起重机。有关最佳塔式起重机价格，请联系我们。",
        keywords: "科威特塔式起重机, 塔式起重机, 待售塔式起重机, 租赁塔式起重机, 利勃海尔, 波坦, 中联重科, 永茂, 建筑起重机, 自升式塔式起重机, 动臂起重机, 塔式起重机价格, BKU Crane, 科威特塔吊, 科威特塔机租赁, 科威特塔机销售, BKU CRANE, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机",
        ogTitle: "BKU: 科威特塔式起重机租赁与销售第一选择",
        ogDescription: "科威特领先的塔式起重机销售和租赁服务提供商。您在科威特塔式起重机相关一切领域的专家。我们专注于利勃海尔、波坦、中联重科和永茂起重机。",
    },
    tr: {
        title: "Kuveyt Kule Vinç | BKU | Kiralama & Satış | #1 Uzmanlar",
        description: "BKU Vinç, Kuveyt kule vinçleri için en iyi seçiminizdir. Kuveyt kule vinç kiralama hizmetleri sunuyoruz ve Kuveyt'te satılık kule vinçlerimiz (Liebherr, Potain, Zoomlion, Yongmao) bulunmaktadır. Sertifikalı tedarikçiler olarak, her türlü proje için luffing vinç, kendinden kurmalı kule vinç ve inşaat vinci dahil olmak üzere kapsamlı çözümler sunuyoruz. En iyi kule vinç fiyatı için bize ulaşın.",
        keywords: "kuveyt kule vinç, kule vinç, satılık kule vinç, kiralık kule vinç, Liebherr, Potain, Zoomlion, Yongmao, inşaat vinci, kendinden kurmalı kule vinç, luffing vinç, kule vinç fiyatı, BKU Vinç, kule vinç kuveyt, kiralık kule vinç kuveyt, satılık kule vinç kuveyt, BKU CRANE, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur",
        ogTitle: "BKU: Kuveyt Kule Vinç Kiralama ve Satışında 1 Numara",
        ogDescription: "Kuveyt'te satılık kule vinç ve kiralık kule vinç hizmetlerinin lider sağlayıcısı. Kuveyt kule vinç ile ilgili her şey için uzmanınız. Liebherr, Potain, Zoomlion ve Yongmao vinçlerinde uzmanız.",
    }
  };

  const t = homeContent[language] || homeContent.ar;

  const getCanonicalUrl = () => {
    let path = '';
    if (language === 'en') path = '/en';
    if (language === 'zh') path = '/cn';
    if (language === 'tr') path = '/tr';
    return `https://bku-website.online${path || '/'}`;
  };

  const webPageSchema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "url": getCanonicalUrl(),
    "name": t.title,
    "description": t.description,
    "keywords": t.keywords,
    "inLanguage": language,
    "mainEntity": {
      "@type": "Organization",
      "name": "شركة الاخوة الكويتية المتحدة (BKU Crane)",
      "url": "https://bku-website.online",
      "logo": "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/7d494b4590625ca775a667a4119d24d3.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+965-69306030",
        "contactType": "customer service",
        "areaServed": "KW"
      },
      "knowsAbout": "tower crane kuwait"
    }
  };

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.description} />
        <meta name="keywords" content={t.keywords} />
        <meta property="og:title" content={t.ogTitle} />
        <meta property="og:description" content={t.ogDescription} />
        <meta property="og:url" content={getCanonicalUrl()} />
        <meta property="og:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/67f8d94986fe0cd93c7cbb7b81c7a6f0.jpg" />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
        <meta property="og:image:alt" content="A fleet of BKU's Liebherr and Potain tower cranes at a construction site in Kuwait. The best Tower Crane Kuwait service." />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={t.ogTitle} />
        <meta name="twitter:description" content={t.ogDescription} />
        <meta name="twitter:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/67f8d94986fe0cd93c7cbb7b81c7a6f0.jpg" />
        <script type="application/ld+json">{JSON.stringify(webPageSchema)}</script>
      </Helmet>
      
      <Hero />
      <ProductHighlights />
      <PartnersSection />
      <NewsSection />
    </>
  );
};

export default HomePage;