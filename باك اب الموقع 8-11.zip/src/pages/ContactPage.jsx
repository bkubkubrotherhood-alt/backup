import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin } from 'lucide-react';
import ContactForm from '@/components/ContactForm';
import { LanguageContext } from '@/context/LanguageContext';

const ContactPage = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const newMapSrc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d281.0590941086085!2d48.01983241711719!3d29.340991389901127!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fcf9cf606064161%3A0x492a5a66836750ef!2z2LTYp9ix2Lkg2KrZiNmG2LPYjCDYrdmI2YTZig!5e1!3m2!1sar!2skw!4v1762207852552!5m2!1sar!2skw";

  const content = {
    en: {
      title: "Contact Us",
      metaDescription: "Contact BKU Crane for tower crane rental, sales, maintenance, or project consultations in Kuwait. We are the best in tower crane kuwait.",
      keywords: `contact BKU, bku address, bku phone, ${'tower crane kuwait, '.repeat(10)}`,
      subtitle: "We're here to help with your heavy lifting needs. Get in touch!",
      info: {
        title: "Our Contact Information",
        phone: { text: "69306030", href: "tel:69306030" },
        phone2: { text: "65121663", href: "tel:65121663" },
        email: { text: "INFO@BKUCRANE.COM", href: "mailto:INFO@BKUCRANE.COM" },
        address: "Al-Nahar Complex, Floor 1, Office 5, Tunisia St, Hawally, Kuwait"
      },
      map: {
        title: "Find Us On The Map",
        src: newMapSrc
      }
    },
    ar: {
      title: "تواصل معنا",
      metaDescription: "تواصل مع BKU Crane للاستفسار عن تأجير وبيع وصيانة الرافعات البرجية أو استشارات المشاريع في الكويت. نحن الأفضل في مجال تاور كرين الكويت.",
      keywords: `اتصل بـ BKU, عنوان BKU, هاتف BKU, ${'tower crane kuwait, '.repeat(10)}`,
      subtitle: "نحن هنا لمساعدتك في احتياجاتك من معدات الرفع. تواصل معنا!",
      info: {
        title: "معلومات الاتصال بنا",
        phone: { text: "69306030", href: "tel:69306030" },
        phone2: { text: "65121663", href: "tel:65121663" },
        email: { text: "INFO@BKUCRANE.COM", href: "mailto:INFO@BKUCRANE.COM" },
        address: "مجمع النهار، الدور الأول، مكتب 5، شارع تونس، حولي، الكويت"
      },
      map: {
        title: "تجدنا على الخريطة",
        src: newMapSrc
      }
    },
    tr: {
      title: "Bize Ulaşın",
      metaDescription: "Kuveyt'te kule vinç kiralama, satış, bakım veya proje danışmanlığı için BKU Crane ile iletişime geçin. Kule vinç Kuveyt konusunda en iyisiyiz.",
      keywords: `BKU ile iletişime geç, BKU adresi, BKU telefonu, ${'tower crane kuwait, '.repeat(10)}`,
      subtitle: "Ağır kaldırma ihtiyaçlarınızda size yardımcı olmak için buradayız. Bizimle iletişime geçin!",
      info: {
        title: "İletişim Bilgilerimiz",
        phone: { text: "69306030", href: "tel:69306030" },
        phone2: { text: "65121663", href: "tel:65121663" },
        email: { text: "INFO@BKUCRANE.COM", href: "mailto:INFO@BKUCRANE.COM" },
        address: "Al-Nahar Kompleksi, Kat 1, Ofis 5, Tunus Cad., Hawally, Kuveyt"
      },
      map: {
        title: "Haritada Bizi Bulun",
        src: newMapSrc
      }
    },
    zh: {
      title: "联系我们",
      metaDescription: "联系BKU Crane，咨询科威特的塔式起重机租赁、销售、维护或项目咨询。我们是科威特塔式起重机领域的最佳选择。",
      keywords: `联系BKU, BKU地址, BKU电话, ${'tower crane kuwait, '.repeat(10)}`,
      subtitle: "我们随时准备帮助您满足重型起重需求。请联系我们！",
      info: {
        title: "我们的联系方式",
        phone: { text: "69306030", href: "tel:69306030" },
        phone2: { text: "65121663", href: "tel:65121663" },
        email: { text: "INFO@BKUCRANE.COM", href: "mailto:INFO@BKUCRANE.COM" },
        address: "科威特哈瓦里，突尼斯街，Al-Nahar综合大楼1楼5号办公室"
      },
      map: {
        title: "在地图上找到我们",
        src: newMapSrc
      }
    }
  };

  const t = content[language] || content.en;
  
  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.2,
        duration: 0.6,
        ease: "easeOut",
      },
    }),
  };

  return (
    <>
      <Helmet>
        <title>{t.title} - BKU Crane</title>
        <meta name="description" content={t.metaDescription} />
        <meta name="keywords" content={t.keywords} />
      </Helmet>
       <div style={{ display: 'none' }}>
        {'tower crane kuwait '.repeat(10)}
      </div>
      <div className="bg-gradient-to-b from-gray-100 to-gray-200 dark:from-gray-900 dark:to-black" dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="container mx-auto px-4 py-16 sm:py-24">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-400 pb-2">{t.title}</h1>
            <p className="mt-4 text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">{t.subtitle}</p>
          </motion.div>

          <div className="grid lg:grid-cols-5 gap-12 items-start">
            <motion.div
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
              custom={0}
              className="lg:col-span-2 bg-white/50 dark:bg-black/20 backdrop-blur-lg border border-white/20 p-8 rounded-2xl shadow-2xl"
            >
              <ContactForm />
            </motion.div>

            <motion.div
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
              custom={1}
              className="lg:col-span-3 space-y-8"
            >
              <div className="bg-white/50 dark:bg-black/20 backdrop-blur-lg border border-white/20 p-8 rounded-2xl shadow-lg">
                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">{t.info.title}</h3>
                <div className="space-y-6 text-gray-700 dark:text-gray-300">
                  <a href={t.info.phone.href} className="flex items-center group text-lg hover:text-blue-500 transition-colors">
                    <Phone className={`h-6 w-6 text-blue-500 ${isRtl ? 'ml-4' : 'mr-4'}`} />
                    <span>{t.info.phone.text}</span>
                  </a>
                  <a href={t.info.phone2.href} className="flex items-center group text-lg hover:text-blue-500 transition-colors">
                    <Phone className={`h-6 w-6 text-blue-500 ${isRtl ? 'ml-4' : 'mr-4'}`} />
                    <span>{t.info.phone2.text}</span>
                  </a>
                  <a href={t.info.email.href} className="flex items-center group text-lg hover:text-blue-500 transition-colors">
                    <Mail className={`h-6 w-6 text-blue-500 ${isRtl ? 'ml-4' : 'mr-4'}`} />
                    <span>{t.info.email.text}</span>
                  </a>
                  <p className="flex items-start text-lg">
                    <MapPin className={`h-6 w-6 mt-1 text-blue-500 flex-shrink-0 ${isRtl ? 'ml-4' : 'mr-4'}`} />
                    <span>{t.info.address}</span>
                  </p>
                </div>
              </div>

               <div className="bg-white/50 dark:bg-black/20 backdrop-blur-lg border border-white/20 p-8 rounded-2xl shadow-lg">
                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.map.title}</h3>
                <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
                  <iframe
                    src={t.map.src}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="BKU Crane Location Map"
                  ></iframe>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContactPage;