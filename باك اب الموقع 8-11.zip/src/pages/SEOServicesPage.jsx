import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LanguageContext } from '@/context/LanguageContext';
import { Check, BarChart, Search, Link2, MonitorSmartphone, FileText, BrainCircuit, Users } from 'lucide-react';

const SEOServicesPage = () => {
    const { language } = useContext(LanguageContext);
    const isRtl = language === 'ar';

    const t = {
        en: {
            title: "Professional SEO Services | Boost Your Ranking | BKU",
            description: "Boost your website's visibility with our expert SEO services. We offer technical audits, on-page, off-page, keyword research, and comprehensive reporting.",
            keywords: "SEO services, technical SEO, on-page SEO, off-page SEO, backlink building, keyword research, SEO audit, Google Analytics, search engine optimization",
            h1: "Comprehensive SEO Services to Dominate Search Rankings",
            p: "From technical audits to strategic content, we provide everything you need to climb the search ladder and attract your target audience.",
            services: [
                { title: 'Comprehensive Site Analysis and Full SEO Evaluation', icon: BarChart, points: ['Technical Audit', 'Crawl, Indexing, and Speed Error Analysis', 'User Experience (UX) Analysis'] },
                { title: 'On-Page SEO Optimization', icon: MonitorSmartphone, points: ['Meta Title & Description Optimization', 'Site Structure & Internal Linking Improvement', 'Targeted Keyword Usage', 'Site Speedand UX Improvement'] },
                { title: 'Off-Page SEO Optimization', icon: Link2, points: ['High-Authority Backlink Building', 'Natural and Safe Strategies', 'Professional Backlink File Delivery'] },
                { title: 'Competitor and Keyword Analysis', icon: Search, points: ['Competitor Strategy Analysis', 'Custom Keyword List Generation', 'Local (Gulf) or Global Market Targeting'] },
                { title: 'Google Search Console & Analytics', icon: BarChart, points: ['Site Connection and Traffic Analysis', 'Page and Keyword Performance Tracking', 'Technical Error Detection and Solutions'] },
                { title: 'Sitemap Submission & Full Indexing', icon: FileText, points: ['XML Sitemap Creation and Upload', 'Robots.txt Configuration', 'Manual Indexing Requests'] },
                { title: 'Content, Articles, & Blog SEO', icon: BrainCircuit, points: ['SEO-Friendly Content Creation', 'Content Improvement and Generation', 'CTR-Boosting Headlines'] },
                { title: 'Detailed Reports & Clear Action Plan', icon: FileText, points: ['Detailed SEO Audit Report', 'Clear Implementation Plan & Timeline', 'Regular Progress Reports'] },
            ],
            whyUsTitle: "Why Work With Us?",
            whyUsPoints: [
                "Extensive experience in the Arab and Saudi markets.",
                "Tangible results without false promises.",
                "Full commitment to time and quality.",
                "Continuous technical support and consulting.",
                "Professional and flexible communication style."
            ],
            ctaTitle: "Ready to Get Started?",
            ctaPoints: [
                "A free report on your current site status.",
                "Technical consultation to improve performance.",
                "A custom strategy tailored to your project goals."
            ]
        },
        ar: {
            title: "خدمات سيو احترافية | تعزيز ترتيبك | BKU",
            description: "عزز ظهور موقعك على الويب من خلال خدمات تحسين محركات البحث (SEO) المتخصصة التي نقدمها. نحن نقدم تدقيقًا تقنيًا، وتحسينًا داخليًا وخارجيًا، وبحثًا عن الكلمات المفتاحية، وتقارير شاملة.",
            keywords: "خدمات سيو, سيو تقني, تحسين داخلي, تحسين خارجي, بناء روابط خلفية, بحث عن الكلمات المفتاحية, تدقيق سيو, جوجل أناليتكس, تحسين محركات البحث",
            h1: "خدمات SEO شاملة للسيطرة على تصنيفات البحث",
            p: "من التدقيق الفني إلى المحتوى الاستراتيجي، نقدم كل ما تحتاجه لتسلق سلم البحث وجذب جمهورك المستهدف.",
            services: [
                { title: 'تحليل شامل للموقع وتقييم SEO كامل', icon: BarChart, points: ['فحص تقني للموقع (Technical Audit)', 'كشف وتحليل أخطاء الزحف والأرشفة والسرعة', 'تحليل تجربة المستخدم (UX) وتأثيرها على الترتيب'] },
                { title: 'تحسين داخلي On-Page SEO', icon: MonitorSmartphone, points: ['تحسين العناوين والوصف (Meta Title & Description)', 'تحسين هيكلية الموقع والروابط الداخلية (Internal Linking)', 'استخدام كلمات مفتاحية دقيقة مدروسة', 'تحسين سرعة الموقع وتجربة المستخدم'] },
                { title: 'تحسين خارجي Off-Page SEO', icon: Link2, points: ['بناء روابط خارجية قوية (Backlinks)', 'استخدام استراتيجيات طبيعية وآمنة', 'تسليم ملف باك لينكس احترافي'] },
                { title: 'تحليل المنافسين والكلمات المفتاحية', icon: Search, points: ['دراسة أداء المنافسين واستخلاص استراتيجياتهم', 'توليد قائمة كلمات مفتاحية مخصصة', 'استهداف السوق المحلي (الخليجي) أو العالمي'] },
                { title: 'ربط وتحسين Google Search Console & Analytics', icon: BarChart, points: ['ربط الموقع وتحليل بيانات الزيارات', 'تتبع أداء الصفحات والكلمات المفتاحية', 'كشف الأخطاء التقنية واقتراح حلول'] },
                { title: 'رفع خريطة الموقع (Sitemap) وأرشفة كاملة', icon: FileText, points: ['إنشاء ورفع خريطة XML', 'تهيئة ملفات Robots.txt', 'طلب فهرسة الصفحات يدوياً'] },
                { title: 'تحسين المحتوى والمقالات والمدونة (Content SEO)', icon: BrainCircuit, points: ['صياغة محتوى متوافق مع السيو', 'تحسين المقالات الحالية وتوليد مواضيع جديدة', 'استخدام عناوين جذابة وتحسين معدل النقر (CTR)'] },
                { title: 'تقارير مفصلة وخطة عمل واضحة', icon: FileText, points: ['تسليم تقرير SEO Audit مفصل', 'خطة تنفيذ وجدول زمني واضح', 'تحديثات وتقارير دورية'] },
            ],
            whyUsTitle: "مميزات العمل معي:",
            whyUsPoints: [
                "خبرة واسعة في السوق العربي والسعودي خصوصاً",
                "نتائج ملموسة بدون وعود مزيفة",
                "التزام كامل بالوقت والجودة",
                "دعم فني واستشارات مستمرة",
                "أسلوب تواصل محترف ومرن"
            ],
            ctaTitle: "عند بداية العمل ستحصل على:",
            ctaPoints: [
                "تقرير مجاني لحالة موقعك الحالي",
                "استشارة فنية لتحسين الأداء",
                "خطة استراتيجية مخصصة حسب أهداف مشروعك"
            ]
        },
    };

    const content = t[language] || t.en;
    const pageUrl = language === 'ar' ? `https://bku-website.online/seo-services` : `https://bku-website.online/en/seo-services`;

    const ServiceCard = ({ service, index }) => (
        <motion.div
            className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
        >
            <div className="p-6">
                <div className="flex items-center mb-4">
                    <div className="p-3 bg-red-100 rounded-full mr-4 rtl:ml-4">
                        <service.icon className="w-6 h-6 text-red-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
                </div>
                <ul className="space-y-2">
                    {service.points.map((point, i) => (
                        <li key={i} className="flex items-start">
                            <Check className="w-5 h-5 text-green-500 mr-2 rtl:ml-2 mt-1 flex-shrink-0" />
                            <span className="text-gray-600">{point}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </motion.div>
    );

    const FeatureCard = ({ title, points, icon: Icon }) => (
      <div className="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center text-center transform hover:scale-105 transition-transform duration-300">
          <div className="p-4 bg-red-100 rounded-full mb-4">
              <Icon className="w-8 h-8 text-red-600" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-3">{title}</h3>
          <ul className="space-y-2 text-gray-600">
              {points.map((point, i) => (
                  <li key={i} className="flex items-center">
                      <Check className="w-4 h-4 text-green-500 mr-2 rtl:ml-2" />
                      {point}
                  </li>
              ))}
          </ul>
      </div>
  );

    return (
        <>
            <Helmet>
                <title>{content.title}</title>
                <meta name="description" content={content.description} />
                <meta name="keywords" content={content.keywords} />
                <link rel="canonical" href={pageUrl} />
                 <meta property="og:title" content={content.title} />
                <meta property="og:description" content={content.description} />
                <meta property="og:url" content={pageUrl} />
            </Helmet>
            <div className="bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
                {/* Hero Section */}
                <section className="bg-gradient-to-br from-red-600 to-red-800 text-white py-20">
                    <div className="container mx-auto px-4 text-center">
                        <motion.h1
                            className="text-4xl md:text-5xl font-extrabold mb-4"
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.5 }}
                        >
                            {content.h1}
                        </motion.h1>
                        <motion.p
                            className="text-lg md:text-xl max-w-3xl mx-auto"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.5, delay: 0.2 }}
                        >
                            {content.p}
                        </motion.p>
                    </div>
                </section>

                {/* Services Grid */}
                <section className="py-16">
                    <div className="container mx-auto px-4">
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                            {content.services.map((service, index) => (
                                <ServiceCard key={index} service={service} index={index} />
                            ))}
                        </div>
                    </div>
                </section>

                {/* Why Us & CTA Section */}
                <section className="bg-gray-100 py-16">
                    <div className="container mx-auto px-4">
                        <div className="grid md:grid-cols-2 gap-12 items-start">
                             <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }}>
                                <FeatureCard title={content.whyUsTitle} points={content.whyUsPoints} icon={Users} />
                            </motion.div>
                            <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.2 }}>
                                <FeatureCard title={content.ctaTitle} points={content.ctaPoints} icon={FileText} />
                            </motion.div>
                        </div>
                    </div>
                </section>
            </div>
        </>
    );
};

export default SEOServicesPage;