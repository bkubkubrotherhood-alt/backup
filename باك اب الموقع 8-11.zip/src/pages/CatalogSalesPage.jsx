import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, Tag } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';
import { catalogData } from '@/lib/catalogData';

const CatalogSalesPage = () => {
    const { language } = useContext(LanguageContext);
    const t = catalogData[language] || catalogData.ar;

    const pageContent = {
        en: {
            title: "Used Equipment for Sale | BKU Crane",
            description: "Explore our catalog of certified used tower cranes and heavy equipment for sale in Kuwait. Find reliable machinery at competitive prices, including top brands like Liebherr and Potain.",
            heading: "Equipment Catalog for Sale",
            subheading: "Find certified new and used cranes and heavy equipment."
        },
        ar: {
            title: "معدات مستعملة للبيع | BKU Crane",
            description: "تصفح كتالوجنا للمعدات الثقيلة والرافعات البرجية المستعملة المعتمدة للبيع في الكويت. اعثر على آليات موثوقة بأسعار تنافسية، بما في ذلك أفضل العلامات التجارية مثل ليبهير وبوتان.",
            heading: "كتالوج المعدات للبيع",
            subheading: "اعثر على رافعات ومعدات ثقيلة جديدة ومستعملة معتمدة."
        },
        tr: {
            title: "Satılık İkinci El Ekipmanlar | BKU Crane",
            description: "Kuveyt'te satılık sertifikalı ikinci el kule vinçleri ve ağır ekipman kataloğumuzu keşfedin. Liebherr ve Potain gibi en iyi markalar da dahil olmak üzere rekabetçi fiyatlarla güvenilir makineler bulun.",
            heading: "Satılık Ekipman Kataloğu",
            subheading: "Sertifikalı yeni ve kullanılmış vinçleri ve ağır ekipmanları bulun."
        },
        zh: {
            title: "二手设备出售 | BKU Crane",
            description: "浏览我们在科威特出售的经认证的二手塔式起重机和重型设备目录。以有竞争力的价格找到可靠的机械，包括利勃海尔和波坦等顶级品牌。",
            heading: "待售设备目录",
            subheading: "查找经认证的新旧起重机和重型设备。"
        }
    };
    const currentContent = pageContent[language] || pageContent.ar;

    const getLink = (path) => {
        if (language === 'ar') return path;
        const langCode = language === 'zh' ? 'cn' : language;
        return `/${langCode}${path}`;
    };

    const generateProductSchema = (item) => ({
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": item.title,
        "image": item.image,
        "description": item.description,
        "sku": item.id,
        "mpn": item.id,
        "brand": {
          "@type": "Brand",
          "name": "BKU Crane"
        },
        ...(item.review && {
          "review": {
            "@type": "Review",
            "reviewRating": {
              "@type": "Rating",
              "ratingValue": item.review.rating,
              "bestRating": "5"
            },
            "author": {
              "@type": "Organization",
              "name": "BKU Crane"
            }
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": item.review.rating,
            "reviewCount": item.review.count
          }
        }),
        "offers": {
          "@type": "Offer",
          "url": `https://bku-website.online${getLink(`/catalog-sales/${item.id}`)}`,
          "priceCurrency": "KWD",
          "price": item.price.split(' ')[0],
          "priceValidUntil": item.priceValidUntil,
          "itemCondition": "https://schema.org/UsedCondition",
          "availability": `https://schema.org/${item.availability}`,
          "seller": {
            "@type": "Organization",
            "name": "BKU Crane"
          }
        }
    });

    const AvailabilityBadge = ({ availability }) => {
        const styles = {
          InStock: 'bg-green-100 text-green-800',
          OutOfStock: 'bg-red-100 text-red-800',
          PreOrder: 'bg-yellow-100 text-yellow-800',
        };
        const text = {
            en: { InStock: 'In Stock', OutOfStock: 'Out of Stock', PreOrder: 'Pre-Order' },
            ar: { InStock: 'متوفر', OutOfStock: 'غير متوفر', PreOrder: 'طلب مسبق' },
            tr: { InStock: 'Stokta', OutOfStock: 'Stokta Yok', PreOrder: 'Ön Sipariş' },
            zh: { InStock: '有现货', OutOfStock: '缺货', PreOrder: '预购' },
        }
        return (
          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${styles[availability] || 'bg-gray-100 text-gray-800'}`}>
            {text[language][availability] || availability}
          </span>
        );
    };

    const StarRating = ({ rating, count }) => (
        <div className="flex items-center">
            <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`h-4 w-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                ))}
            </div>
            <span className="text-xs text-gray-500 ml-2">{`(${count})`}</span>
        </div>
    );

    return (
        <>
            <Helmet>
                <title>{currentContent.title}</title>
                <meta name="description" content={currentContent.description} />
                {t.map(item => (
                    <script key={`schema-${item.id}`} type="application/ld+json">
                        {JSON.stringify(generateProductSchema(item))}
                    </script>
                ))}
            </Helmet>
            <div className="bg-gray-50 py-12">
                <div className="container mx-auto px-4">
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-center mb-12">
                        <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">{currentContent.heading}</h1>
                        <p className="mt-4 text-xl text-gray-600">{currentContent.subheading}</p>
                    </motion.div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                        {t.map((item, index) => (
                            <motion.div key={item.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }}>
                                <Card className="h-full flex flex-col overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300 group">
                                    <div className="relative">
                                        <img src={item.image} alt={item.title} className="w-full h-48 object-cover" />
                                        <div className="absolute top-2 right-2">
                                           <AvailabilityBadge availability={item.availability} />
                                        </div>
                                    </div>
                                    <CardContent className="p-6 flex flex-col flex-grow">
                                        <h2 className="text-lg font-bold text-gray-900 mb-2 flex-grow">{item.title}</h2>
                                        <p className="text-sm text-gray-600 mb-4">{item.description}</p>
                                        
                                        <div className="flex justify-between items-center mb-4">
                                            <div className="flex items-center">
                                                <Tag className="h-4 w-4 text-gray-500 mr-1" />
                                                <span className="text-lg font-bold text-red-600">{item.price}</span>
                                            </div>
                                            {item.review && <StarRating rating={item.review.rating} count={item.review.count} />}
                                        </div>

                                        <Link to={getLink(`/catalog-sales/${item.id}`)} className="mt-auto">
                                            <Button className="w-full bg-red-600 hover:bg-red-700 text-white font-bold transition-colors">
                                                {language === 'ar' ? 'عرض التفاصيل' : language === 'tr' ? 'Detayları Görüntüle' : language === 'zh' ? '查看详情' : 'View Details'}
                                            </Button>
                                        </Link>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
};

export default CatalogSalesPage;