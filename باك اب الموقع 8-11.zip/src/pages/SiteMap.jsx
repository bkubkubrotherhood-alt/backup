import React from 'react';
import { blogData } from '@/lib/blogData.js';
import { catalogData } from '@/lib/catalogData.js';
import { towerCranesData } from '@/lib/towerCranesData.js';

const generateUrlSet = (urls, langPrefixes) => {
  const baseUrl = 'https://bku-website.online';
  
  return urls.map(urlObject => {
    const alternates = Object.keys(langPrefixes).map(lang => {
      const href = `${baseUrl}${langPrefixes[lang]}${urlObject.path}`;
      const hreflang = lang === 'zh' ? 'zh-CN' : lang;
      return `<xhtml:link rel="alternate" hreflang="${hreflang}" href="${href}"/>`;
    }).join('');

    const defaultHref = `${baseUrl}${langPrefixes['ar']}${urlObject.path}`;
    const xDefault = `<xhtml:link rel="alternate" hreflang="x-default" href="${defaultHref}"/>`;

    return `
    <url>
      <loc>${defaultHref}</loc>
      <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
      <changefreq>daily</changefreq>
      <priority>0.9</priority>
      ${alternates}
      ${xDefault}
    </url>
  `;
  }).join('');
};

const SiteMapPage = () => {
  const langPrefixes = { ar: '', en: '/en', tr: '/tr', zh: '/cn' };
  
  const staticRoutes = [
    '/',
    '/about',
    '/equipment',
    '/equipment/tower-cranes',
    '/equipment/construction-hoists',
    '/services',
    '/services/maintenance',
    '/services/training',
    '/services/logistics',
    '/services/consultation',
    '/media',
    '/projects',
    '/catalog-sales',
    '/contact',
    '/store-locator',
    '/blog'
  ].map(path => ({ path }));

  const dynamicBlogUrls = (blogData.ar || []).map(post => ({ path: `/blog/${post.id}` }));
  const dynamicCatalogUrls = (catalogData.ar || []).map(item => ({ path: `/catalog-sales/${item.id}` }));
  const dynamicCraneUrls = (towerCranesData.ar || []).map(crane => ({ path: `/equipment/tower-cranes/${crane.id}` }));

  const allUrlObjects = [
    ...staticRoutes,
    ...dynamicBlogUrls,
    ...dynamicCatalogUrls,
    ...dynamicCraneUrls
  ];
  
  const uniqueUrlObjects = allUrlObjects.filter((v,i,a)=>a.findIndex(t=>(t.path === v.path))===i)

  const sitemapContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
  ${generateUrlSet(uniqueUrlObjects, langPrefixes)}
</urlset>
  `.trim();

  // In a client-side app, we can't directly serve an XML file.
  // This component will render the XML as text. 
  // Your hosting should serve this route with an 'application/xml' Content-Type header.
  return <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{sitemapContent}</pre>;
};

export default SiteMapPage;