import React, { useState, useRef, useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Check, Mail, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import KeywordsCloud from '@/components/KeywordsCloud';
import { LanguageContext } from '@/context/LanguageContext';
import emailjs from '@emailjs/browser';

const ConsultationPage = () => {
  const { toast } = useToast();
  const formRef = useRef(null);
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const content = {
    en: {
      title: "Technical Consultation for Tower Crane Kuwait | BKU Experts",
      subtitle: "Get expert advice on selecting the right tower crane in Kuwait for your project. Our team provides detailed analysis to ensure you get the most efficient and cost-effective lifting solution for your tower crane kuwait needs.",
      keywords: "crane consultation, tower crane selection, project consulting, BKU experts, tower crane in Kuwait, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, crane project planning, lifting solutions Kuwait, heavy equipment consultation, construction advice Kuwait, Liebherr, Potain, Zoomlion, Yongmao, BKU CRANE, tower crane kuwait, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية",
      form: {
        title: "Schedule Your Free Consultation",
        companyName: "Company Name",
        name: "Your Name",
        email: "Email",
        phone: "Phone Number",
        projectDetails: "Briefly describe your project and your tower crane in Kuwait requirements",
        submit: "Request Consultation"
      },
      benefits: {
          title: "Why Consult Us for tower crane kuwait?",
          points: [
              "Optimal crane selection for your specific project needs.",
              "Improved on-site safety and efficiency.",
              "Clear understanding of costs and accurate quotes.",
              "Leverage our ~20 years of expertise in tower crane kuwait."
          ]
      },
      toastSuccess: "Consultation request sent successfully!",
      toastSuccessDesc: "We will contact you shortly.",
      toastError: "Error!",
      toastErrorDesc: "Failed to send request. Please try again later."
    },
    ar: {
      title: "استشارات فنية لـ تاور كرين الكويت | خبراء BKU",
      subtitle: "احصل على مشورة الخبراء لاختيار تاور كرين في الكويت المناسب لمشروعك. يقدم فريقنا تحليلاً مفصلاً لضمان حصولك على حل الرفع الأكثر كفاءة وفعالية من حيث التكلفة لاحتياجاتك من tower crane kuwait.",
      keywords: "استشارات الرافعات, اختيار الرافعة البرجية, استشارات المشاريع, خبراء BKU, تاور كرين في الكويت, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, تخطيط مشاريع الرافعات, حلول الرفع الكويت, استشارات معدات ثقيلة, نصائح بناء الكويت, Liebherr, Potain, Zoomlion, Yongmao, BKU CRANE, تاور كرين الكويت, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية",
      form: {
        title: "حدد موعد استشارتك المجانية",
        companyName: "اسم الشركة",
        name: "الاسم",
        email: "البريد الإلكتروني",
        phone: "رقم الهاتف",
        projectDetails: "صف بإيجاز مشروعك ومتطلباتك من تاور كرين في الكويت",
        submit: "طلب استشارة"
      },
      benefits: {
          title: "لماذا تستشيرنا بشأن tower crane kuwait؟",
          points: [
              "اختيار الرافعة الأمثل لاحتياجات مشروعك الخاصة.",
              "تحسين السلامة والكفاءة في الموقع.",
              "فهم التكاليف المترتبة والحصول على عروض أسعار دقيقة.",
              "الاستفادة من خبرتنا التي تقارب 20 عامًا في مجال tower crane kuwait."
          ]
      },
      toastSuccess: "تم إرسال طلب الاستشارة بنجاح!",
      toastSuccessDesc: "سوف نتصل بك قريبا.",
      toastError: "خطأ!",
      toastErrorDesc: "فشل إرسال الطلب. يرجى المحاولة مرة أخرى لاحقًا."
    },
    zh: {
        title: "科威特塔式起重机技术咨询 | BKU专家",
        subtitle: "获取专家建议，为您的项目选择合适的科威特塔式起重机。我们的团队提供详细分析，确保您获得最高效、最具成本效益的起重解决方案，满足您的科威特塔式起重机需求。",
        keywords: "起重机咨询, 塔式起重机选择, 项目咨询, BKU专家, 科威特塔式起重机, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, 起重机项目规划, 起重解决方案科威特, 重型设备咨询, 建筑建议科威特, 利勃海尔, 波坦, 中联重科, 永茂, BKU CRANE, tower crane kuwait, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机",
        form: { title: "安排您的免费咨询", companyName: "公司名称", name: "您的姓名", email: "电子邮件", phone: "电话号码", projectDetails: "简要描述您的项目和科威特塔式起重机需求", submit: "请求咨询" },
        benefits: { title: "为何就科威特塔式起重机咨询我们？", points: ["为您的特定项目需求选择最佳起重机。", "提高现场安全性和效率。", "清晰了解成本和准确报价。", "利用我们近20年在科威特塔式起重机领域的专业知识。"] },
        toastSuccess: "咨询请求已成功发送！", toastSuccessDesc: "我们将很快与您联系。", toastError: "错误！", toastErrorDesc: "发送请求失败。请稍后再试。"
    },
    tr: {
        title: "Kuveyt Kule Vinç Teknik Danışmanlık | BKU Uzmanları",
        subtitle: "Projeniz için doğru Kuveyt kule vincini seçme konusunda uzman tavsiyesi alın. Ekibimiz, kule vinç kuveyt ihtiyaçlarınız için en verimli ve uygun maliyetli kaldırma çözümünü elde etmenizi sağlamak için ayrıntılı analiz sunar.",
        keywords: "vinç danışmanlığı, kule vinç seçimi, proje danışmanlığı, BKU uzmanları, Kuveyt'te kule vinç, للايجار تاور كرين الكويت, تاجير تاور كرين الكويت, vinç proje planlaması, kaldırma çözümleri Kuveyt, ağır ekipman danışmanlığı, inşaat tavsiyesi Kuveyt, Liebherr, Potain, Zoomlion, Yongmao, BKU CRANE, kule vinç Kuveyt, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur",
        form: { title: "Ücretsiz Danışmanlığınızı Planlayın", companyName: "Şirket Adı", name: "Adınız", email: "E-posta", phone: "Telefon Numarası", projectDetails: "Projenizi ve Kuveyt kule vinç gereksinimlerinizi kısaca açıklayın", submit: "Danışmanlık İste" },
        benefits: { title: "Neden kule vinç kuveyt için bize danışmalısınız?", points: ["Özel proje ihtiyaçlarınız için en uygun vinç seçimi.", "Sahada artırılmış güvenlik ve verimlilik.", "Maliyetlerin net bir şekilde anlaşılması ve doğru teklifler.", "Kule vinç kuveyt alanındaki ~20 yıllık uzmanlığımızdan yararlanın."] },
        toastSuccess: "Danışmanlık talebi başarıyla gönderildi!", toastSuccessDesc: "Yakında sizinle iletişime geçeceğiz.", toastError: "Hata!", toastErrorDesc: "İstek gönderilemedi. Lütfen daha sonra tekrar deneyin."
    }
  };

  const t = content[language] || content.en;
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    emailjs.sendForm('service_gkl5ueg', 'template_vxo3769', formRef.current, 'aIV30VFPKcE2h5A_w')
      .then((result) => {
          toast({ title: t.toastSuccess, description: t.toastSuccessDesc });
          formRef.current.reset();
      }, (error) => {
          toast({ title: t.toastError, description: error.text || t.toastErrorDesc, variant: 'destructive' });
      })
      .finally(() => {
        setIsSubmitting(false);
      });
  };

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "Technical Consultation for Tower Crane",
    "provider": { "@type": "Organization", "name": "BKU Crane" },
    "areaServed": "Kuwait",
    "description": t.subtitle,
    "name": t.title
  };

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.subtitle} />
        <meta name="keywords" content={t.keywords} />
        <link rel="canonical" href="https://bku-website.online/services/consultation" />
        <meta property="og:title" content={t.title} />
        <meta property="og:description" content={t.subtitle} />
        <meta property="og:url" content="https://bku-website.online/services/consultation" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=2130&auto=format&fit=crop" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify(serviceSchema)}</script>
      </Helmet>
      <div className="bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
      <section className="container mx-auto px-4 py-16 sm:py-24">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800">{t.title}</h1>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">{t.subtitle}</p>
        </motion.div>
        <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
                initial={{ opacity: 0, x: isRtl ? 50 : -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="space-y-6"
            >
                <h2 className="text-3xl font-bold text-gray-800">{t.benefits.title}</h2>
                <ul className="space-y-4">
                    {t.benefits.points.map((point, index) => (
                        <li key={index} className="flex items-start">
                            <div className="flex-shrink-0 h-6 w-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
                                <Check className="h-4 w-4"/>
                            </div>
                            <span className={`${isRtl ? 'mr-3' : 'ml-3'} text-lg text-gray-700`}>{point}</span>
                        </li>
                    ))}
                </ul>
                 <div className="mt-8">
                    <img alt="A team of engineers reviewing blueprints for a tower crane project in Kuwait." className="rounded-lg shadow-xl w-full h-auto object-cover" src="https://images.unsplash.com/photo-1581093196867-ca3dba3c721b" />
                </div>
            </motion.div>
            <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="bg-white p-8 rounded-lg shadow-2xl"
            >
            <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">{t.form.title}</h3>
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="from_name" className="block text-sm font-medium text-gray-700 mb-1">{t.form.name}</label>
                  <Input id="from_name" name="from_name" type="text" placeholder={t.form.name} required />
                </div>
                <div>
                  <label htmlFor="company_name" className="block text-sm font-medium text-gray-700 mb-1">{t.form.companyName}</label>
                  <Input id="company_name" name="company_name" type="text" placeholder={t.form.companyName} />
                </div>
                <div>
                  <label htmlFor="from_email" className="block text-sm font-medium text-gray-700 mb-1">{t.form.email}</label>
                  <Input id="from_email" name="from_email" type="email" placeholder={t.form.email} required />
                </div>
                <div>
                  <label htmlFor="from_phone" className="block text-sm font-medium text-gray-700 mb-1">{t.form.phone}</label>
                  <Input id="from_phone" name="from_phone" type="tel" placeholder={t.form.phone} />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">{t.form.projectDetails}</label>
                  <Textarea id="message" name="message" placeholder={t.form.projectDetails} rows={5} required />
                </div>
                <div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Mail className="mr-2 h-5 w-5" />}
                    {isSubmitting ? (language === 'ar' ? 'جاري الإرسال...' : 'Submitting...') : t.form.submit}
                </Button>
                </div>
            </form>
            </motion.div>
        </div>
      </section>
      </div>
      <KeywordsCloud />
    </>
  );
};

export default ConsultationPage;