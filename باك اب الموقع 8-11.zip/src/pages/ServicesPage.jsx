import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Wrench, HardHat, Truck, MessageSquare, ArrowRight, ArrowLeft } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';
import { Button } from '@/components/ui/button';

const ServicesPage = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const servicesContent = {
    en: {
      title: "Tower Crane Services in Kuwait | Maintenance, Training, Logistics",
      description: "BKU offers comprehensive services for tower cranes in Kuwait, including expert maintenance, certified operator training, full logistics, and technical consultation for any project. Your source for tower crane kuwait solutions.",
      keywords: "tower crane services Kuwait, crane maintenance, crane operator training, crane logistics, crane consultation, tower crane support Kuwait, tower crane kuwait, BKU CRANE, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية",
      subtitle: "Comprehensive services for tower cranes in Kuwait, from maintenance and training to logistics and consultation. We provide end-to-end support for your tower crane kuwait needs.",
      learnMore: "Learn More",
      services: [
        { title: "Maintenance & Repair", description: "Expert maintenance to keep your tower crane in Kuwait operating at peak performance.", icon: Wrench, link: "/services/maintenance" },
        { title: "Operator Training", description: "Certified training programs for safe and efficient tower crane operation.", icon: HardHat, link: "/services/training" },
        { title: "Logistics & Transport", description: "Complete logistics solutions for transporting and assembling your tower crane.", icon: Truck, link: "/services/logistics" },
        { title: "Technical Consultation", description: "Expert advice to help you select the right tower crane for your project.", icon: MessageSquare, link: "/services/consultation" },
      ],
    },
    ar: {
      title: "خدمات الرافعات البرجية في الكويت | صيانة، تدريب، لوجستيات",
      description: "تقدم BKU خدمات شاملة للرافعات البرجية في الكويت، تشمل الصيانة المتخصصة، تدريب المشغلين المعتمد، الخدمات اللوجستية الكاملة، والاستشارات الفنية لأي مشروع.",
      keywords: "خدمات تاور كرين الكويت, صيانة الرافعات, تدريب مشغلي الرافعات, لوجستيات الرافعات, استشارات الرافعات, دعم فني للرافعات البرجية الكويت, BKU CRANE, تاور كرين الكويت, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية",
      subtitle: "خدمات شاملة للرافعات البرجية في الكويت، من الصيانة والتدريب إلى اللوجستيات والاستشارات. نقدم دعمًا شاملاً لتلبية احتياجاتك من tower crane kuwait.",
      learnMore: "اعرف المزيد",
      services: [
          { title: "الصيانة والإصلاح", description: "صيانة متخصصة للحفاظ على تشغيل تاور كرين الكويت بأعلى أداء.", icon: Wrench, link: "/services/maintenance" },
          { title: "تدريب المشغلين", description: "برامج تدريب معتمدة لتشغيل الرافعات البرجية بأمان وكفاءة.", icon: HardHat, link: "/services/training" },
          { title: "اللوجستيات والنقل", description: "حلول لوجستية كاملة لنقل وتجميع رافعتك البرجية.", icon: Truck, link: "/services/logistics" },
          { title: "الاستشارات الفنية", description: "مشورة الخبراء لمساعدتك في اختيار الرافعة البرجية المناسبة لمشروعك.", icon: MessageSquare, link: "/services/consultation" },
      ],
    },
    zh: {
      title: "科威特塔式起重机服务 | 维护、培训、物流",
      description: "BKU为科威特的塔式起重机提供全面服务，包括专家维护、认证操作员培训、全方位物流和任何项目的技术咨询。",
      keywords: "科威特塔式起重机服务, 起重机维护, 起重机操作员培训, 起重机物流, 起重机咨询, 科威特塔式起重机支持, tower crane kuwait, BKU CRANE, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机",
      subtitle: "为科威特的塔式起重机提供从维护、培训到物流和咨询的全面服务。我们为您的科威特塔式起重机需求提供端到端支持。",
      learnMore: "了解更多",
      services: [
        { title: "维护与修理", description: "专业的维护服务，确保您在科威特的塔式起重机以最佳性能运行。", icon: Wrench, link: "/services/maintenance" },
        { title: "操作员培训", description: "为安全高效的塔式起重机操作提供认证培训计划。", icon: HardHat, link: "/services/training" },
        { title: "物流与运输", description: "为您的塔式起重机运输和组装提供完整的物流解决方案。", icon: Truck, link: "/services/logistics" },
        { title: "技术咨询", description: "专家建议，帮助您为项目选择合适的塔式起重机。", icon: MessageSquare, link: "/services/consultation" },
      ],
    },
    tr: {
      title: "Kuveyt Kule Vinç Hizmetleri | Bakım, Eğitim, Lojistik",
      description: "BKU, Kuveyt'teki kule vinçler için uzman bakım, sertifikalı operatör eğitimi, tam lojistik ve herhangi bir proje için teknik danışmanlık dahil olmak üzere kapsamlı hizmetler sunmaktadır.",
      keywords: "kuveyt kule vinç hizmetleri, vinç bakımı, vinç operatörü eğitimi, vinç lojistiği, vinç danışmanlığı, kuveyt kule vinç desteği, tower crane kuwait, BKU CRANE, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur",
      subtitle: "Kuveyt'teki kule vinçler için bakımdan eğitime, lojistikten danışmanlığa kadar kapsamlı hizmetler. Kule vinç Kuveyt ihtiyaçlarınız için uçtan uca destek sağlıyoruz.",
      learnMore: "Daha Fazla Bilgi",
      services: [
        { title: "Bakım ve Onarım", description: "Kuveyt'teki kule vincinizin en yüksek performansta çalışmasını sağlamak için uzman bakım.", icon: Wrench, link: "/services/maintenance" },
        { title: "Operatör Eğitimi", description: "Güvenli ve verimli kule vinç operasyonu için sertifikalı eğitim programları.", icon: HardHat, link: "/services/training" },
        { title: "Lojistik ve Nakliye", description: "Kule vincinizin taşınması ve montajı için eksiksiz lojistik çözümleri.", icon: Truck, link: "/services/logistics" },
        { title: "Teknik Danışmanlık", description: "Projeniz için doğru kule vinci seçmenize yardımcı olacak uzman tavsiyesi.", icon: MessageSquare, link: "/services/consultation" },
      ],
    },
  };

  const t = servicesContent[language] || servicesContent.en;

  const getLink = (path) => {
    if (language === 'ar') return path;
    const langCode = language === 'zh' ? 'cn' : language;
    return `/${langCode}${path}`;
  };

  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      },
    },
  };

  const itemListSchema = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    "itemListElement": t.services.map((service, index) => ({
      "@type": "ListItem",
      "position": index + 1,
      "item": {
        "@type": "Service",
        "name": service.title,
        "description": service.description,
        "url": `https://bku-website.online${getLink(service.link)}`,
        "provider": {
          "@type": "Organization",
          "name": "BKU Crane"
        }
      }
    }))
  };

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.description} />
        <meta name="keywords" content={t.keywords} />
        <link rel="canonical" href={`https://bku-website.online${getLink('/services')}`} />
        <meta property="og:title" content={t.title} />
        <meta property="og:description" content={t.subtitle} />
        <meta property="og:url" content={`https://bku-website.online${getLink('/services')}`} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/df99478f79f4c1c9ff97924c562544c4.jpg" />
        <meta property="og:image:alt" content="A technician working on a large piece of machinery, representing BKU's comprehensive crane services in Kuwait." />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={t.title} />
        <meta name="twitter:description" content={t.description} />
        <meta name="twitter:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/df99478f79f4c1c9ff97924c562544c4.jpg" />
        <script type="application/ld+json">{JSON.stringify(itemListSchema)}</script>
      </Helmet>
      <div className="bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="container mx-auto px-4 py-16 sm:py-24">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800">{t.title}</h1>
            <h2 className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">{t.subtitle}</h2>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
          >
            {t.services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className="bg-white rounded-lg shadow-lg overflow-hidden group hover:shadow-xl transition-all duration-300"
                >
                  <div className="p-8">
                    <div className="flex items-center mb-4">
                      <div className="flex-shrink-0 h-12 w-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
                          {Icon && <Icon className="h-6 w-6" />}
                      </div>
                      <h3 className="text-2xl font-bold text-gray-800 ms-4">{service.title}</h3>
                    </div>
                    <p className="text-gray-600 mb-6">{service.description}</p>
                    <Button asChild variant="outline" className="group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <Link to={getLink(service.link)}>
                        {t.learnMore}
                        <ArrowIcon className="ms-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ServicesPage;