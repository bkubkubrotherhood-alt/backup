
import React, { useEffect, useState, useContext } from 'react';
import { LanguageContext } from '@/context/LanguageContext';
import { catalogData } from '@/lib/catalogData.js';
import { translations } from '@/lib/translations';

const CatalogFeedPage = () => {
    const { language } = useContext(LanguageContext);
    const [feedXml, setFeedXml] = useState('');
    const t = translations[language] || translations.en;

    useEffect(() => {
        const generateFeed = () => {
            const host = window.location.origin;

            const formatPriceForGoogle = (priceString) => {
                if (!priceString) return '';
                const numericPart = parseFloat(String(priceString).replace(/[^\d.]/g, ''));
                if (isNaN(numericPart)) return '';
                return `${numericPart.toFixed(2)} KWD`;
            };

            const products = catalogData.en.map(catalog => ({
                id: catalog.id,
                title: catalog.title,
                description: catalog.description,
                link: `${host}/en/catalog-sales/${catalog.id}`,
                image_link: catalog.image,
                availability: catalog.availability.toLowerCase() === 'outofstock' ? 'out of stock' : 'in stock',
                price: formatPriceForGoogle(catalog.price),
                brand: 'BKU Crane',
                gtin: `BKU-CATALOG-${catalog.id}`,
                mpn: `BKU-CATALOG-${catalog.id}`,
                condition: 'new',
                item_group_id: 'Catalogs',
            }));

            let xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
<channel>
<title>${t.catalogFeedPage ? t.catalogFeedPage.title : 'BKU Catalogs'}</title>
<link>${host}</link>
<description>${t.catalogFeedPage ? t.catalogFeedPage.description : 'Catalog feed for BKU Crane'}</description>`;

            products.forEach(product => {
                 if (!product.price || product.price === '0.00 KWD' || product.price.trim() === 'KWD') {
                    return;
                }

                xml += `
<item>
    <g:id>${product.id || ''}</g:id>
    <g:title><![CDATA[${product.title || ''}]]></g:title>
    <g:description><![CDATA[${product.description || ''}]]></g:description>
    <g:link>${product.link || ''}</g:link>
    <g:image_link>${product.image_link || ''}</g:image_link>
    <g:availability>${product.availability || 'out of stock'}</g:availability>
    <g:price>${product.price}</g:price>
    <g:brand><![CDATA[${product.brand || 'BKU Crane'}]]></g:brand>
    ${product.gtin ? `<g:gtin>${product.gtin}</g:gtin>` : ''}
    <g:mpn>${product.mpn || ''}</g:mpn>
    <g:condition>${product.condition || 'new'}</g:condition>
    <g:item_group_id><![CDATA[${product.item_group_id || ''}]]></g:item_group_id>
</item>`;
            });

            xml += `
</channel>
</rss>`;

            setFeedXml(xml);
        };

        generateFeed();
    }, [language, t]);
    
    useEffect(() => {
        if (feedXml) {
            // Display the XML content directly in the browser
            document.documentElement.outerHTML = feedXml;
            // Prevent React from trying to re-render the original HTML
            document.getElementById('root').innerHTML = ''; 
        }
    }, [feedXml]);

    return (
        <div style={{ padding: '2rem', fontFamily: 'monospace' }}>
            Generating catalog feed... If you are not redirected, please refresh the page.
        </div>
    );
};

export default CatalogFeedPage;
