import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Wrench, Zap, ShieldCheck, Clock, Award } from 'lucide-react';
import ServiceRequestForm from '@/components/ServiceRequestForm';
import KeywordsCloud from '@/components/KeywordsCloud';
import { LanguageContext } from '@/context/LanguageContext';

const MaintenancePage = () => {
    const { language } = useContext(LanguageContext);
    const isRtl = language === 'ar';

    const getLangPrefix = () => {
      if (language === 'ar') return '';
      if (language === 'zh') return '/cn';
      return `/${language}`;
    };
    const langPrefix = getLangPrefix();

    const content = {
        en: {
            title: "Tower Crane Kuwait Maintenance & Support | BKU Service",
            metaDescription: "Ensure peak performance and safety with BKU Crane's expert maintenance and support services for tower cranes and construction hoists in Kuwait. Best tower crane kuwait.",
            keywords: `crane maintenance, tower crane support, crane repair, Liebherr parts, Potain service, tower crane kuwait, للايجار تاور كرين الكويت, BKU CRANE, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
            hero: {
                title: "Keeping Your Equipment at Peak Performance",
                subtitle: "Reliable maintenance and support for uninterrupted tower crane kuwait operations."
            },
            offerings: {
                title: "Our Maintenance Offerings",
                items: [
                    {
                        title: "Preventive Maintenance Programs",
                        description: "Scheduled checks and proactive servicing to identify and address potential issues before they become major breakdowns."
                    },
                    {
                        title: "Emergency Repair Services",
                        description: "Our rapid-response team of certified technicians is available 24/7 to tackle any unexpected downtime."
                    },
                    {
                        title: "Genuine Spare Parts",
                        description: "We use only genuine manufacturer parts to ensure compatibility, reliability, and extend equipment life."
                    },
                    {
                        title: "On-Site Technical Support",
                        description: "Our experienced technicians provide on-site diagnostics and troubleshooting to optimize your tower crane kuwait performance."
                    }
                ]
            },
            benefits: {
                title: "Benefits of Maintenance with BKU Crane",
                items: [
                    { icon: Clock, text: "Maximize uptime and minimize unexpected breakdowns." },
                    { icon: ShieldCheck, text: "Enhanced equipment safety to ensure your team and site are secure." },
                    { icon: Award, text: "Prolong equipment lifespan through proactive care." },
                    { icon: Zap, text: "Cost-efficiency by preventing expensive major repairs." }
                ]
            },
            formTitle: "Request Maintenance Service Now"
        },
        ar: {
            title: "صيانة ودعم تاور كرين الكويت | خدمة BKU",
            metaDescription: "ضمان الأداء الأقصى والسلامة مع خدمات الصيانة والدعم الخبيرة من BKU Crane للرافعات البرجية ومصاعد البناء في الكويت. أفضل تاور كرين الكويت.",
            keywords: `صيانة الرافعات, دعم الرافعات البرجية, إصلاح الرافعات, قطع غيار Liebherr, خدمة Potain, تاور كرين الكويت, للايجار تاور كرين الكويت, BKU CRANE, معدات ثقيلة, شركة الاخوة الكويتية المتحدة, رافعات برجية, tower crane kuwat, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, تاور كرين الكويت, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, تاور كرين, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, أنواع الرافعات البرجية, الرافعات البرجية, الرافعة البرجية, تركيب الرافعة البرجية, تور كرين, الرافعة البرجية, طريقة تركيب الرافعات البرجية, كرين تاور, كيفية تركيب الرافعات البرجية`,
            hero: {
                title: "الحفاظ على معداتك في أفضل أداء",
                subtitle: "صيانة ودعم موثوقان لعمليات غير منقطعة لـ tower crane kuwait."
            },
            offerings: {
                title: "خدمات الصيانة التي نقدمها",
                items: [
                    {
                        title: "برامج الصيانة الوقائية",
                        description: "فحوصات مجدولة وخدمة استباقية لتحديد المشاكل المحتملة ومعالجتها قبل أن تصبح أعطالاً كبيرة."
                    },
                    {
                        title: "خدمات الإصلاح الطارئة",
                        description: "فريقنا للاستجابة السريعة من الفنيين المعتمدين متاح على مدار الساعة طوال أيام الأسبوع لمعالجة أي أعطال غير متوقعة."
                    },
                    {
                        title: "قطع الغيار الأصلية",
                        description: "نستخدم فقط قطع غيار أصلية من الشركة المصنعة لضمان التوافق والموثوقية وإطالة عمر المعدات."
                    },
                    {
                        title: "الدعم الفني في الموقع",
                        description: "يقدم فنيونا ذوو الخبرة التشخيص واستكشاف الأخطاء وإصلاحها في الموقع لتحسين أداء tower crane kuwait."
                    }
                ]
            },
            benefits: {
                title: "فوائد الصيانة مع BKU Crane",
                items: [
                    { icon: Clock, text: "زيادة وقت التشغيل إلى أقصى حد وتقليل الأعطال غير المتوقعة." },
                    { icon: ShieldCheck, text: "تعزيز سلامة المعدات لضمان أمان فريقك وموقعك." },
                    { icon: Award, text: "إطالة عمر المعدات من خلال الصيانة الاستباقية." },
                    { icon: Zap, text: "كفاءة التكلفة عن طريق منع الإصلاحات الكبرى المكلفة." }
                ]
            },
            formTitle: "اطلب خدمة الصيانة الآن"
        },
        zh: {
            title: "科威特塔式起重机维护与支持 | BKU服务",
            metaDescription: "通过BKU Crane为科威特的塔式起重机和施工升降机提供专家维护和支持服务，确保最佳性能和安全性。最佳科威特塔式起重机。",
            keywords: `起重机维护, 塔式起重机支持, 起重机维修, 利勃海尔零件, 波坦服务, 科威特塔式起重机, للايجار تاور كرين الكويت, BKU CRANE, tower crane kuwait, 重型设备, 联合兄弟公司, 塔式起重机, tower crane kuwat, 租赁塔式起重机, 待售塔式起重机, 租赁塔式起重机, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 科威特塔式起重机租赁, 科威特塔式起重机销售, 租赁塔式起重机, 待售塔式起重机, 待售塔式起重机, 租赁塔式起重机, 待售塔式起重机科威特, 租赁塔式起重机科威特, 待售塔式起重机科威特, 租赁塔式起重机科威特, 租赁塔式起重机科威特, 科威特塔式起重机, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, 塔式起重机, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, 塔式起重机类型, 塔式起重机, 塔式起重机, 塔式起重机安装, 塔式起重机, 塔式起重机, 塔式起重机安装方法, 起重机塔, 如何安装塔式起重机`,
            hero: {
                title: "让您的设备保持最佳性能",
                subtitle: "可靠的维护和支持，确保科威特塔式起重机不间断运行。"
            },
            offerings: {
                title: "我们的维护服务",
                items: [
                    { title: "预防性维护计划", description: "定期检查和主动服务，在潜在问题成为重大故障前发现并解决。" },
                    { title: "紧急维修服务", description: "我们由认证技术人员组成的快速反应团队全天候待命，处理任何意外停机。" },
                    { title: "原厂备件", description: "我们只使用原厂备件，以确保兼容性、可靠性并延长设备寿命。" },
                    { title: "现场技术支持", description: "我们经验丰富的技术人员提供现场诊断和故障排除，以优化您的科威特塔式起重机性能。" }
                ]
            },
            benefits: {
                title: "与BKU Crane合作进行维护的好处",
                items: [
                    { icon: Clock, text: "最大化正常运行时间，减少意外故障。" },
                    { icon: ShieldCheck, text: "增强设备安全性，确保您的团队和场地安全。" },
                    { icon: Award, text: "通过主动保养延长设备使用寿命。" },
                    { icon: Zap, text: "通过预防昂贵的大修来提高成本效益。" }
                ]
            },
            formTitle: "立即申请维护服务"
        },
        tr: {
            title: "Kuveyt Kule Vinç Bakım ve Destek | BKU Servisi",
            metaDescription: "BKU Crane'in Kuveyt'teki kule vinçler ve inşaat asansörleri için uzman bakım ve destek hizmetleriyle en yüksek performansı ve güvenliği sağlayın. En iyi kule vinç Kuveyt.",
            keywords: `vinç bakımı, kule vinç desteği, vinç onarımı, Liebherr parçaları, Potain servisi, kule vinç kuveyt, للايجار تاور كرين الكويت, BKU CRANE, kule vinç Kuveyt, ağır ekipman, Birleşik Kardeşler Şirketi, kule vinçler, kule vinç kuveyt, kiralık kule vinç, satılık kule vinç, kiralık kule vinç, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç, satılık kule vinç, satılık kule vinç, kiralık kule vinç, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, satılık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kiralık kule vinç Kuveyt, kule vinç Kuveyt, Liebherr, Rentel, tower crane, ton jib crane, tower crane for sale, tower crane price, construction crane, self erecting tower crane, potain crane, mobile tower crane, self erecting tower crane for sale, luffing crane, tower crane companies, self erecting crane, liebherr tower crane, used tower crane for sale, potain tower crane, portable tower crane, tower crane cost, building crane, tower crane companies near me, construction crane for sale, tower crane camera, potain self erecting crane, telescopic boom crane, construction crane price, small tower crane, lr 11000, kule vinç, fassi f28, grove 4100l, grove 6300l, kato 250, mc 85 potain, potain mc 310 k12, potain mr 608, rk450, zoomlion w12000 450, kule vinç türleri, kule vinçler, kule vinç, kule vinç kurulumu, kule vinç, kule vinç, kule vinç kurulum yöntemi, vinç kulesi, kule vinçler nasıl kurulur`,
            hero: {
                title: "Ekipmanlarınızı Zirve Performansta Tutmak",
                subtitle: "Kuveyt kule vinç operasyonlarının kesintisiz sürmesi için güvenilir bakım ve destek."
            },
            offerings: {
                title: "Bakım Hizmetlerimiz",
                items: [
                    { title: "Önleyici Bakım Programları", description: "Potansiyel sorunları büyük arızalara dönüşmeden belirlemek ve gidermek için planlı kontroller ve proaktif servis." },
                    { title: "Acil Onarım Hizmetleri", description: "Sertifikalı teknisyenlerden oluşan hızlı müdahale ekibimiz, beklenmedik arızaları gidermek için 7/24 hizmetinizdedir." },
                    { title: "Orijinal Yedek Parçalar", description: "Uyumluluğu, güvenilirliği sağlamak ve ekipman ömrünü uzatmak için yalnızca orijinal üretici parçaları kullanıyoruz." },
                    { title: "Yerinde Teknik Destek", description: "Deneyimli teknisyenlerimiz, kule vinç kuveyt performansınızı optimize etmek için yerinde teşhis ve sorun giderme hizmeti sunar." }
                ]
            },
            benefits: {
                title: "BKU Vinç ile Bakımın Faydaları",
                items: [
                    { icon: Clock, text: "Çalışma süresini en üst düzeye çıkarın ve beklenmedik arızaları en aza indirin." },
                    { icon: ShieldCheck, text: "Ekibinizin ve şantiyenizin güvenliğini sağlamak için geliştirilmiş ekipman güvenliği." },
                    { icon: Award, text: "Proaktif bakımla ekipman ömrünü uzatın." },
                    { icon: Zap, text: "Pahalı büyük onarımları önleyerek maliyet verimliliği." }
                ]
            },
            formTitle: "Şimdi Bakım Hizmeti Talep Edin"
        }
    };
  
    const t = content[language] || content.en;
  
    const serviceSchema = {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Tower Crane Maintenance and Support",
      "provider": {
        "@type": "Organization",
        "name": "BKU Crane"
      },
      "areaServed": "Kuwait",
      "description": t.metaDescription,
      "name": t.title
    };

    return (
        <>
            <Helmet>
                <title>{t.title}</title>
                <meta name="description" content={t.metaDescription} />
                <meta name="keywords" content={t.keywords} />
                <link rel="canonical" href={`https://bku-website.online${langPrefix}/services/maintenance`} />
                <meta property="og:title" content={t.title} />
                <meta property="og:description" content={t.hero.subtitle} />
                <meta property="og:url" content={`https://bku-website.online${langPrefix}/services/maintenance`} />
                <meta property="og:type" content="website" />
                <meta property="og:image" content="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/8f8fecafaa61b283a79e8cd5b8553dcb.jpg" />
                <meta name="twitter:card" content="summary_large_image" />
                <script type="application/ld+json">{JSON.stringify(serviceSchema)}</script>
            </Helmet>
            <div className="bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
                {/* Hero Section */}
                <section className="relative bg-gray-900 text-white py-32 md:py-48 overflow-hidden">
                    <div className="absolute inset-0">
                        <img
                            alt="Rows of new crane winches and parts in a large warehouse, ready for maintenance and installation."
                            className="w-full h-full object-cover opacity-30"
                            src="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/8f8fecafaa61b283a79e8cd5b8553dcb.jpg"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent"></div>
                    </div>
                    <div className="relative container mx-auto px-4 text-center">
                        <motion.h1 
                            initial={{ opacity: 0, y: -30 }} 
                            animate={{ opacity: 1, y: 0 }} 
                            transition={{ duration: 0.8, ease: 'easeOut' }}
                            className="text-4xl md:text-6xl font-extrabold"
                        >
                            {t.hero.title}
                        </motion.h1>
                        <motion.p 
                            initial={{ opacity: 0, y: 30 }} 
                            animate={{ opacity: 1, y: 0 }} 
                            transition={{ duration: 0.8, delay: 0.3, ease: 'easeOut' }}
                            className="mt-4 text-lg md:text-xl max-w-3xl mx-auto text-gray-300"
                        >
                            {t.hero.subtitle}
                        </motion.p>
                    </div>
                </section>

                {/* Offerings Section */}
                <section className="py-16 md:py-24 bg-white">
                    <div className="container mx-auto px-4">
                        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 text-center mb-12">{t.offerings.title}</h2>
                        <div className="grid md:grid-cols-2 gap-8">
                            {t.offerings.items.map((item, index) => (
                                <motion.div 
                                    key={index}
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true, amount: 0.5 }}
                                    transition={{ duration: 0.5, delay: index * 0.1 }}
                                    className="bg-gray-100 p-8 rounded-lg shadow-md"
                                >
                                    <h3 className="text-2xl font-semibold text-gray-800 mb-4">{item.title}</h3>
                                    <p className="text-gray-600 leading-relaxed">{item.description}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* Benefits Section */}
                <section className="py-16 md:py-24 bg-gray-800 text-white">
                    <div className="container mx-auto px-4">
                        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">{t.benefits.title}</h2>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                            {t.benefits.items.map((benefit, index) => {
                                const Icon = benefit.icon;
                                return (
                                    <motion.div 
                                        key={index}
                                        initial={{ opacity: 0, scale: 0.9 }}
                                        whileInView={{ opacity: 1, scale: 1 }}
                                        viewport={{ once: true, amount: 0.5 }}
                                        transition={{ duration: 0.5, delay: index * 0.1 }}
                                        className="text-center p-6 bg-gray-700/50 rounded-lg"
                                    >
                                        <div className="inline-block p-4 bg-blue-600 rounded-full mb-4">
                                            <Icon className="h-8 w-8" />
                                        </div>
                                        <p>{benefit.text}</p>
                                    </motion.div>
                                );
                            })}
                        </div>
                    </div>
                </section>

                {/* Service Request Form Section */}
                <section className="py-16 md:py-24 bg-gray-50">
                    <div className="container mx-auto px-4">
                        <ServiceRequestForm 
                            serviceName="Maintenance & Support"
                            formTitle={t.formTitle}
                            pageName="Maintenance Page"
                        />
                    </div>
                </section>
                
                <KeywordsCloud />
            </div>
        </>
    );
};

export default MaintenancePage;