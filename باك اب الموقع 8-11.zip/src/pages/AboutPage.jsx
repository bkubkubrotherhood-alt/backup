import React, { useContext, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import KeywordsCloud from '@/components/KeywordsCloud';
import { Target, Eye, Shield, Award, Zap, Users, Milestone, Calendar, Flag } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';
import { translations } from '@/lib/translations';

const AboutPage = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const t = useMemo(() => (translations[language]?.aboutPage) || translations.en.aboutPage, [language]);
  
  const valueIcons = {
    'Safety First': Shield,
    'Quality & Excellence': Award,
    'Innovation': Zap,
    'Client Partnership': Users,
    'السلامة أولاً': Shield,
    'الجودة والتميز': Award,
    'الابتكار': Zap,
    'شراكة العميل': Users,
    'Önce Güvenlik': Shield,
    'Kalite ve Mükemmellik': Award,
    'İnovasyon': Zap,
    'Müşteri Ortaklığı': Users,
    '安全第一': Shield,
    '质量与卓越': Award,
    '创新': Zap,
    '客户伙伴关系': Users,
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };

  if (!t || !t.meta) {
    return <div>Loading...</div>;
  }
  
  const getCanonicalUrl = () => {
    let path = '/about';
    if (language === 'en') path = '/en/about';
    else if (language === 'tr') path = '/tr/about';
    else if (language === 'zh') path = '/cn/about';
    return `https://bku-website.online${path}`;
  };

  return (
    <>
      <Helmet>
        <title>{t.meta.title}</title>
        <meta name="description" content={t.meta.description} />
        <meta name="keywords" content={t.meta.keywords} />
        <link rel="canonical" href={getCanonicalUrl()} />
      </Helmet>
      
      <div className="bg-white" dir={isRtl ? 'rtl' : 'ltr'}>
        {/* Hero Section */}
        <section className="relative bg-gray-900 text-white py-32 md:py-48 overflow-hidden">
          <div className="absolute inset-0">
            <img
              alt="An abstract, dynamic image of construction cranes against a dramatic sky, representing BKU's vision and scale for tower crane kuwait."
              className="w-full h-full object-cover opacity-30" src="https://images.unsplash.com/photo-1684139274185-f058419ac27e" />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent"></div>
          </div>
          <div className="relative container mx-auto px-4 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: -30 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className="text-4xl md:text-6xl font-extrabold tracking-tight leading-tight"
            >
              {t.hero.title}
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 30 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.8, delay: 0.3, ease: 'easeOut' }}
              className="mt-4 text-lg md:text-xl max-w-3xl mx-auto text-gray-300"
            >
              {t.hero.subtitle}
            </motion.p>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-16 md:py-24 bg-gray-50">
            <div className="container mx-auto px-4">
                 <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.5 }}
                    transition={{ duration: 0.7 }}
                    className="max-w-4xl mx-auto text-center prose prose-lg prose-p:text-gray-600 prose-strong:text-gray-900"
                >
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">{t.story.title}</h2>
                    <p>{t.story.p1}</p>
                    <p>{t.story.p2}</p>
                </motion.div>
            </div>
        </section>

        {/* Mission & Vision Section */}
        <section className="py-16 md:py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 lg:gap-16 items-center">
              <motion.div initial={{ opacity: 0, x: isRtl ? 50 : -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.8 }} className="bg-gray-100/50 p-8 rounded-xl shadow-lg border border-gray-200">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-600 text-white p-3 rounded-full"><Target size={28} /></div>
                    <h2 className="text-3xl font-bold text-gray-900">{t.missionVision.missionTitle}</h2>
                  </div>
                  <p className="text-gray-600 leading-relaxed">{t.missionVision.missionText}</p>
              </motion.div>
              <motion.div initial={{ opacity: 0, x: isRtl ? -50 : 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.8 }} className="bg-gray-100/50 p-8 rounded-xl shadow-lg border border-gray-200">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-600 text-white p-3 rounded-full"><Eye size={28} /></div>
                    <h2 className="text-3xl font-bold text-gray-900">{t.missionVision.visionTitle}</h2>
                  </div>
                  <p className="text-gray-600 leading-relaxed">{t.missionVision.visionText}</p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Core Values Section */}
        <section className="py-16 md:py-24 bg-gray-800 text-white">
          <div className="container mx-auto px-4">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.7 }}
              className="text-3xl md:text-4xl font-bold text-center mb-12"
            >
              {t.values.title}
            </motion.h2>
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.3 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
            >
              {t.values.items.map((value, index) => {
                const Icon = valueIcons[value.name] || Shield;
                return (
                  <motion.div key={index} variants={itemVariants} className="text-center p-6 bg-gray-700/50 rounded-lg transition-transform duration-300 hover:scale-105 hover:bg-gray-700">
                    <div className="inline-block p-4 bg-blue-600 rounded-full mb-4">
                      <Icon className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{value.name}</h3>
                    <p className="text-gray-300">{value.description}</p>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>

        {/* Timeline Section */}
        <section className="py-16 md:py-24 bg-gray-50">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 text-center mb-16">{t.timeline.title}</h2>
                <div className="relative">
                    {/* The vertical line */}
                    <div className={`absolute top-0 h-full w-0.5 bg-gray-300 ${isRtl ? 'right-1/2 translate-x-1/2' : 'left-1/2 -translate-x-1/2'}`}></div>

                    {t.timeline.events.map((event, index) => {
                        const isAlignedRight = isRtl ? index % 2 !== 0 : index % 2 === 0;
                        const Icon = [Flag, Calendar, Milestone][index % 3];
                        return (
                            <motion.div 
                                key={index} 
                                className={`relative mb-12 flex w-full items-center ${isAlignedRight ? 'justify-start' : 'justify-end'}`}
                                initial={{ opacity: 0, x: isAlignedRight ? -50 : 50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true, amount: 0.5 }}
                                transition={{ duration: 0.8 }}
                            >
                                <div className={`relative w-[calc(50%-2.5rem)] ${isAlignedRight ? 'text-left' : 'text-right'}`}>
                                    <div className={`inline-block p-6 rounded-lg shadow-lg bg-white w-full`}>
                                        <p className="text-blue-600 font-bold text-lg mb-1">{event.year}</p>
                                        <h3 className="text-xl font-semibold text-gray-900 mb-2">{event.title}</h3>
                                        <p className="text-gray-600">{event.description}</p>
                                    </div>
                                </div>
                                <div className={`absolute z-10 ${isRtl ? 'right-1/2 translate-x-1/2' : 'left-1/2 -translate-x-1/2'}`}>
                                    <div className="bg-blue-600 text-white rounded-full p-3 border-4 border-white shadow-md">
                                        <Icon size={24} />
                                    </div>
                                </div>
                            </motion.div>
                        );
                    })}
                </div>
            </div>
        </section>
        
        <div className="bg-gray-800 pt-8">
            <div className="container mx-auto px-4">
                <KeywordsCloud />
            </div>
        </div>
      </div>
    </>
  );
};

export default AboutPage;