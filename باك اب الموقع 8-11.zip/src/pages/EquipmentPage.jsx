import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';

const EquipmentPage = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const tContent = {
    en: {
      title: "Our Equipment - BKU Crane Kuwait",
      subtitle: "Explore BKU Crane's extensive fleet of tower cranes and construction hoists from top brands like Liebherr, Potain, and Zoomlion in Kuwait. Find the right equipment for your project.",
      towerCranes: "Tower Cranes",
      towerCranesDesc: "A wide range of top-slewing, luffing-jib, and self-erecting cranes from world-class brands.",
      constructionHoists: "Construction Hoists",
      constructionHoistsDesc: "Efficient and safe vertical transport solutions for personnel and materials on your job site.",
      explore: "Explore"
    },
    ar: {
      title: "معداتنا - بي كيه يو كرين الكويت",
      subtitle: "اكتشف أسطول BKU Crane الواسع من الرافعات البرجية ومصاعد البناء من أفضل العلامات التجارية مثل Liebherr و Potain و Zoomlion في الكويت. اعثر على المعدات المناسبة لمشروعك.",
      towerCranes: "الرافعات البرجية",
      towerCranesDesc: "مجموعة واسعة من الرافعات ذات الدوران العلوي والذراع المتحرك وذاتية التركيب من علامات تجارية عالمية.",
      constructionHoists: "مصاعد البناء",
      constructionHoistsDesc: "حلول نقل عمودية فعالة وآمنة للأفراد والمواد في موقع عملك.",
      explore: "استكشف"
    },
    tr: {
      title: "Ekipmanlarımız - BKU Vinç Kuveyt",
      subtitle: "BKU Crane'in Kuveyt'teki Liebherr, Potain ve Zoomlion gibi en iyi markalardan oluşan geniş kule vinç ve inşaat asansörü filosunu keşfedin. Projeniz için doğru ekipmanı bulun.",
      towerCranes: "Kule Vinçler",
      towerCranesDesc: "Dünya standartlarında markalardan geniş bir yelpazede üstten döner, orsa kollu ve kendi kendine kurulan vinçler.",
      constructionHoists: "İnşaat Asansörleri",
      constructionHoistsDesc: "Şantiyenizde personel ve malzemeler için verimli ve güvenli dikey taşıma çözümleri.",
      explore: "Keşfet"
    },
    zh: {
      title: "我们的设备 - BKU起重机科威特",
      subtitle: "探索BKU Crane在科威特的广泛的塔式起重机和施工升降机机队，这些设备来自利勃海尔、波坦和中联重科等顶级品牌。为您的项目找到合适的设备。",
      towerCranes: "塔式起重机",
      towerCranesDesc: "来自世界级品牌的各种上回转、动臂和自升式起重机。",
      constructionHoists: "施工升降机",
      constructionHoistsDesc: "为您工地的员工和材料提供高效安全的垂直运输解决方案。",
      explore: "探索"
    }
  };
  
  const t = tContent[language] || tContent.en;

  const getLink = (path) => {
    if (language === 'ar') return path;
    const langCode = language === 'zh' ? 'cn' : language;
    return `/${langCode}${path}`;
  };
  
  const equipmentCategories = [
    {
      title: t.towerCranes,
      description: t.towerCranesDesc,
      link: getLink('/equipment/tower-cranes'),
      image: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/c573a3f25a217add53e4ea1161cb127c.jpg"
    },
    {
      title: t.constructionHoists,
      description: t.constructionHoistsDesc,
      link: getLink('/equipment/construction-hoists'),
      image: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/8fe0a1e6e3d7de22a73553aa4dce3c52.jpg"
    }
  ];
  
  const ArrowIcon = isRtl ? ChevronLeft : ChevronRight;

  return (
    <>
      <Helmet>
        <title>{t.title}</title>
        <meta name="description" content={t.subtitle} />
        <meta name="keywords" content={`equipment, heavy machinery, construction, ${'tower crane kuwait, '.repeat(10)}`} />
      </Helmet>
      <div style={{ display: 'none' }}>
        {'tower crane kuwait '.repeat(10)}
      </div>
      <div className="flex flex-col min-h-screen bg-gray-50" dir={isRtl ? 'rtl' : 'ltr'}>
        <main className="flex-grow">
          <section className="py-16 sm:py-24 bg-white">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <motion.h1
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7 }}
                  className="text-4xl md:text-5xl font-extrabold text-gray-800"
                >
                  {t.title}
                </motion.h1>
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7, delay: 0.2 }}
                  className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto"
                >
                  {t.subtitle}
                </motion.p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {equipmentCategories.map((category, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.6, delay: index * 0.15 }}
                    className="group"
                  >
                    <Link to={category.link} className="block rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 bg-white h-full flex flex-col">
                      <div className="relative h-64 overflow-hidden">
                        <img className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" alt={category.title} src={category.image} />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                      </div>
                      <div className="p-6 flex-grow flex flex-col">
                        <h3 className="text-2xl font-bold text-gray-800 mb-2">{category.title}</h3>
                        <p className="text-gray-600 mb-4 flex-grow">{category.description}</p>
                        <div className="mt-auto flex items-center font-semibold text-blue-600">
                          {t.explore}
                          <ArrowIcon className={`${isRtl ? 'mr-2' : 'ml-2'} h-5 w-5 transform group-hover:${isRtl ? 'translate-x-1' : '-translate-x-1'} transition-transform`} />
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>
      </div>
    </>
  );
};

export default EquipmentPage;