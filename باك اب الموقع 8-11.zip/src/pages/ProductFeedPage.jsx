
import React, { useContext, useEffect, useState } from 'react';
import { LanguageContext } from '@/context/LanguageContext';
import { towerCranesData } from '@/lib/towerCranesData.js';
import { catalogData } from '@/lib/catalogData.js';
import { translations } from '@/lib/translations';
import { getProducts } from '@/api/EcommerceApi.js';

const ProductFeedPage = () => {
    const { language } = useContext(LanguageContext);
    const [productsXml, setProductsXml] = useState('');
    const t = translations[language] || translations.en;
    
    useEffect(() => {
        const generateFeed = async () => {
            let ecommerceProducts = [];
            try {
                const response = await getProducts({ limit: 100 });
                if (response && response.products) {
                   ecommerceProducts = response.products;
                }
            } catch (error) {
                console.error("Failed to fetch ecommerce products:", error);
            }

            const host = "https://bku-website.online";

            const formatPriceForGoogle = (priceString) => {
                if (!priceString) return '';
                const numericPart = parseFloat(String(priceString).replace(/[^\d.]/g, ''));
                if (isNaN(numericPart)) return '';
                return `${numericPart.toFixed(2)} KWD`;
            };

            const products = [
                ...towerCranesData.en.map(crane => ({
                    id: crane.id,
                    title: `${crane.brand} ${crane.model} ${crane.category}`,
                    description: crane.description,
                    link: `${host}/en/equipment/tower-cranes/${crane.id}`,
                    image_link: crane.image,
                    availability: crane.availability && crane.availability.toLowerCase() === 'outofstock' ? 'out of stock' : 'in stock',
                    price: formatPriceForGoogle(crane.price),
                    brand: crane.brand,
                    gtin: crane.gtin,
                    mpn: crane.mpn,
                    condition: 'new',
                    item_group_id: crane.brand,
                })),
                ...catalogData.en.map(catalog => ({
                    id: catalog.id,
                    title: catalog.title,
                    description: catalog.description,
                    link: `${host}/en/catalog-sales/${catalog.id}`,
                    image_link: catalog.image,
                    availability: catalog.availability && catalog.availability.toLowerCase() === 'outofstock' ? 'out of stock' : 'in stock',
                    price: formatPriceForGoogle(catalog.price),
                    brand: 'BKU Crane',
                    gtin: `BKU-CATALOG-${catalog.id}`,
                    mpn: `BKU-CATALOG-${catalog.id}`,
                    condition: 'new',
                    item_group_id: 'Catalogs',
                })),
                ...ecommerceProducts.map(product => ({
                    id: product.id,
                    title: product.title,
                    description: product.description,
                    link: `${host}/en/products/${product.id}`,
                    image_link: product.images && product.images.length > 0 ? product.images[0].url : '',
                    availability: product.variants.some(v => v.inventory_quantity > 0 || !v.manage_inventory) ? 'in stock' : 'out of stock',
                    price: formatPriceForGoogle(`${(product.price_in_cents / 100).toFixed(2)} ${product.currency}`),                    brand: product.collections && product.collections.length > 0 ? product.collections[0].collection_id : 'BKU Crane',
                    gtin: '', // GTIN is not available in the current product structure
                    mpn: product.variants.length > 0 && product.variants[0].sku ? product.variants[0].sku : `ECOMM-${product.id}`,
                    condition: 'new',
                    item_group_id: 'Ecommerce Products',
                }))
            ];

            let xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
<channel>
<title>${t.productFeedPage ? t.productFeedPage.title : 'BKU Crane Products'}</title>
<link>${host}</link>
<description>${t.productFeedPage ? t.productFeedPage.description : 'Product feed for BKU Crane'}</description>`;

            products.forEach(product => {
                // Only include products with a valid price
                if (!product.price || product.price === '0.00 KWD' || product.price.trim() === 'KWD') {
                    return;
                }

                xml += `
<item>
    <g:id>${product.id || ''}</g:id>
    <g:title><![CDATA[${product.title || ''}]]></g:title>
    <g:description><![CDATA[${product.description || ''}]]></g:description>
    <g:link>${product.link || ''}</g:link>
    <g:image_link>${product.image_link || ''}</g:image_link>
    <g:availability>${product.availability || 'out of stock'}</g:availability>
    <g:price>${product.price}</g:price>
    <g:brand><![CDATA[${product.brand || 'BKU Crane'}]]></g:brand>
    ${product.gtin ? `<g:gtin>${product.gtin}</g:gtin>` : ''}
    <g:mpn>${product.mpn || ''}</g:mpn>
    <g:condition>${product.condition || 'new'}</g:condition>
    <g:item_group_id><![CDATA[${product.item_group_id || ''}]]></g:item_group_id>
</item>`;
            });

            xml += `
</channel>
</rss>`;

            setProductsXml(xml);
        };

        generateFeed();
    }, [language, t]);
    
    useEffect(() => {
        if (productsXml) {
            const blob = new Blob([productsXml], { type: 'application/xml' });
            const url = URL.createObjectURL(blob);
            window.location.replace(url);
        }
    }, [productsXml]);

    return (
        <div style={{ padding: '2rem', fontFamily: 'monospace' }}>
            Generating product feed... If you are not redirected, please refresh the page.
        </div>
    );
};

export default ProductFeedPage;
