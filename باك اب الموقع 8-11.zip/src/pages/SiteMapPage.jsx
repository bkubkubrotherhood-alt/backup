
import React from 'react';
import { Helmet } from 'react-helmet';
import { towerCranesData } from '@/lib/towerCranesData.js';
import { catalogData } from '@/lib/catalogData.js';
import { blogData } from '@/lib/blogData.js';

const languages = ['ar', 'en', 'tr', 'zh'];
const getLangPrefix = (lang) => {
  if (lang === 'ar') return '';
  if (lang === 'zh') return '/cn';
  return `/${lang}`;
};

const formatDate = (date) => {
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const lastMod = formatDate(new Date());

const SiteMapPage = () => {
    const baseUrl = 'https://www.bku-website.online';

    const staticPages = [
        { path: '/', priority: 1.0 },
        { path: '/about', priority: 0.8 },
        { path: '/services', priority: 0.8 },
        { path: '/services/maintenance', priority: 0.7 },
        { path: '/services/training', priority: 0.7 },
        { path: '/services/logistics', priority: 0.7 },
        { path: '/services/consultation', priority: 0.7 },
        { path: '/equipment', priority: 0.8 },
        { path: '/equipment/tower-cranes', priority: 0.9 },
        { path: '/equipment/construction-hoists', priority: 0.8 },
        { path: '/projects', priority: 0.8 },
        { path: '/contact', priority: 0.7 },
        { path: '/catalog-sales', priority: 0.8 },
        { path: '/store-locator', priority: 0.7 },
        { path: '/media', priority: 0.7 },
        { path: '/blog', priority: 0.8 },
        { path: '/seo-services', priority: 0.7 },
    ];
    
    const generateUrlSet = (urls) => {
        return urls.map(url => {
            const alternates = languages.map(lang => 
                `<xhtml:link rel="alternate" hreflang="${lang === 'zh' ? 'zh-CN' : lang}" href="${baseUrl}${getLangPrefix(lang)}${url.path}"/>`
            ).join('\n    ');
            
            return `
  <url>
    <loc>${baseUrl}${url.path}</loc>
    <lastmod>${url.lastmod || lastMod}</lastmod>
    <priority>${url.priority}</priority>
    ${alternates}
  </url>`;
        }).join('');
    };

    const allUrls = [];

    languages.forEach(lang => {
      const prefix = getLangPrefix(lang);
      staticPages.forEach(page => {
        allUrls.push({
          path: `${prefix}${page.path === '/' ? '' : page.path}`,
          priority: page.priority,
          lastmod: page.lastmod,
        });
      });

      const cranes = towerCranesData[lang] || towerCranesData.en;
      cranes.forEach(crane => {
        allUrls.push({ path: `${prefix}/equipment/tower-cranes/${crane.id}`, priority: 0.9 });
      });

      const catalogs = catalogData[lang] || catalogData.en;
      catalogs.forEach(item => {
        allUrls.push({ path: `${prefix}/catalog-sales/${item.id}`, priority: 0.8 });
      });

      const blogs = blogData[lang] || blogData.en;
      blogs.forEach(post => {
        allUrls.push({ path: `${prefix}/blog/${post.id}`, priority: 0.85, lastmod: post.datetime.split('T')[0] });
      });
    });

    const uniqueUrls = Array.from(new Set(allUrls.map(u => u.path))).map(path => {
      return allUrls.find(u => u.path === path);
    });

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${generateUrlSet(uniqueUrls)}
</urlset>`;

    return (
        <>
            <Helmet>
                <meta http-equiv="Content-Type" content="application/xml; charset=utf-8" />
            </Helmet>
            <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{xml}</pre>
        </>
    );
};

export default SiteMapPage;
