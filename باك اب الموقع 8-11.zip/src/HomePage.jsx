import React, { useContext } from 'react';
    import { Helmet } from 'react-helmet';
    import Hero from '@/components/sections/Hero';
    import ProductHighlights from '@/components/sections/ProductHighlights';
    import PartnersSection from '@/components/sections/PartnersSection';
    import NewsSection from '@/components/sections/NewsSection';
    import { LanguageContext } from '@/context/LanguageContext';

    const HomePage = () => {
      const { language } = useContext(LanguageContext);
      const canonicalHost = 'https://www.bku-website.online';

      const homeContent = {
        en: {
          title: "Tower Crane Kuwait | BKU | Rental & Sale | #1 Experts",
          description: "BKU Crane is your top choice for tower crane kuwait. We offer rental tower crane Kuwait services and have tower cranes for sale in Kuwait (Liebherr, Potain). As certified suppliers, we provide comprehensive solutions including luffing crane, self erecting tower crane, and construction crane for any project. For the best tower crane price, contact us.",
          keywords: "tower crane kuwait, tower crane, tower crane for sale, rental tower crane, Liebherr, Potain, construction crane, self erecting tower crane, luffing crane, tower crane price, BKU Crane, tower crane kuwat, تاور كرين الكويت, للايجار تاور كرين الكويت, للبيع تاور كرين الكويت",
          ogTitle: "BKU: The #1 for Tower Crane Kuwait Rental & Sale",
          ogDescription: "Leading provider of tower crane for sale in Kuwait and rental tower crane services. Your expert for everything related to tower crane kuwait. We specialize in Liebherr and Potain cranes.",
        },
        ar: {
          title: "تاور كرين الكويت | شركة الاخوة | ايجار وبيع | رقم #1",
          description: "شركة الاخوة الكويتية المتحدة هي خيارك الأول لخدمات tower crane kuwait (تاور كرين الكويت). نقدم خدمات ايجار و تاجير تاور كرين الكويت ولدينا تور كرين للبيع (Liebherr, Potain). بصفتنا موردين معتمدين، نوفر حلولاً شاملة لـ tower crane kuwait وأفضل سعر تور كرين.",
          keywords: "tower crane kuwait, تاور كرين الكويت, تاجير رافعه برجية, بيع رافعة برجية, للايجار رافعة برجية, تاجير رافعة برجية الكويت, بيع رافعة برجية الكويت, للايجار رافعه برجية الكويت, تاجير رافعه برجية في الكويت, بيع رافعه برجية في الكويت, للايجار رافعة برجية في الكويت, تاجير تور كرين, للبيع تور كرين, بيع تور كرين, للايجار تور كرين, للبيع تور كرين الكويت, للايجار تور كرين الكويت, للبيع تور كرين في الكويت, تاجير تور كرين في الكويت, للايجار تور كرين في الكويت, BKU Crane, سعر تور كرين",
          ogTitle: "تاور كرين الكويت | شركة الاخوة: ايجار وبيع",
          ogDescription: "الشركة الرائدة في بيع تور كرين في الكويت وخدمات تاجير تاور كرين الكويت. نحن خبراء في رافعات Liebherr و Potain، وجهتك الأولى لكل ما يتعلق بـ tower crane kuwait.",
        },
        zh: {
            title: "科威特塔式起重机 | BKU | 租赁与销售 | #1 专家",
            description: "BKU Crane是您在科威特塔式起重机领域的首选。我们提供科威特塔式起重机租赁服务，并销售科威特塔式起重机（利勃海尔、波坦）。作为认证供应商，我们为任何项目提供全面的解决方案，包括动臂起重机、自升式塔式起重机和建筑起重机。有关最佳塔式起重机价格，请联系我们。",
            keywords: "科威特塔式起重机, 塔式起重机, 待售塔式起重机, 租赁塔式起重机, 利勃海尔, 波坦, 建筑起重机, 自升式塔式起重机, 动臂起重机, 塔式起重机价格, BKU Crane, 科威特塔吊, 科威特塔机租赁, 科威特塔机销售",
            ogTitle: "BKU: 科威特塔式起重机租赁与销售第一选择",
            ogDescription: "科威特领先的塔式起重机销售和租赁服务提供商。您在科威特塔式起重机相关一切领域的专家。我们专注于利勃海尔和波坦起重机。",
        },
        tr: {
            title: "Kuveyt Kule Vinç | BKU | Kiralama & Satış | #1 Uzmanlar",
            description: "BKU Vinç, Kuveyt kule vinçleri için en iyi seçiminizdir. Kuveyt kule vinç kiralama hizmetleri sunuyoruz ve Kuveyt'te satılık kule vinçlerimiz (Liebherr, Potain) bulunmaktadır. Sertifikalı tedarikçiler olarak, her türlü proje için luffing vinç, kendinden kurmalı kule vinç ve inşaat vinci dahil olmak üzere kapsamlı çözümler sunuyoruz. En iyi kule vinç fiyatı için bize ulaşın.",
            keywords: "kuveyt kule vinç, kule vinç, satılık kule vinç, kiralık kule vinç, Liebherr, Potain, inşaat vinci, kendinden kurmalı kule vinç, luffing vinç, kule vinç fiyatı, BKU Vinç, kule vinç kuveyt, kiralık kule vinç kuveyt, satılık kule vinç kuveyt",
            ogTitle: "BKU: Kuveyt Kule Vinç Kiralama ve Satışında 1 Numara",
            ogDescription: "Kuveyt'te satılık kule vinç ve kiralık kule vinç hizmetlerinin lider sağlayıcısı. Kuveyt kule vinç ile ilgili her şey için uzmanınız. Liebherr ve Potain vinçlerinde uzmanız.",
        }
      };

      const t = homeContent[language] || homeContent.ar;

      const getCanonicalUrl = () => {
        let path = '';
        if (language === 'en') path = '/en';
        if (language === 'zh') path = '/cn';
        if (language === 'tr') path = '/tr';
        return `${canonicalHost}${path || '/'}`;
      };

      const webPageSchema = {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "url": getCanonicalUrl(),
        "name": t.title,
        "description": t.description,
        "keywords": t.keywords,
        "inLanguage": language,
        "mainEntity": {
          "@type": "Organization",
          "name": "شركة الاخوة الكويتيه المتحدة (BKU Crane)",
          "url": canonicalHost,
          "logo": "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/21c805987ec946d9b33c469e72b6ab57.png",
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+965-69306030",
            "contactType": "sales",
            "areaServed": "KW"
          },
          "knowsAbout": "tower crane kuwait"
        }
      };

      return (
        <>
          <Helmet>
            <title>{t.title}</title>
            <meta name="description" content={t.description} />
            <meta name="keywords" content={t.keywords} />
            <link rel="canonical" href={getCanonicalUrl()} />
            <meta property="og:title" content={t.ogTitle} />
            <meta property="og:description" content={t.ogDescription} />
            <meta property="og:url" content={getCanonicalUrl()} />
            <meta property="og:image" content={`${canonicalHost}/og-image.jpg`} />
            <meta property="og:image:width" content="1200" />
            <meta property="og:image:height" content="630" />
            <meta property="og:image:alt" content="A fleet of BKU's Liebherr and Potain tower cranes at a construction site in Kuwait. The best Tower Crane Kuwait service." />
            <meta name="twitter:card" content="summary_large_image" />
            <meta name="twitter:title" content={t.ogTitle} />
            <meta name="twitter:description" content={t.ogDescription} />
            <meta name="twitter:image" content={`${canonicalHost}/og-image.jpg`} />
            <script type="application/ld+json">{JSON.stringify(webPageSchema)}</script>
          </Helmet>
          
          <Hero />
          <ProductHighlights />
          <PartnersSection />
          <NewsSection />
        </>
      );
    };

    export default HomePage;