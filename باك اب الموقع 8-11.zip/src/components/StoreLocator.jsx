import React, { useEffect, useRef, useContext } from 'react';
import { LanguageContext } from '@/context/LanguageContext';

const StoreLocator = () => {
  const locatorRef = useRef(null);
  const { language } = useContext(LanguageContext);
  const GOOGLE_MAPS_API_KEY = "YOUR_API_KEY_HERE";

  const CONFIGURATION = {
    "locations": [
      {"title":"KUWAIT EVENT","address1":"Hawally","address2":"Kuwait, Kuwait","coords":{"lat":29.3387361,"lng":48.0062203}},
      {"title":"شركة الاخوة الكويتية المتحدة","address1":"حولي","address2":"حولي, Kuwait","coords":{"lat":29.341109,"lng":48.0194933},"placeId":"ChIJd308wk-dzz8RwYrlLo3z7h4"},
      {"title":"BKU EVENT","address1":"82Q3+9WR","address2":"Hawally, Kuwait","coords":{"lat":29.338434,"lng":48.004898},"placeId":"ChIJQW138ZWdzz8RE5zxzZJEv28"},
      {"title":"تأجير شاشات شركة هاي رزليوشن","address1":"Salem Al Mubarak Street","address2":"Salmiya, Kuwait","coords":{"lat":29.341374,"lng":48.0736595},"placeId":"ChIJ6bpIghidzz8RtRogk2YwqwI"},
      {"title":"تاجير شاشات عرض وأضاءة كيي","address1":"82R5+558","address2":"حولي, Kuwait","coords":{"lat":29.3362942,"lng":48.0199356},"placeId":"ChIJBfPBaQCdzz8RzYalXHH7ieE"}
    ],
    "mapOptions": {"center":{"lat":29.34,"lng":48.01},"fullscreenControl":true,"mapTypeControl":false,"streetViewControl":false,"zoom":12,"zoomControl":true,"maxZoom":17,"mapId":""},
    "mapsApiKey": GOOGLE_MAPS_API_KEY,
    "capabilities": {"input":false,"autocomplete":false,"directions":false,"distanceMatrix":false,"details":true,"actions":['directions', 'website', 'phone']}
  };

  useEffect(() => {
    const scriptId = 'google-maps-extended-library';
    if (!document.getElementById(scriptId)) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.type = 'module';
      script.src = 'https://ajax.googleapis.com/ajax/libs/@googlemaps/extended-component-library/0.6.11/index.min.js';
      document.head.appendChild(script);
    }

    const configureLocator = async () => {
      if (GOOGLE_MAPS_API_KEY === "YOUR_API_KEY_HERE") return;
      await customElements.whenDefined('gmpx-store-locator');
      if (locatorRef.current) {
        locatorRef.current.configureFromQuickBuilder(CONFIGURATION);
      }
    };

    configureLocator();
  }, []);

  if (GOOGLE_MAPS_API_KEY === "YOUR_API_KEY_HERE") {
    return (
      <div className="p-8 text-center text-red-600 bg-red-100 border border-red-300 rounded-md">
        <h3 className="font-bold text-lg mb-2">
          {language === 'ar' ? 'ميزة محدد مواقع الفروع معطلة' : 'Store Locator Feature is Disabled'}
        </h3>
        <p>
          {language === 'ar' 
            ? 'يرجى إضافة مفتاح Google Maps API في مكون StoreLocator.jsx لتفعيل هذه الميزة.' 
            : 'Please add a Google Maps API key in the StoreLocator.jsx component to enable this feature.'}
        </p>
      </div>
    );
  }

  return (
    <>
      <gmpx-api-loader key={GOOGLE_MAPS_API_KEY} solution-channel="GMP_QB_locatorplus_v11_cABD"></gmpx-api-loader>
      <gmpx-store-locator ref={locatorRef} style={{width: '100%', height: '100%'}}></gmpx-store-locator>
    </>
  );
};

export default StoreLocator;