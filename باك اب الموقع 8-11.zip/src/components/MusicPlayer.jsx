import React, { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';

const MusicPlayer = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef(null);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(error => {
          console.error("Audio play failed:", error);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  return (
    <>
      <audio ref={audioRef} src="https://4up4.com//uploads/file_2025-10-06_171136.mp3" loop />
      <div className="fixed bottom-5 right-5 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={togglePlay}
          className="bg-white/80 backdrop-blur-sm rounded-full shadow-lg hover:bg-white"
        >
          {isPlaying ? <Volume2 className="h-5 w-5 text-gray-700" /> : <VolumeX className="h-5 w-5 text-gray-500" />}
        </Button>
      </div>
    </>
  );
};

export default MusicPlayer;