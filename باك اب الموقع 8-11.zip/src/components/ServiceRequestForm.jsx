import React, { useRef, useState, useContext } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';
import emailjs from '@emailjs/browser';

const ServiceRequestForm = ({ serviceName, formTitle, pageName }) => {
  const form = useRef();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const { language } = useContext(LanguageContext);

  const translations = {
    en: {
      name: "Your Name",
      company: "Company Name",
      email: "Email",
      phone: "Phone Number",
      message: "Your Message",
      submit: "Submit Request",
      sending: "Sending...",
      successTitle: "Message Sent!",
      successDescription: "Thanks for your inquiry. We will get back to you soon.",
      errorTitle: "Oops! Something went wrong.",
      errorDescription: "There was a problem with your request. Please try again."
    },
    ar: {
      name: "الاسم",
      company: "اسم الشركة",
      email: "البريد الإلكتروني",
      phone: "رقم الهاتف",
      message: "الرسالة",
      submit: "إرسال الطلب",
      sending: "جاري الإرسال...",
      successTitle: "تم إرسال الرسالة!",
      successDescription: "شكراً لاستفسارك. سوف نرد عليك قريباً.",
      errorTitle: "عفوًا! حدث خطأ ما.",
      errorDescription: "حدثت مشكلة في طلبك. يرجى المحاولة مرة أخرى."
    },
    zh: {
      name: "您的姓名",
      company: "公司名称",
      email: "电子邮件",
      phone: "电话号码",
      message: "您的留言",
      submit: "提交请求",
      sending: "发送中...",
      successTitle: "消息已发送！",
      successDescription: "感谢您的咨询。我们会尽快回复您。",
      errorTitle: "哎呀！出错了。",
      errorDescription: "您的请求有问题。请再试一次。"
    },
    tr: {
      name: "Adınız",
      company: "Şirket Adı",
      email: "E-posta",
      phone: "Telefon Numarası",
      message: "Mesajınız",
      submit: "İstek Gönder",
      sending: "Gönderiliyor...",
      successTitle: "Mesaj Gönderildi!",
      successDescription: "İlginiz için teşekkürler. En kısa sürede size geri döneceğiz.",
      errorTitle: "Hay aksi! Bir şeyler ters gitti.",
      errorDescription: "İsteğinizle ilgili bir sorun oluştu. Lütfen tekrar deneyin."
    }
  };

  const t = translations[language] || translations.en;

  const sendEmail = (e) => {
    e.preventDefault();
    setIsLoading(true);

    // Manually construct the message to include the service name and page name
    const formData = new FormData(form.current);
    const templateParams = {
      from_name: formData.get('from_name'),
      company_name: formData.get('company_name'),
      from_email: formData.get('from_email'),
      from_phone: formData.get('from_phone'),
      message: `Service Request: ${serviceName}\nPage: ${pageName}\n\n${formData.get('message')}`
    };

    emailjs.send('service_gkl5ueg', 'template_vxo3769', templateParams, 'aIV30VFPKcE2h5A_w')
      .then((result) => {
          toast({
            title: t.successTitle,
            description: t.successDescription,
          });
          form.current.reset();
      }, (error) => {
          toast({
            title: t.errorTitle,
            description: error.text || t.errorDescription,
            variant: 'destructive',
          });
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-8 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm shadow-2xl rounded-xl border border-gray-200 dark:border-gray-700">
      <h2 className="text-3xl font-bold text-center mb-6 text-gray-900 dark:text-white">{formTitle}</h2>
      <form ref={form} onSubmit={sendEmail} className="space-y-6">
        <Input type="text" name="from_name" placeholder={t.name} required className="bg-gray-50 dark:bg-gray-800" />
        <Input type="text" name="company_name" placeholder={t.company} className="bg-gray-50 dark:bg-gray-800" />
        <Input type="email" name="from_email" placeholder={t.email} required className="bg-gray-50 dark:bg-gray-800" />
        <Input type="tel" name="from_phone" placeholder={t.phone} className="bg-gray-50 dark:bg-gray-800" />
        <Textarea name="message" placeholder={t.message} required rows={5} className="bg-gray-50 dark:bg-gray-800" />
        <Button type="submit" className="w-full text-lg" disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : t.submit}
        </Button>
      </form>
    </div>
  );
};

export default ServiceRequestForm;