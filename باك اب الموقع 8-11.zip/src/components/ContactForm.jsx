import React, { useRef, useState, useContext } from 'react';
import emailjs from '@emailjs/browser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';

const ContactForm = () => {
  const form = useRef();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const { language } = useContext(LanguageContext);

  const t = {
    en: {
        formTitle: "Send Us a Message",
        name: "Your Name",
        email: "Your Email",
        phone: "Your Phone Number",
        message: "Your Message",
        submit: "Send Message",
        successTitle: "Success!",
        successMessage: "Your message has been sent successfully.",
        errorTitle: "Error!",
        errorMessage: "Failed to send message. Please try again later."
    },
    ar: {
        formTitle: "أرسل لنا رسالة",
        name: "اسمك",
        email: "بريدك الإلكتروني",
        phone: "رقم هاتفك",
        message: "رسالتك",
        submit: "أرسل الرسالة",
        successTitle: "نجاح!",
        successMessage: "تم إرسال رسالتك بنجاح.",
        errorTitle: "خطأ!",
        errorMessage: "فشل إرسال الرسالة. يرجى المحاولة مرة أخرى لاحقًا."
    },
    tr: {
        formTitle: "Bize Mesaj Gönderin",
        name: "Adınız",
        email: "E-postanız",
        phone: "Telefon Numaranız",
        message: "Mesajınız",
        submit: "Mesaj Gönder",
        successTitle: "Başarılı!",
        successMessage: "Mesajınız başarıyla gönderildi.",
        errorTitle: "Hata!",
        errorMessage: "Mesaj gönderilemedi. Lütfen daha sonra tekrar deneyin."
    },
    zh: {
        formTitle: "给我们发消息",
        name: "您的姓名",
        email: "您的电子邮件",
        phone: "您的电话号码",
        message: "您的留言",
        submit: "发送消息",
        successTitle: "成功！",
        successMessage: "您的消息已成功发送。",
        errorTitle: "错误！",
        errorMessage: "发送消息失败。请稍后再试。"
    }
  }[language] || {
    ar: {
        formTitle: "أرسل لنا رسالة",
        name: "اسمك",
        email: "بريدك الإلكتروني",
        phone: "رقم هاتفك",
        message: "رسالتك",
        submit: "أرسل الرسالة",
        successTitle: "نجاح!",
        successMessage: "تم إرسال رسالتك بنجاح.",
        errorTitle: "خطأ!",
        errorMessage: "فشل إرسال الرسالة. يرجى المحاولة مرة أخرى لاحقًا."
    }
  }.ar;


  const sendEmail = (e) => {
    e.preventDefault();
    setIsLoading(true);

    emailjs.sendForm('service_gkl5ueg', 'template_vxo3769', form.current, 'aIV30VFPKcE2h5A_w')
      .then((result) => {
          toast({
            title: t.successTitle,
            description: t.successMessage,
          });
          form.current.reset();
      }, (error) => {
          toast({
            title: t.errorTitle,
            description: error.text || t.errorMessage,
            variant: 'destructive',
          });
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <div className="w-full">
      <h2 className="text-3xl font-bold text-center mb-6 text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-400">{t.formTitle}</h2>
      <form ref={form} onSubmit={sendEmail} className="space-y-6">
        <div className="relative">
          <Input 
            type="text" 
            name="from_name" 
            id="from_name"
            placeholder=" " 
            required 
            className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" 
          />
          <label 
            htmlFor="from_name" 
            className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white/0 dark:bg-transparent px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 start-1 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto"
          >
            {t.name}
          </label>
        </div>
        <div className="relative">
          <Input 
            type="email" 
            name="from_email" 
            id="from_email"
            placeholder=" " 
            required 
            className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
          />
           <label htmlFor="from_email" className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white/0 dark:bg-transparent px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 start-1">{t.email}</label>
        </div>
        <div className="relative">
          <Input 
            type="tel" 
            name="from_phone" 
            id="from_phone"
            placeholder=" " 
            className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
          />
          <label htmlFor="from_phone" className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white/0 dark:bg-transparent px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 start-1">{t.phone}</label>
        </div>
         <div className="relative">
          <Textarea 
            name="message" 
            id="message"
            placeholder=" " 
            required 
            rows={5} 
            className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
          />
          <label htmlFor="message" className="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-4 scale-75 top-4 z-10 origin-[0] bg-white/0 dark:bg-transparent px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-8 peer-focus:top-4 peer-focus:scale-75 peer-focus:-translate-y-4 start-1">{t.message}</label>
        </div>
        <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg py-6 transition-all duration-300 ease-in-out transform hover:scale-105" disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-6 w-6 animate-spin" /> : t.submit}
        </Button>
      </form>
    </div>
  );
};

export default ContactForm;