import React, { useState, useEffect, useRef } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { Play, Pause, RotateCcw, Camera, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const TowerCraneVideo = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentScene, setCurrentScene] = useState(0);
  const [dronePosition, setDronePosition] = useState({ x: 0, y: 0, z: 0 });
  const craneControls = useAnimation();
  const droneControls = useAnimation();
  const hookControls = useAnimation();
  const containerRef = useRef(null);

  const scenes = [
    { name: 'Wide Shot', position: { x: 0, y: -20, z: 50 }, rotation: 0 },
    { name: 'Close Up', position: { x: 20, y: 10, z: 20 }, rotation: 15 },
    { name: 'Top View', position: { x: 0, y: -50, z: 80 }, rotation: 0 },
    { name: 'Side Sweep', position: { x: -40, y: 0, z: 30 }, rotation: -25 }
  ];

  useEffect(() => {
    if (isPlaying) {
      startAnimation();
    } else {
      stopAnimation();
    }
  }, [isPlaying]);

  const startAnimation = async () => {
    // Crane rotation animation
    craneControls.start({
      rotate: [0, 360],
      transition: {
        duration: 20,
        repeat: Infinity,
        ease: "linear"
      }
    });

    // Hook movement
    hookControls.start({
      y: [0, 40, 0],
      transition: {
        duration: 8,
        repeat: Infinity,
        ease: "easeInOut"
      }
    });

    // Drone movement
    droneControls.start({
      x: [-100, 100, -100],
      y: [-50, 50, -50],
      rotate: [-10, 10, -10],
      transition: {
        duration: 15,
        repeat: Infinity,
        ease: "easeInOut"
      }
    });
  };

  const stopAnimation = () => {
    craneControls.stop();
    hookControls.stop();
    droneControls.stop();
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    toast({
      title: isPlaying ? "Video Paused" : "Video Playing",
      description: isPlaying ? "Animation stopped" : "Drone footage rolling!",
    });
  };

  const handleSceneChange = (sceneIndex) => {
    setCurrentScene(sceneIndex);
    toast({
      title: `Scene Changed`,
      description: `Now viewing: ${scenes[sceneIndex].name}`,
    });
  };

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentScene(0);
    craneControls.set({ rotate: 0 });
    hookControls.set({ y: 0 });
    droneControls.set({ x: 0, y: 0, rotate: 0 });
    toast({
      title: "Reset Complete",
      description: "All animations reset to starting position",
    });
  };

  const handleSettings = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Sky */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-400 via-blue-600 to-blue-800">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-20 h-20 bg-yellow-300 rounded-full blur-sm"></div>
          <div className="absolute top-20 right-20 w-32 h-8 bg-white rounded-full opacity-60"></div>
          <div className="absolute top-32 left-1/3 w-24 h-6 bg-white rounded-full opacity-40"></div>
        </div>
      </div>

      {/* Ground */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-600 to-gray-500">
        <div className="absolute inset-0 bg-gradient-to-r from-gray-700 via-gray-600 to-gray-700 opacity-50"></div>
      </div>

      {/* Construction Site Elements */}
      <div className="absolute bottom-32 left-10 w-16 h-8 bg-yellow-500 rounded transform rotate-12"></div>
      <div className="absolute bottom-32 right-20 w-12 h-6 bg-orange-600 rounded"></div>
      <div className="absolute bottom-32 left-1/3 w-8 h-4 bg-red-500 rounded"></div>

      {/* Main Scene Container */}
      <div 
        ref={containerRef}
        className="absolute inset-0 flex items-center justify-center perspective-1000"
        style={{
          transform: `translate3d(${scenes[currentScene].position.x}px, ${scenes[currentScene].position.y}px, ${scenes[currentScene].position.z}px) rotateY(${scenes[currentScene].rotation}deg)`,
          transition: 'transform 2s ease-in-out'
        }}
      >
        {/* Tower Crane */}
        <motion.div
          animate={craneControls}
          className="relative"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Crane Base */}
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2">
            <div className="w-8 h-32 bg-gradient-to-t from-gray-700 to-gray-500 relative">
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-12 h-2 bg-gray-600"></div>
              <div className="absolute top-8 left-1/2 transform -translate-x-1/2 w-10 h-1 bg-gray-600"></div>
              <div className="absolute top-16 left-1/2 transform -translate-x-1/2 w-10 h-1 bg-gray-600"></div>
              <div className="absolute top-24 left-1/2 transform -translate-x-1/2 w-10 h-1 bg-gray-600"></div>
            </div>
          </div>

          {/* Crane Arm */}
          <div className="absolute bottom-32 left-1/2 transform -translate-x-1/2">
            <div className="w-48 h-3 bg-gradient-to-r from-yellow-500 to-yellow-400 relative">
              <div className="absolute top-1/2 left-0 transform -translate-y-1/2 w-2 h-6 bg-yellow-600"></div>
              <div className="absolute top-1/2 left-12 transform -translate-y-1/2 w-1 h-4 bg-yellow-600"></div>
              <div className="absolute top-1/2 left-24 transform -translate-y-1/2 w-1 h-4 bg-yellow-600"></div>
              <div className="absolute top-1/2 left-36 transform -translate-y-1/2 w-1 h-4 bg-yellow-600"></div>
              <div className="absolute top-1/2 right-0 transform -translate-y-1/2 w-2 h-6 bg-yellow-600"></div>
            </div>
          </div>

          {/* Counter Weight */}
          <div className="absolute bottom-32 left-1/2 transform translate-x-8">
            <div className="w-16 h-3 bg-gradient-to-r from-gray-600 to-gray-500 relative">
              <div className="absolute top-1/2 right-0 transform -translate-y-1/2 w-4 h-8 bg-gray-700"></div>
            </div>
          </div>

          {/* Hook and Cable */}
          <motion.div
            animate={hookControls}
            className="absolute bottom-29 left-20"
          >
            <div className="w-0.5 h-16 bg-gray-800 relative">
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-gray-700 rounded"></div>
              <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 w-6 h-2 bg-gray-600"></div>
            </div>
          </motion.div>

          {/* Crane Cabin */}
          <div className="absolute bottom-32 left-1/2 transform -translate-x-2">
            <div className="w-6 h-4 bg-gradient-to-b from-blue-500 to-blue-600 rounded-t relative">
              <div className="absolute inset-1 bg-blue-300 rounded opacity-60"></div>
            </div>
          </div>
        </motion.div>

        {/* Drone */}
        <motion.div
          animate={droneControls}
          className="absolute top-1/3 left-1/2 transform -translate-x-1/2"
        >
          <div className="relative">
            {/* Drone Body */}
            <div className="w-8 h-2 bg-gradient-to-r from-gray-800 to-gray-700 rounded-full relative">
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-1 bg-red-500 rounded"></div>
            </div>
            
            {/* Propellers */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 0.1, repeat: Infinity, ease: "linear" }}
              className="absolute -top-1 -left-2 w-4 h-4 border-2 border-gray-400 rounded-full opacity-30"
            ></motion.div>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 0.1, repeat: Infinity, ease: "linear" }}
              className="absolute -top-1 -right-2 w-4 h-4 border-2 border-gray-400 rounded-full opacity-30"
            ></motion.div>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 0.1, repeat: Infinity, ease: "linear" }}
              className="absolute -bottom-1 -left-2 w-4 h-4 border-2 border-gray-400 rounded-full opacity-30"
            ></motion.div>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 0.1, repeat: Infinity, ease: "linear" }}
              className="absolute -bottom-1 -right-2 w-4 h-4 border-2 border-gray-400 rounded-full opacity-30"
            ></motion.div>
          </div>
        </motion.div>
      </div>

      {/* Control Panel */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-black/80 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <div className="flex items-center gap-4 mb-4">
          <Button
            onClick={handlePlayPause}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white"
          >
            {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isPlaying ? 'Pause' : 'Play'}
          </Button>
          
          <Button
            onClick={handleReset}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          
          <Button
            onClick={handleSettings}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10"
          >
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>

        <div className="flex gap-2">
          {scenes.map((scene, index) => (
            <Button
              key={index}
              onClick={() => handleSceneChange(index)}
              variant={currentScene === index ? "default" : "outline"}
              className={`text-xs ${
                currentScene === index 
                  ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white" 
                  : "border-white/30 text-white hover:bg-white/10"
              }`}
            >
              <Camera className="w-3 h-3 mr-1" />
              {scene.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Status Display */}
      <div className="absolute top-8 left-8 bg-black/60 backdrop-blur-sm rounded-lg p-4 text-white">
        <h2 className="text-xl font-bold mb-2 bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
          Tower Crane Drone Video
        </h2>
        <div className="space-y-1 text-sm">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span>{isPlaying ? 'Recording' : 'Standby'}</span>
          </div>
          <div>Scene: {scenes[currentScene].name}</div>
          <div>Drone Status: Active</div>
        </div>
      </div>

      {/* Cinematic Overlay */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-black/40 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black/40 to-transparent"></div>
        <div className="absolute top-0 bottom-0 left-0 w-16 bg-gradient-to-r from-black/20 to-transparent"></div>
        <div className="absolute top-0 bottom-0 right-0 w-16 bg-gradient-to-l from-black/20 to-transparent"></div>
      </div>
    </div>
  );
};

export default TowerCraneVideo;