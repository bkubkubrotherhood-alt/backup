import React, { useState, useContext, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { LanguageContext } from '@/context/LanguageContext';
import { towerCranesData } from '@/lib/towerCranesData.jsx';
import { blogData } from '@/lib/blogData.js';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const SearchModal = ({ isOpen, setIsOpen }) => {
  const { language } = useContext(LanguageContext);
  const [searchTerm, setSearchTerm] = useState('');
  const location = useLocation();

  const getLangPrefix = (pathname) => {
    const segments = pathname.split('/').filter(Boolean);
    if (['en', 'cn', 'tr'].includes(segments[0])) {
        return `/${segments[0]}`;
    }
    return '';
  };
  const langPrefix = getLangPrefix(location.pathname);

  const content = {
    en: {
      title: "Search Our Site",
      placeholder: "Search for cranes, articles...",
      noResults: "No results found.",
      cranes: "Cranes",
      blog: "Blog Articles",
    },
    ar: {
      title: "ابحث في موقعنا",
      placeholder: "ابحث عن الرافعات، المقالات...",
      noResults: "لم يتم العثور على نتائج.",
      cranes: "الرافعات",
      blog: "مقالات المدونة",
    },
    zh: {
      title: "搜索我们的网站",
      placeholder: "搜索起重机、文章...",
      noResults: "未找到结果。",
      cranes: "起重机",
      blog: "博客文章",
    },
    tr: {
      title: "Sitemizde Arama Yapın",
      placeholder: "Vinçleri, makaleleri arayın...",
      noResults: "Sonuç bulunamadı.",
      cranes: "Vinçler",
      blog: "Blog Yazıları",
    }
  };

  const t = content[language] || content.ar;

  const allCranes = useMemo(() => towerCranesData[language] || towerCranesData.en, [language]);
  const allPosts = useMemo(() => blogData[language] || blogData.en, [language]);
  
  const [filteredCranes, setFilteredCranes] = useState([]);
  const [filteredPosts, setFilteredPosts] = useState([]);

  useEffect(() => {
    if (searchTerm.length > 2) {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      
      const cranes = allCranes.filter(crane => 
        (crane.title || '').toLowerCase().includes(lowerCaseSearchTerm) ||
        (crane.description || '').toLowerCase().includes(lowerCaseSearchTerm)
      );
      setFilteredCranes(cranes);

      const posts = allPosts.filter(post =>
        (post.title || '').toLowerCase().includes(lowerCaseSearchTerm) ||
        (post.content || '').toLowerCase().includes(lowerCaseSearchTerm)
      );
      setFilteredPosts(posts);

    } else {
      setFilteredCranes([]);
      setFilteredPosts([]);
    }
  }, [searchTerm, allCranes, allPosts]);

  const handleClose = () => {
    setIsOpen(false);
    setSearchTerm('');
  };

  const hasResults = filteredCranes.length > 0 || filteredPosts.length > 0;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[625px] p-0" dir={language === 'ar' ? 'rtl' : 'ltr'}>
        <DialogHeader className="p-6 pb-0">
          <DialogTitle>{t.title}</DialogTitle>
        </DialogHeader>
        <div className="p-6">
          <Input
            placeholder={t.placeholder}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="text-lg"
          />
        </div>
        
        {searchTerm.length > 2 && (
          <div className="max-h-[60vh] overflow-y-auto px-6 pb-6">
            <AnimatePresence>
              {!hasResults ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center text-gray-500 py-8"
                >
                  {t.noResults}
                </motion.div>
              ) : (
                <>
                  {filteredCranes.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-sm font-semibold text-gray-500 uppercase mb-3">{t.cranes}</h3>
                      <ul className="space-y-2">
                        {filteredCranes.map((crane, index) => (
                          <motion.li
                            key={`crane-${crane.id}`}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                          >
                            <Link to={`${langPrefix}/equipment/tower-cranes/${crane.id}`} onClick={handleClose} className="block p-3 rounded-md hover:bg-gray-100">
                              <p className="font-semibold text-gray-800">{crane.title}</p>
                              <p className="text-sm text-gray-500 truncate">{crane.description}</p>
                            </Link>
                          </motion.li>
                        ))}
                      </ul>
                    </div>
                  )}
                   {filteredPosts.length > 0 && (
                    <div>
                      <h3 className="text-sm font-semibold text-gray-500 uppercase mb-3">{t.blog}</h3>
                      <ul className="space-y-2">
                        {filteredPosts.map((post, index) => (
                          <motion.li
                            key={`post-${post.id}`}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: (filteredCranes.length + index) * 0.05 }}
                          >
                            <Link to={`${langPrefix}/blog/${post.id}`} onClick={handleClose} className="block p-3 rounded-md hover:bg-gray-100">
                              <p className="font-semibold text-gray-800">{post.title}</p>
                              <p className="text-sm text-gray-500 truncate">{post.content.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1')}</p>
                            </Link>
                          </motion.li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              )}
            </AnimatePresence>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default SearchModal;