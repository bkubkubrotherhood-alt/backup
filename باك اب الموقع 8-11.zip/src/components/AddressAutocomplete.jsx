import React, { useContext } from 'react';
import GooglePlacesAutocomplete from 'react-google-places-autocomplete';
import { LanguageContext } from '@/context/LanguageContext';
import { Input } from '@/components/ui/input';

const AddressAutocomplete = ({ onSelect }) => {
  const { language } = useContext(LanguageContext);

  const GOOGLE_MAPS_API_KEY = "YOUR_GOOGLE_MAPS_API_KEY_HERE";

  if (GOOGLE_MAPS_API_KEY === "YOUR_GOOGLE_MAPS_API_KEY_HERE") {
    // Render a simple input if the API key is missing, instead of a warning.
    return (
      <Input 
        type="text" 
        placeholder={language === 'ar' ? 'أدخل عنوانك يدويًا...' : 'Enter your address manually...'}
        onChange={(e) => onSelect({ label: e.target.value, value: null })}
        className="dark:bg-gray-700 dark:text-white"
      />
    );
  }

  return (
    <GooglePlacesAutocomplete
      apiKey={GOOGLE_MAPS_API_KEY}
      selectProps={{
        onChange: onSelect,
        placeholder: language === 'ar' ? 'ابحث عن عنوانك...' : 'Search for your address...',
        styles: {
          input: (provided) => ({
            ...provided,
            height: '2.5rem',
            padding: '0.5rem 0.75rem',
            fontSize: '0.875rem',
            borderRadius: '0.375rem',
            borderColor: '#d1d5db',
          }),
          option: (provided, state) => ({
            ...provided,
            backgroundColor: state.isFocused ? '#dbeafe' : 'white',
            color: '#1f2937',
          }),
          singleValue: (provided) => ({
            ...provided,
            color: '#1f2937',
          }),
        },
        className: 'w-full',
      }}
      autocompletionRequest={{
        componentRestrictions: {
          country: ['kw', 'sa', 'qa', 'ae', 'bh', 'om'],
        },
      }}
    />
  );
};

export default AddressAutocomplete;