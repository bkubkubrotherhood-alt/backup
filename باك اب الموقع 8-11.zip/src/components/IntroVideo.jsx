import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

const IntroVideo = ({ onFinish }) => {
  const videoId = 'aFQvB7nvc_w';
  const embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1&controls=0&showinfo=0&rel=0&iv_load_policy=3&modestbranding=1&loop=0`;

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center"
    >
      <div className="relative w-full max-w-4xl aspect-video">
        <iframe
          src={embedUrl}
          title="BKU CRANE Introduction Video"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="w-full h-full"
        ></iframe>
      </div>
      <button
        onClick={onFinish}
        className="absolute top-4 right-4 text-white bg-black bg-opacity-50 rounded-full p-2 hover:bg-opacity-75 transition-colors"
        aria-label="Close video"
      >
        <X size={24} />
      </button>
    </motion.div>
  );
};

export default IntroVideo;