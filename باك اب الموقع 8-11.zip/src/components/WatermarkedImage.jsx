import React from 'react';

const WatermarkedImage = ({ src, alt }) => {
  return (
    <div className="relative group w-full h-full">
      <img src={src} alt={alt} className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100 p-4">
        <div className="text-center text-white break-words">
          <p className="font-bold text-sm md:text-base">bku-website.online</p>
          <p className="text-xs md:text-sm">69306030 | 65121663</p>
        </div>
      </div>
    </div>
  );
};

export default WatermarkedImage;