import React, { useContext } from 'react';
import { LanguageContext } from '@/context/LanguageContext';

const KeywordsCloud = () => {
  const { language } = useContext(LanguageContext);

  const keywordsData = {
    en: {
      title: "Explore Our Specialties",
      keywords: [
        "tower crane kuwait", "Liebherr", "Potain", "Rental", "tower crane", "2 ton jib crane", "tower crane for sale", "tower crane price", "construction crane", "self erecting tower crane", "potain crane", "mobile tower crane", "self erecting tower crane for sale", "luffing crane", "tower crane companies", "self erecting crane", "liebherr tower crane", "used tower crane for sale", "potain tower crane", "portable tower crane", "tower crane cost", "building crane", "construction crane for sale", "tower crane camera", "potain self erecting crane", "telescopic boom crane", "construction crane price", "small tower crane", "lr 11000", "BKU CRANE", "heavy equipment", "United Brothers Company", "tower cranes", "tower crane kuwait"
      ]
    },
    ar: {
      title: "اكتشف تخصصاتنا",
      keywords: [
        "تور كرين الكويت", "تاور كرين الكويت", "تاجير رافعه برجية", "بيع رافعة برجية", "للايجار رافعة برجية", "تاجير رافعة برجية الكويت", "بيع رافعة برجية الكويت", "للايجار رافعه برجية الكويت", "تاجير رافعه برجية في الكويت", "بيع رافعه برجية في الكويت", "للايجار رافعة برجية في الكويت", "تاجير تور كرين", "للبيع تور كرين", "للايجار تور كرين", "للبيع تور كرين الكويت", "للايجار تور كرين الكويت", "للبيع تور كرين في الكويت", "تاجير تور كرين في الكويت", "للايجار تور كرين في الكويت", "BKU CRANE", "شركة الاخوة الكويتية المتحدة", "معدات ثقيلة", "liebherr", "potain", "zoomlion", "yongmao", "fassi f28", "grove 4100l", "grove 6300l", "kato 250", "mc 85 potain", "potain mc 310 k12", "potain mr 608", "rk450", "zoomlion w12000 450", "أنواع الرافعات البرجية", "الرافعات البرجية", "الرافعة البرجية", "تركيب الرافعة البرجية", "تور كرين", "سعر الرافعة البرجية", "طريقة تركيب الرافعات البرجية", "كرين تاور", "كيفية تركيب الرافعات البرجية"
      ]
    },
    tr: {
        title: "Uzmanlık Alanlarımızı Keşfedin",
        keywords: [
            "kule vinç Kuveyt", "Liebherr", "Potain", "kiralık", "kule vinç", "2 tonluk pergel vinç", "satılık kule vinç", "kule vinç fiyatı", "inşaat vinci", "kendinden kurmalı kule vinç", "potain vinç", "mobil kule vinç", "satılık kendinden kurmalı kule vinç", "luffing vinç", "kule vinç şirketleri", "kendinden kurmalı vinç", "liebherr kule vinç", "satılık ikinci el kule vinç", "potain kule vinç", "portatif kule vinç", "kule vinç maliyeti", "bina vinci", "inşaat vinci fiyatı", "küçük kule vinç", "lr 11000", "BKU CRANE", "ağır ekipman", "Birleşik Kardeşler Şirketi", "kule vinçler", "kule vinç kuveyt"
        ]
    },
    zh: {
      title: "探索我们的专业领域",
      keywords: [
        "科威特塔式起重机", "利勃海尔", "波坦", "租赁", "塔式起重机", "2吨悬臂起重机", "待售塔式起重机", "塔式起重机价格", "建筑起重机", "自升式塔式起重机", "波坦起重机", "移动式塔式起重机", "待售自升式塔式起重机", "动臂起重机", "塔式起重机公司", "自升式起重机", "利勃海尔塔式起重机", "待售二手塔式起重机", "波坦塔式起重机", "便携式塔式起重机", "塔式起重机成本", "建筑起重机", "建筑起重机价格", "小型塔式起重机", "lr 11000", "BKU CRANE", "重型设备", "联合兄弟公司", "塔式起重机", "科威特塔式起重机"
      ]
    }
  };

  const t = keywordsData[language] || keywordsData.en;

  return (
    <div className="py-8">
      <p className="font-semibold text-white mb-4 text-center md:text-start">{t.title}</p>
      <div className="flex flex-wrap gap-2 justify-center md:justify-start">
        {t.keywords.map((keyword, index) => (
          <span
            key={index}
            className="bg-gray-700 text-gray-300 text-xs font-medium px-3 py-1 rounded-full hover:bg-blue-600 hover:text-white transition-colors cursor-default"
          >
            {keyword}
          </span>
        ))}
      </div>
    </div>
  );
};

export default KeywordsCloud;