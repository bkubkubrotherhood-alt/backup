import React from 'react';

const HeroImage = () => {
  const videoId = 'gYi51iEyf8A';
  const embedUrl = `https://www.youtube.com/embed/${videoId}?start=39&autoplay=1&mute=1&loop=1&playlist=${videoId}&controls=0&showinfo=0&rel=0&iv_load_policy=3&modestbranding=1`;

  return (
    <div className="absolute top-0 left-0 w-full h-full overflow-hidden">
      <iframe
        src={embedUrl}
        title="YouTube video player"
        frameBorder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        className="absolute top-1/2 left-1/2 w-full h-full -translate-x-1/2 -translate-y-1/2"
        style={{
          minWidth: '177.77vh', // 16/9 aspect ratio
          minHeight: '100vw',
          width: '100vw',
          height: '56.25vw', // 16/9 aspect ratio
          pointerEvents: 'none',
        }}
      ></iframe>
    </div>
  );
};

export default HeroImage;