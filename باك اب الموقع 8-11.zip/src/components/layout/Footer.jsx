
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { LanguageContext } from '@/context/LanguageContext';
import { Youtube, Linkedin, Instagram, Facebook, Instagram as TikTokIcon } from 'lucide-react';

const Footer = () => {
  const { language } = useContext(LanguageContext);
  const isRtl = language === 'ar';

  const t = {
    en: {
      subscribeTitle: "Subscribe to Our Newsletter",
      subscribePlaceholder: "Enter your email",
      subscribeButton: "Subscribe",
      services: "Services",
      equipment: "Equipment",
      about: "About Us",
      contact: "Contact Us",
      blog: "Blog",
      projects: "Projects",
      company: "Company",
      legal: "Legal",
      privacy: "Privacy Policy",
      terms: "Terms of Service",
      rights: "© 2024 BKU Crane. All rights reserved.",
      maintenance: "Maintenance",
      training: "Training",
      logistics: "Logistics",
      consultation: "Consultation",
      towerCranes: "Tower Cranes",
      constructionHoists: "Construction Hoists",
      catalogSales: "Catalog Sales",
      media: "Media",
    },
    ar: {
      subscribeTitle: "اشترك في نشرتنا الإخبارية",
      subscribePlaceholder: "أدخل بريدك الإلكتروني",
      subscribeButton: "اشتراك",
      services: "الخدمات",
      equipment: "المعدات",
      about: "من نحن",
      contact: "اتصل بنا",
      blog: "المدونة",
      projects: "المشاريع",
      company: "الشركة",
      legal: "قانوني",
      privacy: "سياسة الخصوصية",
      terms: "شروط الخدمة",
      rights: "© 2024 BKU Crane. جميع الحقوق محفوظة.",
      maintenance: "الصيانة",
      training: "التدريب",
      logistics: "الخدمات اللوجستية",
      consultation: "الاستشارات",
      towerCranes: "رافعات برجية",
      constructionHoists: "مصاعد البناء",
      catalogSales: "بيع الكتالوج",
      media: "الإعلام",
    },
     tr: {
      subscribeTitle: "Bültenimize Abone Olun",
      subscribePlaceholder: "E-postanızı girin",
      subscribeButton: "Abone Ol",
      services: "Hizmetler",
      equipment: "Ekipman",
      about: "Hakkımızda",
      contact: "İletişim",
      blog: "Blog",
      projects: "Projeler",
      company: "Şirket",
      legal: "Yasal",
      privacy: "Gizlilik Politikası",
      terms: "Hizmet Şartları",
      rights: "© 2024 BKU Crane. Tüm hakları saklıdır.",
      maintenance: "Bakım",
      training: "Eğitim",
      logistics: "Lojistik",
      consultation: "Danışmanlık",
      towerCranes: "Kule Vinçler",
      constructionHoists: "İnşaat Asansörleri",
      catalogSales: "Katalog Satışları",
      media: "Medya",
    },
    zh: {
      subscribeTitle: "订阅我们的新闻通讯",
      subscribePlaceholder: "输入您的电子邮件",
      subscribeButton: "订阅",
      services: "服务",
      equipment: "设备",
      about: "关于我们",
      contact: "联系我们",
      blog: "博客",
      projects: "项目",
      company: "公司",
      legal: "法律",
      privacy: "隐私政策",
      terms: "服务条款",
      rights: "© 2024 BKU Crane. 版权所有。",
      maintenance: "维护",
      training: "培训",
      logistics: "后勤",
      consultation: "咨询",
      towerCranes: "塔式起重机",
      constructionHoists: "施工升降机",
      catalogSales: "目录销售",
      media: "媒体",
    },
  }[language];

  const langPrefix = language === 'ar' ? '' : (language === 'zh' ? '/cn' : `/${language}`);

  return (
    <footer className="bg-gray-900 text-gray-300" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-8">
          
          <div className="col-span-1 md:col-span-4 lg:col-span-2">
            <h3 className="text-lg font-semibold text-white mb-4">{t.subscribeTitle}</h3>
            <form className="flex">
              <Input
                type="email"
                placeholder={t.subscribePlaceholder}
                className="rounded-l-md rounded-r-none bg-gray-800 text-white border-gray-700 focus:ring-red-500"
                aria-label={t.subscribePlaceholder}
              />
              <Button type="submit" className="bg-red-600 hover:bg-red-700 text-white rounded-r-md rounded-l-none">
                {t.subscribeButton}
              </Button>
            </form>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-4">{t.services}</h3>
            <ul className="space-y-2">
              <li><Link to={`${langPrefix}/services/maintenance`} className="hover:text-white transition-colors">{t.maintenance}</Link></li>
              <li><Link to={`${langPrefix}/services/training`} className="hover:text-white transition-colors">{t.training}</Link></li>
              <li><Link to={`${langPrefix}/services/logistics`} className="hover:text-white transition-colors">{t.logistics}</Link></li>
              <li><Link to={`${langPrefix}/services/consultation`} className="hover:text-white transition-colors">{t.consultation}</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-4">{t.equipment}</h3>
            <ul className="space-y-2">
              <li><Link to={`${langPrefix}/equipment/tower-cranes`} className="hover:text-white transition-colors">{t.towerCranes}</Link></li>
              <li><Link to={`${langPrefix}/equipment/construction-hoists`} className="hover:text-white transition-colors">{t.constructionHoists}</Link></li>
              <li><Link to={`${langPrefix}/catalog-sales`} className="hover:text-white transition-colors">{t.catalogSales}</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-4">{t.company}</h3>
            <ul className="space-y-2">
              <li><Link to={`${langPrefix}/about`} className="hover:text-white transition-colors">{t.about}</Link></li>
              <li><Link to={`${langPrefix}/contact`} className="hover:text-white transition-colors">{t.contact}</Link></li>
              <li><Link to={`${langPrefix}/blog`} className="hover:text-white transition-colors">{t.blog}</Link></li>
              <li><Link to={`${langPrefix}/projects`} className="hover:text-white transition-colors">{t.projects}</Link></li>
              <li><Link to={`${langPrefix}/media`} className="hover:text-white transition-colors">{t.media}</Link></li>
            </ul>
          </div>

        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-sm text-gray-400">{t.rights}</p>
          <div className="flex space-x-4 mt-4 sm:mt-0">
            <a href="https://www.youtube.com/@bkucrane" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white"><Youtube /></a>
            <a href="https://www.linkedin.com/company/bkucrane/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white"><Linkedin /></a>
            <a href="https://www.instagram.com/bku_cranes/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white"><Instagram /></a>
            <a href="https://www.facebook.com/share/1QK2CJFNbr/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white"><Facebook /></a>
            <a href="https://www.tiktok.com/@bku_cranes" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white"><TikTokIcon /></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
