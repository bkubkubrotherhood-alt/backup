import React, { useState, useContext, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Mail, Phone, Globe, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { LanguageContext } from '@/context/LanguageContext';
import { translations } from '@/lib/translations';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const NavLink = ({ to, children, isActive, getLink, closeMobileMenu, className = "" }) => {
    return (
        <Link 
            to={getLink(to)} 
            className={`font-semibold transition-colors text-lg lg:text-base ${className} ${isActive ? 'text-red-500' : 'text-white hover:text-red-500'}`} 
            onClick={closeMobileMenu}
        >
            {children}
        </Link>
    );
};

const NavDropdown = ({ name, items, getLink, closeMobileMenu, textColorClass }) => {
    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <button className={`flex items-center font-semibold hover:text-red-500 transition-colors focus:outline-none text-lg lg:text-base ${textColorClass}`}>
                    {name}
                    <ChevronDown className="h-4 w-4 ml-1" />
                </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                {items.map((item) => (
                    <DropdownMenuItem key={item.name} asChild>
                        <Link to={getLink(item.href)} onClick={closeMobileMenu}>{item.name}</Link>
                    </DropdownMenuItem>
                ))}
            </DropdownMenuContent>
        </DropdownMenu>
    );
};

const Header = ({ isHomePage }) => {
    const [isOpen, setIsOpen] = useState(false);
    const { language, setLanguage } = useContext(LanguageContext);
    const location = useLocation();
    const navigate = useNavigate();
    const [isScrolled, setIsScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        setIsOpen(false);
    }, [location]);

    useEffect(() => {
        if (isOpen) {
            document.body.classList.add('overflow-hidden');
        } else {
            document.body.classList.remove('overflow-hidden');
        }
        return () => document.body.classList.remove('overflow-hidden');
    }, [isOpen]);
    
    const t = translations[language] || translations.en;
    
    const getLink = (path) => {
        if (!path) return '/';
        const langPrefix = {
            en: '/en',
            tr: '/tr',
            zh: '/cn',
            ar: ''
        }[language];
        
        return `${langPrefix}${path === '/' ? '' : path}`;
    };
    
    const closeMobileMenu = () => setIsOpen(false);

    const navLinks = [
        { name: t.nav.home, href: '/' },
        { 
            name: t.nav.equipment, 
            href: '/equipment', 
            hasDropdown: true,
            dropdownItems: [
                { name: t.equipment_dropdown.tower_cranes, href: '/equipment/tower-cranes' },
                { name: t.equipment_dropdown.construction_hoists, href: '/equipment/construction-hoists' },
                { name: t.equipment_dropdown.catalog_sales, href: '/catalog-sales' },
            ]
        },
        { name: t.nav.services, href: '/services' },
        { name: t.nav.about, href: '/about' },
        { name: t.nav.projects, href: '/projects' },
        { name: t.nav.blog, href: '/blog' },
        { name: t.nav.media, href: '/media' },
        { name: t.nav.contact, href: '/contact' },
    ];
    
    const handleLanguageChange = (newLang) => {
        const pathSegments = location.pathname.split('/').filter(Boolean);
        let currentPathWithoutLang = location.pathname;

        if (['en', 'tr', 'cn'].includes(pathSegments[0])) {
            currentPathWithoutLang = '/' + pathSegments.slice(1).join('/');
        }
        
        if (currentPathWithoutLang === '') currentPathWithoutLang = '/';

        let newPath;
        if (newLang === 'ar') {
            newPath = currentPathWithoutLang;
        } else {
            const langPrefix = newLang === 'zh' ? 'cn' : newLang;
            newPath = `/${langPrefix}${currentPathWithoutLang === '/' ? '' : currentPathWithoutLang}`;
        }
        
        setLanguage(newLang);
        navigate(newPath);
    };
    
    const LanguageSwitcher = ({ className }) => (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" className={`px-2 hover:bg-transparent focus-visible:ring-0 ${className}`}>
                    <Globe className="h-5 w-5" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                <DropdownMenuItem onSelect={() => handleLanguageChange('ar')}>العربية</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleLanguageChange('en')}>English</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleLanguageChange('tr')}>Türkçe</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleLanguageChange('zh')}>中文</DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );

    const isTransparent = isHomePage && !isScrolled && !isOpen;
    const headerClasses = `fixed top-0 left-0 w-full z-30 transition-all duration-300 ${isTransparent ? 'bg-transparent' : 'bg-black/80 backdrop-blur-sm shadow-lg'}`;
    const textColorClass = isTransparent ? 'text-white' : 'text-white';
    
    return (
        <header className={headerClasses}>
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                {/* Top bar with Logo and Contact Info */}
                <div className="flex flex-wrap items-center justify-between py-2">
                    {/* Contact Info and Language Switcher (left) */}
                    <div className={`flex items-center space-x-4 order-1 flex-grow justify-start rtl:space-x-reverse ${textColorClass}`}>
                        <LanguageSwitcher className={`${textColorClass} hover:text-red-500`} />
                        <div className="hidden lg:flex items-center text-sm space-x-4 rtl:space-x-reverse">
                            <a href="tel:+96569306030" className="flex items-center space-x-1 rtl:space-x-reverse hover:text-red-500" dir="ltr">
                                <Phone size={16} />
                                <span>+965 - 69306030</span>
                            </a>
                            <a href="mailto:INFO@BKUCRANE.COM" className="flex items-center space-x-1 rtl:space-x-reverse hover:text-red-500">
                                <Mail size={16} />
                                <span>INFO@BKUCRANE.COM</span>
                            </a>
                        </div>
                        {/* Mobile menu button */}
                        <div className="lg:hidden">
                            <button onClick={() => setIsOpen(!isOpen)} className={`${textColorClass} focus:outline-none ml-2`}>
                                {isOpen ? <X size={28} /> : <Menu size={28} />}
                            </button>
                        </div>
                    </div>
                    
                    {/* Logo (right) */}
                    <div className="flex-shrink-0 order-2">
                        <Link to={getLink('/')}>
                            <img className="h-16 w-auto" src="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/7d494b4590625ca775a667a4119d24d3.png" alt="BKU Crane Logo" />
                        </Link>
                    </div>
                </div>

                {/* Navigation Links (centered below) */}
                <div className="hidden lg:flex items-center justify-center pb-2">
                     <nav className="flex items-center space-x-6 rtl:space-x-reverse">
                        {navLinks.map((link) => 
                            link.hasDropdown ? (
                                <NavDropdown 
                                    key={link.name}
                                    name={link.name}
                                    items={link.dropdownItems}
                                    getLink={getLink}
                                    closeMobileMenu={closeMobileMenu}
                                    textColorClass={textColorClass}
                                />
                            ) : (
                                <NavLink 
                                    key={link.name} 
                                    to={link.href}
                                    isActive={location.pathname === getLink(link.href)}
                                    getLink={getLink}
                                    className={textColorClass}
                                >
                                    {link.name}
                                </NavLink>
                            )
                        )}
                    </nav>
                </div>
            </div>

            {/* Mobile Menu Overlay */}
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="lg:hidden fixed inset-0 bg-black bg-opacity-95 z-40 h-screen"
                    >
                        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col">
                            {/* Mobile menu header */}
                            <div className="flex justify-between items-center h-20">
                                 <div className="flex-shrink-0">
                                    <Link to={getLink('/')} onClick={closeMobileMenu}>
                                        <img className="h-16 w-auto" src="https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/7d494b4590625ca775a667a4119d24d3.png" alt="BKU Crane Logo" />
                                    </Link>
                                </div>
                                <button onClick={closeMobileMenu} className="text-white focus:outline-none">
                                    <X size={28} />
                                </button>
                            </div>
                            {/* Mobile menu links */}
                            <div className="flex-grow flex flex-col justify-center items-center -mt-20">
                                <nav className="flex flex-col items-center space-y-6">
                                     {navLinks.map((link) => 
                                        link.hasDropdown ? (
                                            <NavDropdown 
                                                key={link.name}
                                                name={link.name}
                                                items={link.dropdownItems}
                                                getLink={getLink}
                                                closeMobileMenu={closeMobileMenu}
                                                textColorClass="text-white"
                                            />
                                        ) : (
                                            <NavLink 
                                                key={link.name} 
                                                to={link.href}
                                                isActive={location.pathname === getLink(link.href)}
                                                getLink={getLink}
                                                closeMobileMenu={closeMobileMenu}
                                                className="text-2xl text-white"
                                            >
                                                {link.name}
                                            </NavLink>
                                        )
                                    )}
                                </nav>
                                {/* Mobile contact info */}
                                <div className="mt-12 flex flex-col items-center space-y-6 text-white">
                                    <a href="mailto:INFO@BKUCRANE.COM" className="flex items-center space-x-2 rtl:space-x-reverse hover:text-red-500">
                                        <Mail size={20} />
                                        <span>INFO@BKUCRANE.COM</span>
                                    </a>
                                    <a href="tel:+96569306030" className="flex items-center space-x-2 rtl:space-x-reverse hover:text-red-500" dir="ltr">
                                        <Phone size={20} />
                                        <span>+965 - 69306030</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </header>
    );
};

export default Header;