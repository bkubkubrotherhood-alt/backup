import React, { useContext } from 'react';
import { LanguageContext } from '@/context/LanguageContext';

const PartnersSection = () => {
    const { language } = useContext(LanguageContext);

    const content = {
        en: {
            title: "Our Success Partners: The Best in Tower Cranes"
        },
        ar: {
            title: "شركاؤنا في النجاح: الأفضل في عالم الرافعات البرجية"
        },
        zh: {
            title: "我们的成功合作伙伴：塔式起重机领域的佼佼者"
        },
        tr: {
            title: "Başarı Ortaklarımız: Kule Vinçlerde En İyiler"
        }
    };

    const t = content[language] || content.ar;

    const partners = [
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/9ec70a41ade491cc72efd3839b542bfa.png", alt: "CGC - Combined Group Contracting Company Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/f1ce58370330ed3476e1bb3f30a699a2.png", alt: "Ahmadiah Contracting & Trading Co. Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/1860fb9fe4912662f2d45d608a619c6a.jpg", alt: "Alghanim International Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/447b89669268e41bd6cee63c682f7786.jpg", alt: "Al-Ahlia Contracting Group Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/b81f08f284d7e0e44166a16676689e1f.png", alt: "Al Hani Group Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/0880579006d6b802f1f45dc832214ec4.png", alt: "Kuwait Petroleum Corporation Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/0bdc8bbc1006d3a58ed9d8ae64003b43.png", alt: "Kuwait Oil Company Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/c28ef250831a7c35a74bb01043d531ae.png", alt: "First United Building Construction Co. Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/1d2506dce43749ed6cf1134eb1070b62.png", alt: "SHBC Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/2f1850a6aae2529e35b23ae8b0cf866f.jpg", alt: "Al Bahar Construction Co. Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/a57b28c9566d4bc24ced915003321bb1.png", alt: "Ministry of Public Works Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/fae58892849b62ffd2ef82dda618f447.png", alt: "KNPC Logo" },
      { logo: "https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/8d52344eb4de5ab3301b6eb9c849b8bc.webp", alt: "Public Authority for Housing Welfare Logo" }
    ];
    
    const extendedPartners = [...partners, ...partners];

    return (
        <div className="py-16 sm:py-24 bg-gray-100 overflow-hidden">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight text-center mb-12">{t.title}</h2>
                <div className="relative">
                    <div className="marquee">
                        <div className="marquee-content">
                            {extendedPartners.map((partner, index) => (
                                <div key={index} className="marquee-item">
                                    <img 
                                        src={partner.logo} 
                                        alt={partner.alt}
                                        className="h-12 sm:h-16 max-w-none filter grayscale hover:grayscale-0 transition-all duration-300"
                                        loading="lazy"
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PartnersSection;