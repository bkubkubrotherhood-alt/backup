import React, { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { LanguageContext } from '@/context/LanguageContext';
import HeroImage from '@/components/HeroImage';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Building, RollerCoaster, Wrench, Info, BookOpen } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";


const Hero = () => {
    const { language } = useContext(LanguageContext);
    const [activeTab, setActiveTab] = useState('rent');
    const [searchTerm, setSearchTerm] = useState('');
    const { toast } = useToast();
    const navigate = useNavigate();

    const getLink = (path) => {
        if (language === 'ar') return path;
        const langCode = language === 'zh' ? 'cn' : language;
        return `/${langCode}${path}`;
    };

    const handleSearch = (e) => {
        e.preventDefault();
        toast({
            title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
            description: "We're working on bringing you the best search experience!",
        });
    };

    const content = {
        en: {
            mainHeading: "Experts in renting, selling, and maintaining Liebherr, Potain, Zoomlion, and Yongmao cranes.",
            subHeading: "Bader Al-Kuweity For United Brothers leads in tower crane rental and sales in Kuwait. We offer integrated solutions including luffing and self-erecting cranes, with a full commitment to safety. Official partner towards the new Kuwait vision 2035.",
            rent: "Rent",
            buy: "Buy",
            browse: "Search for tower crane for sale, rental...",
            search: "Search",
            whyBKU: "WHY BKU?",
            maintenance: "High-level Maintenance",
            spareParts: "Spare Parts Always Available",
            categories: [
                { name: "Tower Cranes", icon: Building, link: getLink('/equipment/tower-cranes') },
                { name: "Hoists", icon: RollerCoaster, link: getLink('/equipment/construction-hoists') },
                { name: "Catalogs", icon: BookOpen, link: getLink('/catalog-sales') },
                { name: "About Us", icon: Info, link: getLink('/about') },
            ]
        },
        ar: {
            mainHeading: "خبراء تأجير، بيع، وصيانة رافعات Liebherr و Potain و Zoomlion و Yongmao.",
            subHeading: "شركة الإخوة الكويتية المتحدة رائدة في تأجير وبيع الرافعات البرجية في الكويت (تور كرين). نقدم حلولاً متكاملة تشمل luffing crane و self erecting tower crane، مع التزام كامل بالسلامة. شريك رسمي نحو رؤية كويت جديدة 2035.",
            rent: "تأجير",
            buy: "شراء",
            browse: "ابحث عن تاجير رافعه برجية، بيع رافعة برجية...",
            search: "بحث",
            whyBKU: "لماذا BKU؟",
            maintenance: "صيانة عالية المستوى",
            spareParts: "قطع غيار متوفرة دائماً",
            categories: [
                { name: "تاور كرين", icon: Building, link: getLink('/equipment/tower-cranes') },
                { name: "مصاعد بناء", icon: RollerCoaster, link: getLink('/equipment/construction-hoists') },
                { name: "الكتالوجات", icon: BookOpen, link: getLink('/catalog-sales') },
                { name: "من نحن", icon: Info, link: getLink('/about') },
            ]
        },
        zh: {
            mainHeading: "专业租赁、销售和维护利勃海尔、波坦、中联重科和永茂起重机。",
            subHeading: "Bader Al-Kuweity For United Brothers公司是科威特塔式起重机租赁和销售的领导者。我们提供包括动臂起重机和自升式起重机在内的综合解决方案，并完全致力于安全。作为实现新科威特2035年愿景的官方合作伙伴。",
            rent: "租赁",
            buy: "购买",
            browse: "搜索待售、租赁的塔式起重机...",
            search: "搜索",
            whyBKU: "为什么选择BKU？",
            maintenance: "高水平维护",
            spareParts: "备件随时可用",
            categories: [
                { name: "塔式起重机", icon: Building, link: getLink('/equipment/tower-cranes') },
                { name: "施工升降机", icon: RollerCoaster, link: getLink('/equipment/construction-hoists') },
                { name: "产品目录", icon: BookOpen, link: getLink('/catalog-sales') },
                { name: "关于我们", icon: Info, link: getLink('/about') },
            ]
        },
        tr: {
            mainHeading: "Liebherr, Potain, Zoomlion ve Yongmao vinçlerinin kiralanması, satışı ve bakımında uzmanlar.",
            subHeading: "Bader Al-Kuweity For United Brothers, Kuveyt'te kule vinç kiralama ve satışında liderdir. Luffing ve kendi kendine kurulan vinçler de dahil olmak üzere entegre çözümler sunuyoruz ve güvenliğe tam bağlıyız. Yeni Kuveyt 2035 vizyonuna doğru resmi ortak.",
            rent: "Kirala",
            buy: "Satın Al",
            browse: "Satılık, kiralık kule vinç ara...",
            search: "Ara",
            whyBKU: "NEDEN BKU?",
            maintenance: "Üst Düzey Bakım",
            spareParts: "Yedek Parça Her Zaman Mevcut",
            categories: [
                { name: "Kule Vinçler", icon: Building, link: getLink('/equipment/tower-cranes') },
                { name: "İnşaat Asansörleri", icon: RollerCoaster, link: getLink('/equipment/construction-hoists') },
                { name: "Kataloglar", icon: BookOpen, link: getLink('/catalog-sales') },
                { name: "Hakkımızda", icon: Info, link: getLink('/about') },
            ]
        }
    };
    
    const t = content[language] || content.ar;

    const textVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { 
            opacity: 1, 
            y: 0,
            transition: {
                staggerChildren: 0.1,
                delayChildren: 0.2,
            }
        },
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100 } },
    };

    return (
        <section className="relative h-screen w-full text-white overflow-hidden">
            <HeroImage />
            <div className="absolute inset-0 bg-black/60" />
            <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4 pt-32">
                <motion.div
                    className="max-w-4xl w-full"
                    variants={textVariants}
                    initial="hidden"
                    animate="visible"
                >
                    <motion.h2 
                        variants={itemVariants} 
                        className="text-3xl md:text-5xl font-bold tracking-tight text-shadow-lg"
                        style={{ textShadow: '2px 2px 8px rgba(0,0,0,0.7)' }}
                    >
                        {t.mainHeading}
                    </motion.h2>
                    <motion.p
                         variants={itemVariants}
                         className="mt-4 text-base md:text-lg max-w-3xl mx-auto"
                         style={{ textShadow: '1px 1px 4px rgba(0,0,0,0.7)' }}
                    >
                        {t.subHeading}
                    </motion.p>
                    
                    <motion.div variants={itemVariants} className="mt-8 max-w-2xl mx-auto">
                        <form onSubmit={handleSearch} className="relative bg-white rounded-full p-1.5 flex items-center shadow-2xl">
                             <div className="flex">
                                <Button type="button" onClick={() => setActiveTab('rent')} variant="ghost" className={`rounded-full text-sm sm:text-base px-3 sm:px-4 ${activeTab === 'rent' ? 'bg-gray-200 text-gray-800' : 'text-gray-500'}`}>{t.rent}</Button>
                                <Button type="button" onClick={() => setActiveTab('buy')} variant="ghost" className={`rounded-full text-sm sm:text-base px-3 sm:px-4 ${activeTab === 'buy' ? 'bg-gray-200 text-gray-800' : 'text-gray-500'}`}>{t.buy}</Button>
                            </div>
                            <Search className="h-5 w-5 text-gray-400 mx-2" />
                            <Input
                                type="text"
                                placeholder={t.browse}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="flex-grow bg-transparent border-none focus:ring-0 text-gray-800 placeholder-gray-400 text-sm sm:text-base"
                            />
                            <Button type="submit" className="bg-red-600 hover:bg-red-700 rounded-full px-4 sm:px-8 text-sm sm:text-base">{t.search}</Button>
                        </form>
                    </motion.div>

                    <motion.div variants={itemVariants} className="mt-8 flex justify-center items-center gap-4 md:gap-8 flex-wrap">
                        {t.categories.map(cat => (
                             <Link key={cat.name} to={cat.link} className="flex flex-col items-center gap-2 text-white hover:text-red-400 transition-colors">
                                <div className="bg-white/20 p-3 rounded-full backdrop-blur-sm">
                                    <cat.icon className="h-6 w-6" />
                                </div>
                                <span className="text-sm font-semibold">{cat.name}</span>
                            </Link>
                        ))}
                    </motion.div>
                    
                    <motion.div variants={itemVariants} className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4 md:gap-8 text-sm md:text-base">
                        <span className="font-bold">{t.whyBKU}</span>
                        <div className="flex items-center gap-2">
                            <Wrench className="h-5 w-5 text-red-400" />
                            <span>{t.maintenance}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <Info className="h-5 w-5 text-red-400" />
                            <span>{t.spareParts}</span>
                        </div>
                    </motion.div>

                </motion.div>
            </div>
        </section>
    );
};

export default Hero;