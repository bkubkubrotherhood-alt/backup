import React, { useContext, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';
import { translations } from '@/lib/translations';
import { blogData } from '@/lib/blogData.js';

const NewsSection = () => {
    const { language } = useContext(LanguageContext);
    const isRtl = language === 'ar';
    const t = useMemo(() => (translations[language] && translations[language].news) ? translations[language].news : translations.en.news, [language]);
    
    const getLink = (path) => {
        if (language === 'ar') return path;
        const langCode = language === 'zh' ? 'cn' : language;
        return `/${langCode}${path}`;
    };

    const posts = useMemo(() => {
        const allPosts = blogData[language] || blogData.en || [];
        return allPosts.slice(0, 3).filter(p => p && p.id);
    }, [language]);

    const Arrow = isRtl ? ArrowLeft : ArrowRight;

    return (
        <section className="py-16 sm:py-24 bg-gray-50 dark:bg-gray-800">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 dark:text-white tracking-tight">{t.title}</h2>
                    <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300">{t.subtitle}</p>
                </div>
                
                {posts && posts.length > 0 ? (
                    <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                        {posts.map((post, index) => (
                            <motion.div
                                key={post.id}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: index * 0.1 }}
                                className="flex flex-col overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300"
                            >
                                <Link to={getLink(`/blog/${post.id}`)} className="block h-full flex flex-col">
                                    <div className="flex-shrink-0">
                                        <img className="h-56 w-full object-cover" src={post.image} alt={post.imageAlt} />
                                    </div>
                                    <div className="flex flex-1 flex-col justify-between bg-white dark:bg-gray-900 p-6">
                                        <div className="flex-1">
                                            <p className="text-sm font-medium text-red-600 dark:text-red-500">
                                                {post.category}
                                            </p>
                                            <div className="mt-2 block">
                                                <p className="text-xl font-semibold text-gray-900 dark:text-white">{post.title}</p>
                                                <p className="mt-3 text-base text-gray-500 dark:text-gray-400 line-clamp-3">{post.content.replace(/###\s?\d\.\s/g, '').replace(/###/g, '').replace(/\*/g, '')}</p>
                                            </div>
                                        </div>
                                        <div className="mt-6 flex items-center justify-between">
                                            <div className="text-sm text-gray-500 dark:text-gray-400">
                                                <time dateTime={post.datetime}>{post.date}</time>
                                            </div>
                                            <div className="text-sm font-semibold text-red-600 dark:text-red-400 hover:text-red-700 flex items-center">
                                                {t.readMore}
                                                <Arrow className="ml-1 h-4 w-4 rtl:mr-1 rtl:ml-0" />
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            </motion.div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-10">
                        <p className="text-lg text-gray-500 dark:text-gray-400">{t.noNews}</p>
                    </div>
                )}

                <div className="mt-12 text-center">
                     <Button asChild variant="outline" size="lg">
                        <Link to={getLink('/blog')} className="text-red-600 border-red-600 hover:bg-red-50 hover:text-red-700">
                            {t.viewAll}
                        </Link>
                    </Button>
                </div>
            </div>
        </section>
    );
};

export default NewsSection;