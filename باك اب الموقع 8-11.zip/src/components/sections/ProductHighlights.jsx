import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Package, Wrench, Warehouse } from 'lucide-react';
import { LanguageContext } from '@/context/LanguageContext';
import { Link } from 'react-router-dom';

const ProductHighlights = () => {
    const { language } = useContext(LanguageContext);

    const getLink = (path) => {
        if (language === 'ar') return path;
        const langCode = language === 'zh' ? 'cn' : language;
        return `/${langCode}${path}`;
    };
    
    const newImageUrl = 'https://horizons-cdn.hostinger.com/7f32b2f1-8cab-4098-83e8-7ea4bac69708/61820e5025eef3b8de85b0b8c9b19a02.png';

    const content = {
        en: {
            title: "Complete Construction Solutions",
            items: [
                { 
                    icon: Package, 
                    title: "Do you need to Rent an Equipment?",
                    description: "Explore our wide range of rental equipment.",
                    link: getLink('/equipment'),
                    image: newImageUrl,
                    alt: "Tower crane for rent in Kuwait"
                },
                { 
                    icon: Warehouse, 
                    title: "Do you need to Buy an Equipment?",
                    description: "Check our catalog for new and used equipment for sale.",
                    link: getLink('/catalog-sales'),
                    image: newImageUrl,
                    alt: "Tower crane for sale in Kuwait"
                },
                { 
                    icon: Wrench, 
                    title: "Spare Parts & Maintenance",
                    description: "We provide original spare parts and expert maintenance services.",
                    link: getLink('/services/maintenance'),
                    image: newImageUrl,
                    alt: "Tower crane spare parts and maintenance"
                },
            ]
        },
        ar: {
            title: "حلول بناء متكاملة",
            items: [
                { 
                    icon: Package, 
                    title: "هل تحتاج إلى استئجار معدات؟",
                    description: "اكتشف مجموعتنا الواسعة من المعدات المتاحة للإيجار.",
                    link: getLink('/equipment'),
                    image: newImageUrl,
                    alt: "رافعة برجية للإيجار في الكويت"
                },
                { 
                    icon: Warehouse, 
                    title: "هل تحتاج إلى شراء معدات؟",
                    description: "تصفح الكتالوج الخاص بنا للمعدات الجديدة والمستعملة للبيع.",
                    link: getLink('/catalog-sales'),
                    image: newImageUrl,
                    alt: "رافعة برجية للبيع في الكويت"
                },
                { 
                    icon: Wrench, 
                    title: "قطع غيار وصيانة",
                    description: "نوفر قطع غيار أصلية وخدمات صيانة احترافية.",
                    link: getLink('/services/maintenance'),
                    image: newImageUrl,
                    alt: "قطع غيار وصيانة رافعة برجية"
                },
            ]
        },
        zh: {
            title: "完整的施工解决方案",
            items: [
                { 
                    icon: Package, 
                    title: "您需要租赁设备吗？",
                    description: "探索我们广泛的租赁设备。",
                    link: getLink('/equipment'),
                    image: newImageUrl,
                    alt: "科威特塔式起重机租赁"
                },
                { 
                    icon: Warehouse, 
                    title: "您需要购买设备吗？",
                    description: "查看我们的目录，了解待售的新旧设备。",
                    link: getLink('/catalog-sales'),
                    image: newImageUrl,
                    alt: "科威特塔式起重机销售"
                },
                { 
                    icon: Wrench, 
                    title: "备件与维护",
                    description: "我们提供原装备件和专业的维护服务。",
                    link: getLink('/services/maintenance'),
                    image: newImageUrl,
                    alt: "塔式起重机备件和维护"
                },
            ]
        },
        tr: {
            title: "Komple İnşaat Çözümleri",
            items: [
                { 
                    icon: Package, 
                    title: "Ekipman Kiralamanız mı Gerekiyor?",
                    description: "Geniş kiralık ekipman yelpazemizi keşfedin.",
                    link: getLink('/equipment'),
                    image: newImageUrl,
                    alt: "Kuveyt'te kiralık kule vinç"
                },
                { 
                    icon: Warehouse, 
                    title: "Ekipman Satın Almanız mı Gerekiyor?",
                    description: "Satılık yeni ve kullanılmış ekipmanlar için kataloğumuzu kontrol edin.",
                    link: getLink('/catalog-sales'),
                    image: newImageUrl,
                    alt: "Kuveyt'te satılık kule vinç"
                },
                { 
                    icon: Wrench, 
                    title: "Yedek Parça ve Bakım",
                    description: "Orijinal yedek parçalar ve uzman bakım hizmetleri sunuyoruz.",
                    link: getLink('/services/maintenance'),
                    image: newImageUrl,
                    alt: "Kule vinç yedek parçaları ve bakımı"
                },
            ]
        }
    };
    const t = content[language] || content.ar;

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: { staggerChildren: 0.2, delayChildren: 0.2 }
        }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1,
            transition: { type: 'spring', stiffness: 100 }
        }
    };

    return (
        <section className="py-16 sm:py-24 bg-white">
            <div className="container mx-auto px-4">
                 <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight text-center mb-12">{t.title}</h2>
                <motion.div 
                    className="grid grid-cols-1 md:grid-cols-3 gap-8"
                    variants={containerVariants}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.3 }}
                >
                    {t.items.map((item, index) => (
                        <motion.div key={index} variants={itemVariants}>
                             <Link to={item.link} className="h-full block group">
                                <Card className="h-full text-center overflow-hidden transition-all duration-300 ease-in-out group-hover:shadow-2xl group-hover:-translate-y-2">
                                    <CardContent className="p-6 flex flex-col items-start text-start">
                                        <div className="flex justify-between items-center w-full mb-4">
                                            <div className="bg-gray-100 p-3 rounded-full">
                                                <item.icon className="h-6 w-6 text-red-600" />
                                            </div>
                                            <img src={item.image} alt={item.alt} className="w-24 h-24 object-contain" />
                                        </div>
                                        <h3 className="text-lg font-bold text-gray-900 mb-2">{item.title}</h3>
                                        <p className="text-gray-600 flex-grow">{item.description}</p>
                                    </CardContent>
                                </Card>
                            </Link>
                        </motion.div>
                    ))}
                </motion.div>
            </div>
        </section>
    );
};

export default ProductHighlights;